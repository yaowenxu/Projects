UNIVERSE BIOS 1.3 for the MVS NeoGeo system
-------------------------------------------


  homepage = http://bios.cps2shock.com
  email    = unibios@cps2shock.com


WARNING
-------
I TAKE NO RESPONSIBILITY FOR ANY DAMAGE CAUSED TO YOUR MVS OR AES HARDWARE WHILE
INSTALLING OR USING THE UNIVERSE BIOS. WHILE THE BIOS HAS BEEN FULLY TESTED ON THIS
HARDWARE YOU USE IT AT YOUR OWN RISK.

THE UNIVERSE BIOS HAS BEEN DESIGNED FOR NON COMMERCIAL USERS OF MVS AND AES HARDWARE
ONLY. USING THE UNIVERSE BIOS IN AN ARCADE ENVIRONMENT CAN RESULT IN LOSS OF REVENUE
DUE TO CUSTOMERS OBTAINING FREE CREDITS, CHEATING IN GAMES AND SO ON. I TAKE NO
RESPONSIBILITY FOR THIS. DO NOT USE THE UNIVERSE BIOS IN AN ARCADE ENVIRONMENT
TO BE SURE, YOU HAVE BEEN WARNED.


TERMS OF USE
------------
You can use the UNIVERSE BIOS as long as you own original genuine MVS hardware.
Failure of this may result in you the user violating international copyright laws.
New program code within the UNIVERSE BIOS is (c) Razoola, original BIOS program
code remains copyrighted to SNK.

  DO NOT DISTRIBUTE A DUMP OF THE UNIVERSE BIOS UNLESS YOU ARE LEGALLY ABLE TO DO SO.
  I WILL NOT BE HELD RESPONSIBLE FOR OTHERS ACTIONS.

  DO NOT PROVIDE A SERVICE SELLING THE UNIVERSE BIOS ON EEPROM (ESPECIALLY FOR PROFIT).


DONATIONS
---------
Although the UNIVERSE BIOS is free, if you find it usefull then please consider donating
to help the cause. More information can be found on the official UNIVERSE BIOS homepage.


---------------------------------------------------------------------------------


INTRODUCTION
------------

The UNIVERSE BIOS is for owners of MVS or AES hardware that want an easy way
to change country region or between Arcade or Console mode on boot. Also included
are other features that are not normally possible using the standard MVS bios.

The UNIVERSE BIOS is also designed to give easy access to things like inserting
coins, test mode and memory card management when using the joystick ports only.
Of course the BIOS still allows standard operation too. 


  MAIN FEATURES
  -------------

  - The ability to quickly and easily change operation from MVS to AES. Play your
    favorite games as the home console version enabling all the extra gameplay
    options that come with some games.

  - The ability to quickly and easily change country region (great for games that
    disable blood under USA region).

  - Access to the DEBUG DIP's and DEVELOPER mode.

  - Want unlimited lives or energy... Then cheat in games using the built in
    cheat engine which currently holds over 1420 cheats!!!

  - Jukebox player where one can listen to game music without sound FX from
    gameplay over the top. Nice option if you want to create MP3's.

  - A ROM CRC32 check where you can confirm a games program roms are good.

  - True USA region support (correct coin display on bottom left and right of
    screen in the same way a true USA BIOS does.
  
  - Arcade VS-MODE support which is known to be in the version 6 JAPAN bios.
    Turn this feature on via hard dip 2.

  Other features
  --------------

  - Remapping of coin switches to select buttons and visa versa. This allows a SNK
    joypad pad to do everything.

  - Once region and operation mode is set the BIOS will remember settings until you
    change them again.

  - Access to the standard Memory Card Utility no matter what Mode the BIOS is in
    (one could never access this menu with the normal MVS BIOS).

  - Access to Test Mode on boot without the need of wiring the Test Mode JAMMA pins
    or fiddling with DIP's.

  - Enhancements to the TEST MODE menu and hardware test screens.

  - Console mode protection removed from latest games (kof2000 etc).

  - The ability to soft reboot the system without the need of powering off and on.


HARDWARE REQUIREMENTS
---------------------
The UNIVERSE BIOS has been designed to work on all MVS hardware types (SLOT1 and
MULTISLOT) and AES hardware. Saying that installation difficulty varies depending
on the actual MVS / AES model you have. See the notes below which correspond
to your hardware type for details. 

  - MV-1x, MV-2F, MV-4F and MV-6F
 
      MVS models in this category are by far the easiest to install the UNIVERSE BIOS
      on. No soldering is required because the BIOS should already be in a socket.

  - MV-1B and MV-1C

      These MVS models contain a BIOS that is known to be soldered to the PCB,
      the chip size is also different than that used in other MVS models.
      Because of this the MV-1B and MV-1C are very difficult to install the
      UNIVERSE BIOS on and you should not attempt to install unless you are
      very skilled with a soldering iron.

  - A.E.S system

      Installation on the AES will depend on the type of hardware you actually
      have as some AES systems have a soldered BIOS while others have the BIOS
      in a socket (I think the oldest models had a socket). If you are lucky
      you will have socket already on the PCB.

      If you have a soldered BIOS you should not attempt to install unless you
      are skilled with a soldering iron.


---------------------------------------------------------------------------------


USING THE UNIVERSE BIOS (MVS only)
----------------------------------
The first time a MVS system is switched on after UNIVERSE BIOS installation you
will see the welcome screen and then be asked to select a region and operation mode.
The UNIVERSE BIOS will then store your chosen settings and you'll never be asked
again unless you access the UNIVERSE BIOS menu to change settings.

  Note
  ----
  If your systems backup SRAM battery is dead the region settings will be lost on
  power down. This will result in being taken to the initial welcome screen every
  time you turn on the MVS system. I suggest replacement of the onboard battery
  in this situation.


USING THE UNIVERSE BIOS (AES only) 
----------------------------------
Because the AES system has no backup SRAM the system will use the memory card to
store the systems region and operation mode settings. This info is then read once
at power on, it is not read again if you use the system reset button or soft reset
option. In short the memory card must be inserted when you first power on the unit.

If a memory card is not present the system will default to EURO region and CONSOLE
operation mode on power up, you can then change this as required once you reach
the splash screen.

  Important Notes
  --------------- 
  The hardware test will keep looping until you release its button code. The screen
  flashes as the hardware check loops itself.

  Hard DIP�s are all set in the off position and cannot be changed.

  When in ARCADE mode you cannot disable developer mode.

  The UNIVERSE BIOS splash screen cannot be disabled.


Accessing Menues
----------------
The following codes should be used while the splash screen is showing or held during
system power up (splash disabled). Button codes will only work on player 1 controls. 

  A+B+C   = Main UNIVERSE BIOS Menu
  A+B+C+D = Memory Card Manager
  B+C+D   = Test mode (MVS only)
  A+B+D   = Hardware Test (AES only)

The following code can only be entered on player 2 control

  A+B+C+D = Controller Test

The following codes are available in game only, they will not work if you have disabled
the in game menu (general bios settings).

  START+SELECT = In Game Menu
  START+COIN   = In Game Menu
  START+A+B+C  = In Game Menu


The Main Menu
-------------
To navigate the UNIVERSE BIOS menu you will need to use player 1 controls,
button (A) is used as select. Here is a list of all available options
along with a small description.

  Region Settings
  ---------------
  This is where you choose your region and operation mode of the BIOS. Any settings
  made on this screen are permanantly saved until you decide to change them.

  General Settings (MVS only)
  ---------------------------
  Like with the region settings these setting are also permanantly saved. Here is a
  quick description on what each setting does.

  - Disable Boot up HW test
      Turning this option on will force the UNIVERSE BIOS to skip most RAM and VRAM tests
      done after the MVS system is initially switched on. This will make boot time faster
      although you will have no guarantee your MVS system is in correct working order. 

  - Disable In Game Menu
      This simply turns off access to the in game menu when enabled.

  - Disable Input Crossing
      This option turns off all coin to select / select to coin mappings. I'm not sure
      if anyone will find any real benefit from this option but I added it in case.

  - Disable Splash Screen
      This will turn off the UNIVERSE BIOS splash screen on bootup. I'm sure some people
      will find the screen annoying even though it shows your current BIOS region and
      operation mode. 

  Game SoftDIP Settings (AES only)
  --------------------------------
  Here you can change game settings like the amount of lives given per game, amount of
  time rounds lasts or enable blood for example. Note that Soft DIP�s are reset on
  changing the country region so always select your region setup before editing any
  soft DIP�s.

  GameCart CRC Check
  ------------------
  Here you can check that a games program data is correct by using the CRC32 algorithm.
  The screen will display the GAME ID and CRC32 for each memory region used. The result is
  then checked against an internal database to confirm it�s good. Possible messages
  resulting from this check are;

  OK	-  CRC32 Good
  NG	-  CRC32 Bad
  ??	-  CRC32 not in database

  DO NOT take the above output as 100% accurate as some CRC32 values in the database are
  probably wrong (bad dumps etc). If your game does give a different CRC32 than what�s
  expected then please email the details to us (unibios@cps2shock.com).

  Jukebox Music Player
  --------------------
  Here you can listen to music from games. Each tune or sound is assigned a sound code.
  By selecting different codes you will hear different tunes or game fx.

  Play Game
  ---------
  I'm sure this needs no explenation.


The In Game Menu
----------------
Use Player 1 controls to navigate the menues. Button A is used as select.

  The Cheat Database
  ------------------
  Everything is quite straight forward here although using cheats can cause adverse game
  effects. For example, if you experience game lockups when using a cheat try turning it
  off which may allow the game to continue and then enable it again later. Cheats can
  also cause GFX issues, most notably at the end for energy bars in some games when
  infinite energy is enabled.

  Debug DIP Settings
  ------------------
  These settings are more advanced. Debug DIPS do different things depending on the game,
  unless you know what your doing it�s best to leave them alone although experimenting won�t
  cause damage.

  Return To Game
  --------------
  I'm sure this needs no explenation.

  Soft Reboot System
  ------------------
  This setting was added by popular request, it will simply reboot the system without the
  need of powering off and on. In the long term this can help prevent damage to the system
  via constant power off and on (especially if powering off and on to fast).


Input Crossing
--------------
This feature gives you the ability to use the joystick ports (if the system has them) and
the JAMMA connector for things they weren�t initially designed for. Here�s a breakdown on
how it works.

  When using the joystick ports (if the system has them) the select buttons will insert
  coins when pressed if running in arcade mode. On MULTISLOT hardware this is disabled
  when more than one game found (ensures correct game changing operation).

  When using the JAMMA connection for joystick control the coin switches (for getting credits)
  become player 1 and player 2 select buttons when in console mode (see known issues).

  On a MULTISLOT system the joystick port select buttons and JAMMA connector select game
  pins do the same thing (by hardware design). This means you can use the game select buttons
  as player 1 and player 2 select buttons too.

  On a MULTISLOT system game selecting is only available during the attract mode sequence
  when in console mode.


---------------------------------------------------------------------------------


BURNING THE UNIVERSE BIOS ONTO EEPROM
-------------------------------------

The UNIVERSE BIOS requries a 27c1024 type EEPROM, simply burn the UNIVERSE BIOS image
onto it and then put it in place of the original BIOS on your NeoGeo hardware.


OBTAINING THE UNIVERSE BIOS ON EEPROM
-------------------------------------

If you would like the UNIVERSE BIOS provided on EEPROM because you don't have the ability
to do it yourself then visit the official homepage for information on how to get one.


---------------------------------------------------------------------------------
