package Vdb;                                   
public class Dist                              
{                                              
  public static String version = "vdbench50407"; 
  public static String compiled= "Tue June 05  9:49:29 MDT 2018"; 
}                                              
