#include "osd_so.h"

/***************************************************************************

    version.c

    Version string source file for MAME.

    Copyright (c) 1996-2007, Nicola Salmoria and the MAME Team.
    Visit http://mamedev.org for licensing and usage restrictions.

***************************************************************************/

char build_version[] = "0.012a (from MAME 0.117) ("__DATE__")";
