well, everything should be self explained in kailleraclient.h.

if you need a sample, go look at the Kaillera implementation in the Mame32 source code, available on Kaillera's home page (http://www.kaillera.com/)

if you still have troubles/problems implementing the Kaillera client into your application, go look into the Kaillera SDK forums.

-christophe