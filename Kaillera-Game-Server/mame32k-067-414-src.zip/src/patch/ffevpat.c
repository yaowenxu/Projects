/****************************
     Fight Fever Patch
****************************/

#define PATCH_END  (-1)

#include "driver.h"
#include "ffevs1.c"

void neogeo_fightfev_patch(void)
{
	data8_t *mem8 = memory_region(REGION_GFX1);
	int i = 0;

	while (fightfev_s1_address[i] != PATCH_END)
	{
		mem8[fightfev_s1_address[i]] = fightfev_s1_data[i];
		i++;
	}
}
