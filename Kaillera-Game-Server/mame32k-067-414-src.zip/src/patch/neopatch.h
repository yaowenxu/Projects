void neogeo_kof99_patch(void);
void neogeo_garou_patch(void);
void neogeo_strhoop_patch(void);
void neogeo_wjammers_patch(void); // by nose
void neogeo_fightfev_patch(void);
