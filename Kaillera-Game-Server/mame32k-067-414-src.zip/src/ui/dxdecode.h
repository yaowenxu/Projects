/* Copyright 1998 Invasion Games.  All Rights Reserved.  Do NOT distribute. */

/* dxdecode.h for client */

/* Main header file for dxdecode.cpp */

#ifndef DXDECODE_H
#define DXDECODE_H

extern const char* DirectXDecodeError(HRESULT errorval);

#endif /* DXDECODE_H */
