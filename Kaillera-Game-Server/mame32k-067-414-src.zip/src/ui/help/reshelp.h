// Include the Microsoft Developer Studio generated Help ID include file.
//
#include "..\resource.hm"
#include "mame32.hm"