/***************************************************************************

  inptport.c

  Input ports handling

TODO:	remove the 1 analog device per port limitation
		support for inputports producing interrupts
		support for extra "real" hardware (PC throttle's, spinners etc)

***************************************************************************/

#include "driver.h"
#include <math.h>

#ifdef MAME_NET
#include "network.h"

static unsigned short input_port_defaults[MAX_INPUT_PORTS];
static int default_player;
static int analog_player_port[MAX_INPUT_PORTS];
#endif /* MAME_NET */

#ifdef KAILLERA
#include "kailleraclient.h"
#include "ui/kcommand.h"
#include "ui/chat.h"
#include "cheat.h"
int kBitsPlayValues[10][32][6];
int kUpdateDip;
unsigned short kDipSwitch[MAX_INPUT_PORTS];
static unsigned short kDefValues[MAX_INPUT_PORTS];
int kFirstMsg;
extern int kPlay;
extern int kPlayers;
extern int kPlayerNB;
extern void addClock(cycles_t a);
extern cycles_t (*cycle_counter)(void);
extern unsigned int fgetsavecrc(const char *gamename, const char *filename);
extern void overclock_read_config(mame_file *f);
extern void overclock_write_config(mame_file *f);
/* Control Swap Variables */
int p1;
int p2;
int p3;
int p4;
int p5;
int p6;
int p7;
int p8;
int ana_p1;
int ana_p2;
int ana_p3;
int ana_p4;
int p1_pos = 1;
int control_counter = 0;
/* General Global Variables */
int control_type = 0;
int endemu = 0;
int special_key = 0;
int netplay_pause = -1;
unsigned short val[10];
unsigned long val2[10];
signed deltax[4];
signed deltay[4];
extern void *trace;
extern void *playback_trc;
static unsigned short playback_value[MAX_INPUT_PORTS];

/* For Multiplayer Hacks */
int p1_1c, p1_2c, p1_3c, p1_4c, p2_1c, p2_2c, p2_3c, p2_4c;
int player1_c, player2_c, player3_c, player4_c;
int player1_sub, player2_sub, player3_sub, player4_sub;
int p1_1st, p1_2nd, p1_3rd, p1_4th, p2_1st, p2_2nd, p2_3rd, p2_4th;
int init = -1;
int game = 0;
enum {
	none = 0,
	kof96_6p,
	kof97_6p,
	kof98_6p,
	kof99_6p,
	kof2000_6p,
	mvsc4p,
	mshvsf4p,
	xmvsf4p,
	kizuna_4p,
	lbowling_4p,
	kof2001_8p,
	kof2002_6p,
	rotd_4p,
	cyberbt2p,
	loderndf_vs
};
#endif /* KAILLERA */

/* header identifying the version of the game.cfg file */
/* mame 0.36b11 */
#define MAMECFGSTRING_V5 "MAMECFG\5"
#define MAMEDEFSTRING_V5 "MAMEDEF\4"

/* mame 0.36b12 with multi key/joy extension */
#define MAMECFGSTRING_V6 "MAMECFG\6"
#define MAMEDEFSTRING_V6 "MAMEDEF\5"

/* mame 0.36b13 with and/or/not combination */
#define MAMECFGSTRING_V7 "MAMECFG\7"
#define MAMEDEFSTRING_V7 "MAMEDEF\6"

/* mame 0.36b16 with key/joy merge */
#define MAMECFGSTRING_V8 "MAMECFG\x8"
#define MAMEDEFSTRING_V8 "MAMEDEF\7"

extern void *record;
extern void *playback;

extern unsigned int dispensed_tickets;
extern unsigned int coins[COIN_COUNTERS];
extern unsigned int lastcoin[COIN_COUNTERS];
extern unsigned int coinlockedout[COIN_COUNTERS];

static unsigned short input_port_value[MAX_INPUT_PORTS];
static unsigned short input_vblank[MAX_INPUT_PORTS];

/* Assuming a maxium of one analog input device per port BW 101297 */
static struct InputPort *input_analog[MAX_INPUT_PORTS];
static int input_analog_current_value[MAX_INPUT_PORTS],input_analog_previous_value[MAX_INPUT_PORTS];
static int input_analog_init[MAX_INPUT_PORTS];
static int input_analog_scale[MAX_INPUT_PORTS];

static InputCode analogjoy_input[OSD_MAX_JOY_ANALOG][MAX_ANALOG_AXES];	/* [player#][mame axis#] array */

static int mouse_delta_axis[OSD_MAX_JOY_ANALOG][MAX_ANALOG_AXES];
static int lightgun_delta_axis[OSD_MAX_JOY_ANALOG][MAX_ANALOG_AXES];
static int analog_current_axis[OSD_MAX_JOY_ANALOG][MAX_ANALOG_AXES];
static int analog_previous_axis[OSD_MAX_JOY_ANALOG][MAX_ANALOG_AXES];

#if 0
static int mouse_delta_x[OSD_MAX_JOY_ANALOG], mouse_delta_y[OSD_MAX_JOY_ANALOG];			/* replaced by mouse_delta_axis[][] */
static int lightgun_delta_x[OSD_MAX_JOY_ANALOG], lightgun_delta_y[OSD_MAX_JOY_ANALOG];			/* replaced by lightgun_delta_axis[][] */
static int analog_current_x[OSD_MAX_JOY_ANALOG], analog_current_y[OSD_MAX_JOY_ANALOG];		/* replaced by analog_current_axis[][] */
static int analog_previous_x[OSD_MAX_JOY_ANALOG], analog_previous_y[OSD_MAX_JOY_ANALOG];	/* replaced by analog_previous_axis[][] */
#endif

/***************************************************************************

  Configuration load/save

***************************************************************************/

/* this must match the enum in inptport.h */
const char ipdn_defaultstrings[][MAX_DEFSTR_LEN] =
{
	"Off",
	"On",
	"No",
	"Yes",
	"Lives",
	"Bonus Life",
	"Difficulty",
	"Demo Sounds",
	"Coinage",
	"Coin A",
	"Coin B",
	"9 Coins/1 Credit",
	"8 Coins/1 Credit",
	"7 Coins/1 Credit",
	"6 Coins/1 Credit",
	"5 Coins/1 Credit",
	"4 Coins/1 Credit",
	"3 Coins/1 Credit",
	"8 Coins/3 Credits",
	"4 Coins/2 Credits",
	"2 Coins/1 Credit",
	"5 Coins/3 Credits",
	"3 Coins/2 Credits",
	"4 Coins/3 Credits",
	"4 Coins/4 Credits",
	"3 Coins/3 Credits",
	"2 Coins/2 Credits",
	"1 Coin/1 Credit",
	"4 Coins/5 Credits",
	"3 Coins/4 Credits",
	"2 Coins/3 Credits",
	"4 Coins/7 Credits",
	"2 Coins/4 Credits",
	"1 Coin/2 Credits",
	"2 Coins/5 Credits",
	"2 Coins/6 Credits",
	"1 Coin/3 Credits",
	"2 Coins/7 Credits",
	"2 Coins/8 Credits",
	"1 Coin/4 Credits",
	"1 Coin/5 Credits",
	"1 Coin/6 Credits",
	"1 Coin/7 Credits",
	"1 Coin/8 Credits",
	"1 Coin/9 Credits",
	"Free Play",
	"Cabinet",
	"Upright",
	"Cocktail",
	"Flip Screen",
	"Service Mode",
	"Unused",
	"Unknown"
};

struct ipd inputport_defaults[] =
{
	{ IPT_UI_CONFIGURE,         "Config Menu",			SEQ_DEF_1(KEYCODE_TAB) },
	{ IPT_UI_ON_SCREEN_DISPLAY, "On Screen Display",	SEQ_DEF_1(KEYCODE_TILDE) },
	{ IPT_UI_PAUSE,             "Pause",				SEQ_DEF_1(KEYCODE_P) },
	{ IPT_UI_RESET_MACHINE,     "Reset Game",			SEQ_DEF_1(KEYCODE_F3) },
	{ IPT_UI_SHOW_GFX,          "Show Gfx",				SEQ_DEF_1(KEYCODE_F4) },
	{ IPT_UI_FRAMESKIP_DEC,     "Frameskip Dec",		SEQ_DEF_1(KEYCODE_F8) },
	{ IPT_UI_FRAMESKIP_INC,     "Frameskip Inc",		SEQ_DEF_1(KEYCODE_F9) },
	{ IPT_UI_THROTTLE,          "Throttle",				SEQ_DEF_1(KEYCODE_F10) },
	{ IPT_UI_SHOW_FPS,          "Show FPS",				SEQ_DEF_5(KEYCODE_F11, CODE_NOT, KEYCODE_LCONTROL, CODE_NOT, KEYCODE_LSHIFT) },
	{ IPT_UI_SHOW_PROFILER,     "Show Profiler",		SEQ_DEF_2(KEYCODE_F11, KEYCODE_LSHIFT) },
#ifdef MESS
	{ IPT_UI_TOGGLE_UI,         "UI Toggle",			SEQ_DEF_1(KEYCODE_SCRLOCK) },
#endif
#ifdef KAILLERA
	{ IPT_UI_CHAT_OPEN,	    "Kaillera Chat Open", SEQ_DEF_1(KEYCODE_T) },
	{ IPT_UI_CHAT_CHANGE_BG,    "Kaillera Chat Change BG Color", SEQ_DEF_1(KEYCODE_HOME) },
      { IPT_UI_TOGGLE_AUTOSAVE,   "Toggle Auto Save",        SEQ_DEF_1(KEYCODE_F9) },
      { IPT_UI_LOAD_AUTOSAVE,     "Load Auto Save State",       SEQ_DEF_1(KEYCODE_F8) },
	{ IPT_UI_SEND_DIP,	    "Send Dipswitch Settings",	SEQ_DEF_2(KEYCODE_F10, KEYCODE_LSHIFT) },
	{ IPT_UI_VERSION,		    "Version Check",		SEQ_DEF_2(KEYCODE_F10, KEYCODE_RSHIFT) },
      { IPT_UI_P1_SHIFT_DOWN,     "P1 Shift Down",      SEQ_DEF_2(KEYCODE_F6, KEYCODE_LSHIFT) },
      { IPT_UI_P1_SHIFT_UP,       "P1 Shift Up",      SEQ_DEF_2(KEYCODE_F5, KEYCODE_LSHIFT) },
      { IPT_UI_SWAP_CONTROL,      "Swap Player Controls",     SEQ_DEF_3(CODE_NOT, KEYCODE_LSHIFT, KEYCODE_F5) }, 
#endif /* KAILLERA */
	{ IPT_UI_SNAPSHOT,          "Save Snapshot",		SEQ_DEF_1(KEYCODE_F12) },
	{ IPT_UI_TOGGLE_CHEAT,      "Toggle Cheat",			SEQ_DEF_1(KEYCODE_F6) },
	{ IPT_UI_UP,                "UI Up",				SEQ_DEF_3(KEYCODE_UP, CODE_OR, JOYCODE_1_UP) },
	{ IPT_UI_DOWN,              "UI Down",				SEQ_DEF_3(KEYCODE_DOWN, CODE_OR, JOYCODE_1_DOWN) },
	{ IPT_UI_LEFT,              "UI Left",				SEQ_DEF_3(KEYCODE_LEFT, CODE_OR, JOYCODE_1_LEFT) },
	{ IPT_UI_RIGHT,             "UI Right",				SEQ_DEF_3(KEYCODE_RIGHT, CODE_OR, JOYCODE_1_RIGHT) },
	{ IPT_UI_SELECT,            "UI Select",			SEQ_DEF_3(KEYCODE_ENTER, CODE_OR, JOYCODE_1_BUTTON1) },
	{ IPT_UI_CANCEL,            "UI Cancel",			SEQ_DEF_1(KEYCODE_ESC) },
	{ IPT_UI_PAN_UP,            "Pan Up",				SEQ_DEF_3(KEYCODE_PGUP, CODE_NOT, KEYCODE_LSHIFT) },
	{ IPT_UI_PAN_DOWN,          "Pan Down",				SEQ_DEF_3(KEYCODE_PGDN, CODE_NOT, KEYCODE_LSHIFT) },
	{ IPT_UI_PAN_LEFT,          "Pan Left",				SEQ_DEF_2(KEYCODE_PGUP, KEYCODE_LSHIFT) },
	{ IPT_UI_PAN_RIGHT,         "Pan Right",			SEQ_DEF_2(KEYCODE_PGDN, KEYCODE_LSHIFT) },
	{ IPT_UI_TOGGLE_DEBUG,      "Toggle Debugger",		SEQ_DEF_1(KEYCODE_F5) },
	{ IPT_UI_SAVE_STATE,        "Save State",			SEQ_DEF_2(KEYCODE_F7, KEYCODE_LSHIFT) },
	{ IPT_UI_LOAD_STATE,        "Load State",			SEQ_DEF_3(KEYCODE_F7, CODE_NOT, KEYCODE_LSHIFT) },
	{ IPT_UI_ADD_CHEAT,			"Add Cheat",			SEQ_DEF_1(KEYCODE_A) },
	{ IPT_UI_DELETE_CHEAT,		"Delete Cheat",			SEQ_DEF_1(KEYCODE_D) },
	{ IPT_UI_SAVE_CHEAT,		"Save Cheat",			SEQ_DEF_1(KEYCODE_S) },
	{ IPT_UI_WATCH_VALUE,		"Watch Value",			SEQ_DEF_1(KEYCODE_W) },
	{ IPT_UI_EDIT_CHEAT,		"Edit Cheat",			SEQ_DEF_1(KEYCODE_E) },
	{ IPT_UI_TOGGLE_CROSSHAIR,	"Toggle Crosshair",		SEQ_DEF_1(KEYCODE_F1) },
	{ IPT_START1, "1 Player Start",  SEQ_DEF_3(KEYCODE_1, CODE_OR, JOYCODE_1_START) },
	{ IPT_START2, "2 Players Start", SEQ_DEF_3(KEYCODE_2, CODE_OR, JOYCODE_2_START) },
	{ IPT_START3, "3 Players Start", SEQ_DEF_3(KEYCODE_3, CODE_OR, JOYCODE_3_START) },
	{ IPT_START4, "4 Players Start", SEQ_DEF_3(KEYCODE_4, CODE_OR, JOYCODE_4_START) },
	{ IPT_COIN1,  "Coin 1",          SEQ_DEF_3(KEYCODE_5, CODE_OR, JOYCODE_1_SELECT) },
	{ IPT_COIN2,  "Coin 2",          SEQ_DEF_3(KEYCODE_6, CODE_OR, JOYCODE_2_SELECT) },
	{ IPT_COIN3,  "Coin 3",          SEQ_DEF_3(KEYCODE_7, CODE_OR, JOYCODE_3_SELECT) },
	{ IPT_COIN4,  "Coin 4",          SEQ_DEF_3(KEYCODE_8, CODE_OR, JOYCODE_4_SELECT) },
	{ IPT_SERVICE1, "Service 1",     SEQ_DEF_1(KEYCODE_9) },
	{ IPT_SERVICE2, "Service 2",     SEQ_DEF_1(KEYCODE_0) },
	{ IPT_SERVICE3, "Service 3",     SEQ_DEF_1(KEYCODE_MINUS) },
	{ IPT_SERVICE4, "Service 4",     SEQ_DEF_1(KEYCODE_EQUALS) },
#ifndef MESS
	{ IPT_TILT,   "Tilt",            SEQ_DEF_1(KEYCODE_T) },
#else
	{ IPT_TILT,   "Tilt",            SEQ_DEF_0 },
#endif

	{ IPT_JOYSTICK_UP         | IPF_PLAYER1, "P1 Up",          SEQ_DEF_3(KEYCODE_UP, CODE_OR, JOYCODE_1_UP)    },
	{ IPT_JOYSTICK_DOWN       | IPF_PLAYER1, "P1 Down",        SEQ_DEF_3(KEYCODE_DOWN, CODE_OR, JOYCODE_1_DOWN)  },
	{ IPT_JOYSTICK_LEFT       | IPF_PLAYER1, "P1 Left",        SEQ_DEF_3(KEYCODE_LEFT, CODE_OR, JOYCODE_1_LEFT)  },
	{ IPT_JOYSTICK_RIGHT      | IPF_PLAYER1, "P1 Right",       SEQ_DEF_3(KEYCODE_RIGHT, CODE_OR, JOYCODE_1_RIGHT) },
	{ IPT_BUTTON1             | IPF_PLAYER1, "P1 Button 1",    SEQ_DEF_5(KEYCODE_LCONTROL, CODE_OR, JOYCODE_1_BUTTON1, CODE_OR, JOYCODE_MOUSE_1_BUTTON1) },
	{ IPT_BUTTON2             | IPF_PLAYER1, "P1 Button 2",    SEQ_DEF_5(KEYCODE_LALT, CODE_OR, JOYCODE_1_BUTTON2, CODE_OR, JOYCODE_MOUSE_1_BUTTON3) },
	{ IPT_BUTTON3             | IPF_PLAYER1, "P1 Button 3",    SEQ_DEF_5(KEYCODE_SPACE, CODE_OR, JOYCODE_1_BUTTON3, CODE_OR, JOYCODE_MOUSE_1_BUTTON2) },
	{ IPT_BUTTON4             | IPF_PLAYER1, "P1 Button 4",    SEQ_DEF_3(KEYCODE_LSHIFT, CODE_OR, JOYCODE_1_BUTTON4) },
	{ IPT_BUTTON5             | IPF_PLAYER1, "P1 Button 5",    SEQ_DEF_3(KEYCODE_Z, CODE_OR, JOYCODE_1_BUTTON5) },
	{ IPT_BUTTON6             | IPF_PLAYER1, "P1 Button 6",    SEQ_DEF_3(KEYCODE_X, CODE_OR, JOYCODE_1_BUTTON6) },
	{ IPT_BUTTON7             | IPF_PLAYER1, "P1 Button 7",    SEQ_DEF_1(KEYCODE_C) },
	{ IPT_BUTTON8             | IPF_PLAYER1, "P1 Button 8",    SEQ_DEF_1(KEYCODE_V) },
	{ IPT_BUTTON9             | IPF_PLAYER1, "P1 Button 9",    SEQ_DEF_1(KEYCODE_B) },
	{ IPT_BUTTON10            | IPF_PLAYER1, "P1 Button 10",   SEQ_DEF_1(KEYCODE_N) },
#ifdef KAILLERA
	{ IPT_3KICKS              | IPF_PLAYER1, "P1 3 Kicks",     SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_3PUNCHES            | IPF_PLAYER1, "P1 3 Punches",   SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_SPEC1               | IPF_PLAYER1, "P1 Special Atk1", SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_SPEC2               | IPF_PLAYER1, "P1 Special Atk2", SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_SPEC3               | IPF_PLAYER1, "P1 Special Atk3", SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_AB                  | IPF_PLAYER1, "P1 A+B (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_CD                  | IPF_PLAYER1, "P1 C+D (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_BC                  | IPF_PLAYER1, "P1 B+C (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_AC                  | IPF_PLAYER1, "P1 A+C (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_BD                  | IPF_PLAYER1, "P1 B+D (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_ABC                 | IPF_PLAYER1, "P1 A+B+C (NG)",  SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_BCD                 | IPF_PLAYER1, "P1 B+C+D (NG)",  SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_ABCD                | IPF_PLAYER1, "P1 A+B+C+D (NG)",  SEQ_DEF_1(KEYCODE_NONE) },
#endif
	{ IPT_JOYSTICKRIGHT_UP    | IPF_PLAYER1, "P1 Right/Up",    SEQ_DEF_3(KEYCODE_I, CODE_OR, JOYCODE_1_BUTTON2) },
	{ IPT_JOYSTICKRIGHT_DOWN  | IPF_PLAYER1, "P1 Right/Down",  SEQ_DEF_3(KEYCODE_K, CODE_OR, JOYCODE_1_BUTTON3) },
	{ IPT_JOYSTICKRIGHT_LEFT  | IPF_PLAYER1, "P1 Right/Left",  SEQ_DEF_3(KEYCODE_J, CODE_OR, JOYCODE_1_BUTTON1) },
	{ IPT_JOYSTICKRIGHT_RIGHT | IPF_PLAYER1, "P1 Right/Right", SEQ_DEF_3(KEYCODE_L, CODE_OR, JOYCODE_1_BUTTON4) },
	{ IPT_JOYSTICKLEFT_UP     | IPF_PLAYER1, "P1 Left/Up",     SEQ_DEF_3(KEYCODE_E, CODE_OR, JOYCODE_1_UP) },
	{ IPT_JOYSTICKLEFT_DOWN   | IPF_PLAYER1, "P1 Left/Down",   SEQ_DEF_3(KEYCODE_D, CODE_OR, JOYCODE_1_DOWN) },
	{ IPT_JOYSTICKLEFT_LEFT   | IPF_PLAYER1, "P1 Left/Left",   SEQ_DEF_3(KEYCODE_S, CODE_OR, JOYCODE_1_LEFT) },
	{ IPT_JOYSTICKLEFT_RIGHT  | IPF_PLAYER1, "P1 Left/Right",  SEQ_DEF_3(KEYCODE_F, CODE_OR, JOYCODE_1_RIGHT) },

	{ IPT_JOYSTICK_UP         | IPF_PLAYER2, "P2 Up",          SEQ_DEF_3(KEYCODE_R, CODE_OR, JOYCODE_2_UP)    },
	{ IPT_JOYSTICK_DOWN       | IPF_PLAYER2, "P2 Down",        SEQ_DEF_3(KEYCODE_F, CODE_OR, JOYCODE_2_DOWN)  },
	{ IPT_JOYSTICK_LEFT       | IPF_PLAYER2, "P2 Left",        SEQ_DEF_3(KEYCODE_D, CODE_OR, JOYCODE_2_LEFT)  },
	{ IPT_JOYSTICK_RIGHT      | IPF_PLAYER2, "P2 Right",       SEQ_DEF_3(KEYCODE_G, CODE_OR, JOYCODE_2_RIGHT) },
	{ IPT_BUTTON1             | IPF_PLAYER2, "P2 Button 1",    SEQ_DEF_3(KEYCODE_A, CODE_OR, JOYCODE_2_BUTTON1) },
	{ IPT_BUTTON2             | IPF_PLAYER2, "P2 Button 2",    SEQ_DEF_3(KEYCODE_S, CODE_OR, JOYCODE_2_BUTTON2) },
	{ IPT_BUTTON3             | IPF_PLAYER2, "P2 Button 3",    SEQ_DEF_3(KEYCODE_Q, CODE_OR, JOYCODE_2_BUTTON3) },
	{ IPT_BUTTON4             | IPF_PLAYER2, "P2 Button 4",    SEQ_DEF_3(KEYCODE_W, CODE_OR, JOYCODE_2_BUTTON4) },
	{ IPT_BUTTON5             | IPF_PLAYER2, "P2 Button 5",    SEQ_DEF_1(JOYCODE_2_BUTTON5) },
	{ IPT_BUTTON6             | IPF_PLAYER2, "P2 Button 6",    SEQ_DEF_1(JOYCODE_2_BUTTON6) },
	{ IPT_BUTTON7             | IPF_PLAYER2, "P2 Button 7",    SEQ_DEF_0 },
	{ IPT_BUTTON8             | IPF_PLAYER2, "P2 Button 8",    SEQ_DEF_0 },
	{ IPT_BUTTON9             | IPF_PLAYER2, "P2 Button 9",    SEQ_DEF_0 },
	{ IPT_BUTTON10            | IPF_PLAYER2, "P2 Button 10",   SEQ_DEF_0 },
#ifdef KAILLERA
	{ IPT_3KICKS              | IPF_PLAYER2, "P2 3 Kicks",     SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_3PUNCHES            | IPF_PLAYER2, "P2 3 Punches",   SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_SPEC1               | IPF_PLAYER2, "P2 Special Atk1", SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_SPEC2               | IPF_PLAYER2, "P2 Special Atk2", SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_SPEC3               | IPF_PLAYER2, "P2 Special Atk3", SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_AB                  | IPF_PLAYER2, "P2 A+B (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_CD                  | IPF_PLAYER2, "P2 C+D (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_BC                  | IPF_PLAYER2, "P2 B+C (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_AC                  | IPF_PLAYER2, "P2 A+C (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_BD                  | IPF_PLAYER2, "P2 B+D (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_ABC                 | IPF_PLAYER2, "P2 A+B+C (NG)",  SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_BCD                 | IPF_PLAYER2, "P2 B+C+D (NG)",  SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_ABCD                | IPF_PLAYER2, "P2 A+B+C+D (NG)",  SEQ_DEF_1(KEYCODE_NONE) },
#endif
	{ IPT_JOYSTICKRIGHT_UP    | IPF_PLAYER2, "P2 Right/Up",    SEQ_DEF_0 },
	{ IPT_JOYSTICKRIGHT_DOWN  | IPF_PLAYER2, "P2 Right/Down",  SEQ_DEF_0 },
	{ IPT_JOYSTICKRIGHT_LEFT  | IPF_PLAYER2, "P2 Right/Left",  SEQ_DEF_0 },
	{ IPT_JOYSTICKRIGHT_RIGHT | IPF_PLAYER2, "P2 Right/Right", SEQ_DEF_0 },
	{ IPT_JOYSTICKLEFT_UP     | IPF_PLAYER2, "P2 Left/Up",     SEQ_DEF_0 },
	{ IPT_JOYSTICKLEFT_DOWN   | IPF_PLAYER2, "P2 Left/Down",   SEQ_DEF_0 },
	{ IPT_JOYSTICKLEFT_LEFT   | IPF_PLAYER2, "P2 Left/Left",   SEQ_DEF_0 },
	{ IPT_JOYSTICKLEFT_RIGHT  | IPF_PLAYER2, "P2 Left/Right",  SEQ_DEF_0 },

	{ IPT_JOYSTICK_UP         | IPF_PLAYER3, "P3 Up",          SEQ_DEF_3(KEYCODE_I, CODE_OR, JOYCODE_3_UP)    },
	{ IPT_JOYSTICK_DOWN       | IPF_PLAYER3, "P3 Down",        SEQ_DEF_3(KEYCODE_K, CODE_OR, JOYCODE_3_DOWN)  },
	{ IPT_JOYSTICK_LEFT       | IPF_PLAYER3, "P3 Left",        SEQ_DEF_3(KEYCODE_J, CODE_OR, JOYCODE_3_LEFT)  },
	{ IPT_JOYSTICK_RIGHT      | IPF_PLAYER3, "P3 Right",       SEQ_DEF_3(KEYCODE_L, CODE_OR, JOYCODE_3_RIGHT) },
	{ IPT_BUTTON1             | IPF_PLAYER3, "P3 Button 1",    SEQ_DEF_3(KEYCODE_RCONTROL, CODE_OR, JOYCODE_3_BUTTON1) },
	{ IPT_BUTTON2             | IPF_PLAYER3, "P3 Button 2",    SEQ_DEF_3(KEYCODE_RSHIFT, CODE_OR, JOYCODE_3_BUTTON2) },
	{ IPT_BUTTON3             | IPF_PLAYER3, "P3 Button 3",    SEQ_DEF_3(KEYCODE_ENTER, CODE_OR, JOYCODE_3_BUTTON3) },
	{ IPT_BUTTON4             | IPF_PLAYER3, "P3 Button 4",    SEQ_DEF_1(JOYCODE_3_BUTTON4) },
#ifdef KAILLERA
	{ IPT_BUTTON5             | IPF_PLAYER3, "P3 Button 5",    SEQ_DEF_1(JOYCODE_3_BUTTON5) },
	{ IPT_BUTTON6             | IPF_PLAYER3, "P3 Button 6",    SEQ_DEF_1(JOYCODE_3_BUTTON6) },
	{ IPT_BUTTON7             | IPF_PLAYER3, "P3 Button 7",    SEQ_DEF_0 },
	{ IPT_BUTTON8             | IPF_PLAYER3, "P3 Button 8",    SEQ_DEF_0 },
	{ IPT_BUTTON9             | IPF_PLAYER3, "P3 Button 9",    SEQ_DEF_0 },
	{ IPT_BUTTON10            | IPF_PLAYER3, "P3 Button 10",   SEQ_DEF_0 },
	{ IPT_3KICKS              | IPF_PLAYER3, "P3 3 Kicks",     SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_3PUNCHES            | IPF_PLAYER3, "P3 3 Punches",   SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_SPEC1               | IPF_PLAYER3, "P3 Special Atk1", SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_SPEC2               | IPF_PLAYER3, "P3 Special Atk2", SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_SPEC3               | IPF_PLAYER3, "P3 Special Atk3", SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_AB                  | IPF_PLAYER3, "P3 A+B (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_CD                  | IPF_PLAYER3, "P3 C+D (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_BC                  | IPF_PLAYER3, "P3 B+C (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_AC                  | IPF_PLAYER3, "P3 A+C (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_BD                  | IPF_PLAYER3, "P3 B+D (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_ABC                 | IPF_PLAYER3, "P3 A+B+C (NG)",  SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_BCD                 | IPF_PLAYER3, "P3 B+C+D (NG)",  SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_ABCD                | IPF_PLAYER3, "P3 A+B+C+D (NG)",  SEQ_DEF_1(KEYCODE_NONE) },
#endif

	{ IPT_JOYSTICK_UP         | IPF_PLAYER4, "P4 Up",          SEQ_DEF_1(JOYCODE_4_UP) },
	{ IPT_JOYSTICK_DOWN       | IPF_PLAYER4, "P4 Down",        SEQ_DEF_1(JOYCODE_4_DOWN) },
	{ IPT_JOYSTICK_LEFT       | IPF_PLAYER4, "P4 Left",        SEQ_DEF_1(JOYCODE_4_LEFT) },
	{ IPT_JOYSTICK_RIGHT      | IPF_PLAYER4, "P4 Right",       SEQ_DEF_1(JOYCODE_4_RIGHT) },
	{ IPT_BUTTON1             | IPF_PLAYER4, "P4 Button 1",    SEQ_DEF_1(JOYCODE_4_BUTTON1) },
	{ IPT_BUTTON2             | IPF_PLAYER4, "P4 Button 2",    SEQ_DEF_1(JOYCODE_4_BUTTON2) },
	{ IPT_BUTTON3             | IPF_PLAYER4, "P4 Button 3",    SEQ_DEF_1(JOYCODE_4_BUTTON3) },
	{ IPT_BUTTON4             | IPF_PLAYER4, "P4 Button 4",    SEQ_DEF_1(JOYCODE_4_BUTTON4) },
#ifdef KAILLERA
	{ IPT_BUTTON5             | IPF_PLAYER4, "P4 Button 5",    SEQ_DEF_1(JOYCODE_4_BUTTON5) },
	{ IPT_BUTTON6             | IPF_PLAYER4, "P4 Button 6",    SEQ_DEF_1(JOYCODE_4_BUTTON6) },
	{ IPT_BUTTON7             | IPF_PLAYER4, "P4 Button 7",    SEQ_DEF_0 },
	{ IPT_BUTTON8             | IPF_PLAYER4, "P4 Button 8",    SEQ_DEF_0 },
	{ IPT_BUTTON9             | IPF_PLAYER4, "P4 Button 9",    SEQ_DEF_0 },
	{ IPT_BUTTON10            | IPF_PLAYER4, "P4 Button 10",   SEQ_DEF_0 },
	{ IPT_3KICKS              | IPF_PLAYER4, "P4 3 Kicks",     SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_3PUNCHES            | IPF_PLAYER4, "P4 3 Punches",   SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_SPEC1               | IPF_PLAYER4, "P4 Special Atk1", SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_SPEC2               | IPF_PLAYER4, "P4 Special Atk2", SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_SPEC3               | IPF_PLAYER4, "P4 Special Atk3", SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_AB                  | IPF_PLAYER4, "P4 A+B (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_CD                  | IPF_PLAYER4, "P4 C+D (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_BC                  | IPF_PLAYER4, "P4 B+C (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_AC                  | IPF_PLAYER4, "P4 A+C (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_BD                  | IPF_PLAYER4, "P4 B+D (NG)",    SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_ABC                 | IPF_PLAYER4, "P4 A+B+C (NG)",  SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_BCD                 | IPF_PLAYER4, "P4 B+C+D (NG)",  SEQ_DEF_1(KEYCODE_NONE) },
	{ IPT_ABCD                | IPF_PLAYER4, "P4 A+B+C+D (NG)",  SEQ_DEF_1(KEYCODE_NONE) },
#endif

	{ IPT_PEDAL	                | IPF_PLAYER1, "P1 Pedal 1",     SEQ_DEF_3(KEYCODE_LCONTROL, CODE_OR, JOYCODE_1_BUTTON1) },
	{ (IPT_PEDAL+IPT_EXTENSION) | IPF_PLAYER1, "P1 Auto Release <Y/N>", SEQ_DEF_1(KEYCODE_Y) },
	{ IPT_PEDAL                 | IPF_PLAYER2, "P2 Pedal 1",     SEQ_DEF_3(KEYCODE_A, CODE_OR, JOYCODE_2_BUTTON1) },
	{ (IPT_PEDAL+IPT_EXTENSION) | IPF_PLAYER2, "P2 Auto Release <Y/N>", SEQ_DEF_1(KEYCODE_Y) },
	{ IPT_PEDAL                 | IPF_PLAYER3, "P3 Pedal 1",     SEQ_DEF_3(KEYCODE_RCONTROL, CODE_OR, JOYCODE_3_BUTTON1) },
	{ (IPT_PEDAL+IPT_EXTENSION) | IPF_PLAYER3, "P3 Auto Release <Y/N>", SEQ_DEF_1(KEYCODE_Y) },
	{ IPT_PEDAL                 | IPF_PLAYER4, "P4 Pedal 1",     SEQ_DEF_1(JOYCODE_4_BUTTON1) },
	{ (IPT_PEDAL+IPT_EXTENSION) | IPF_PLAYER4, "P4 Auto Release <Y/N>", SEQ_DEF_1(KEYCODE_Y) },

	{ IPT_PEDAL2	             | IPF_PLAYER1, "P1 Pedal 2",    SEQ_DEF_1(JOYCODE_1_DOWN) },
	{ (IPT_PEDAL2+IPT_EXTENSION) | IPF_PLAYER1, "P1 Auto Release <Y/N>", SEQ_DEF_1(KEYCODE_Y) },
	{ IPT_PEDAL2                 | IPF_PLAYER2, "P2 Pedal 2",    SEQ_DEF_1(JOYCODE_2_DOWN) },
	{ (IPT_PEDAL2+IPT_EXTENSION) | IPF_PLAYER2, "P2 Auto Release <Y/N>", SEQ_DEF_1(KEYCODE_Y) },
	{ IPT_PEDAL2                 | IPF_PLAYER3, "P3 Pedal 2",    SEQ_DEF_1(JOYCODE_3_DOWN) },
	{ (IPT_PEDAL2+IPT_EXTENSION) | IPF_PLAYER3, "P3 Auto Release <Y/N>", SEQ_DEF_1(KEYCODE_Y) },
	{ IPT_PEDAL2                 | IPF_PLAYER4, "P4 Pedal 2",    SEQ_DEF_1(JOYCODE_4_DOWN) },
	{ (IPT_PEDAL2+IPT_EXTENSION) | IPF_PLAYER4, "P4 Auto Release <Y/N>", SEQ_DEF_1(KEYCODE_Y) },

	{ IPT_PADDLE | IPF_PLAYER1,  "Paddle",        SEQ_DEF_3(KEYCODE_LEFT, CODE_OR, JOYCODE_1_LEFT) },
	{ (IPT_PADDLE | IPF_PLAYER1)+IPT_EXTENSION,             "Paddle",        SEQ_DEF_3(KEYCODE_RIGHT, CODE_OR, JOYCODE_1_RIGHT)  },
	{ IPT_PADDLE | IPF_PLAYER2,  "Paddle 2",      SEQ_DEF_3(KEYCODE_D, CODE_OR, JOYCODE_2_LEFT) },
	{ (IPT_PADDLE | IPF_PLAYER2)+IPT_EXTENSION,             "Paddle 2",      SEQ_DEF_3(KEYCODE_G, CODE_OR, JOYCODE_2_RIGHT) },
	{ IPT_PADDLE | IPF_PLAYER3,  "Paddle 3",      SEQ_DEF_3(KEYCODE_J, CODE_OR, JOYCODE_3_LEFT) },
	{ (IPT_PADDLE | IPF_PLAYER3)+IPT_EXTENSION,             "Paddle 3",      SEQ_DEF_3(KEYCODE_L, CODE_OR, JOYCODE_3_RIGHT) },
	{ IPT_PADDLE | IPF_PLAYER4,  "Paddle 4",      SEQ_DEF_1(JOYCODE_4_LEFT) },
	{ (IPT_PADDLE | IPF_PLAYER4)+IPT_EXTENSION,             "Paddle 4",      SEQ_DEF_1(JOYCODE_4_RIGHT) },
	{ IPT_PADDLE_V | IPF_PLAYER1,  "Paddle V",          SEQ_DEF_3(KEYCODE_UP, CODE_OR, JOYCODE_1_UP) },
	{ (IPT_PADDLE_V | IPF_PLAYER1)+IPT_EXTENSION,             "Paddle V",          SEQ_DEF_3(KEYCODE_DOWN, CODE_OR, JOYCODE_1_DOWN) },
	{ IPT_PADDLE_V | IPF_PLAYER2,  "Paddle V 2",        SEQ_DEF_3(KEYCODE_R, CODE_OR, JOYCODE_2_UP) },
	{ (IPT_PADDLE_V | IPF_PLAYER2)+IPT_EXTENSION,             "Paddle V 2",      SEQ_DEF_3(KEYCODE_F, CODE_OR, JOYCODE_2_DOWN) },
	{ IPT_PADDLE_V | IPF_PLAYER3,  "Paddle V 3",        SEQ_DEF_3(KEYCODE_I, CODE_OR, JOYCODE_3_UP) },
	{ (IPT_PADDLE_V | IPF_PLAYER3)+IPT_EXTENSION,             "Paddle V 3",      SEQ_DEF_3(KEYCODE_K, CODE_OR, JOYCODE_3_DOWN) },
	{ IPT_PADDLE_V | IPF_PLAYER4,  "Paddle V 4",        SEQ_DEF_1(JOYCODE_4_UP) },
	{ (IPT_PADDLE_V | IPF_PLAYER4)+IPT_EXTENSION,             "Paddle V 4",      SEQ_DEF_1(JOYCODE_4_DOWN) },
	{ IPT_DIAL | IPF_PLAYER1,    "Dial",          SEQ_DEF_3(KEYCODE_LEFT, CODE_OR, JOYCODE_1_LEFT) },
	{ (IPT_DIAL | IPF_PLAYER1)+IPT_EXTENSION,               "Dial",          SEQ_DEF_3(KEYCODE_RIGHT, CODE_OR, JOYCODE_1_RIGHT) },
	{ IPT_DIAL | IPF_PLAYER2,    "Dial 2",        SEQ_DEF_3(KEYCODE_D, CODE_OR, JOYCODE_2_LEFT) },
	{ (IPT_DIAL | IPF_PLAYER2)+IPT_EXTENSION,               "Dial 2",      SEQ_DEF_3(KEYCODE_G, CODE_OR, JOYCODE_2_RIGHT) },
	{ IPT_DIAL | IPF_PLAYER3,    "Dial 3",        SEQ_DEF_3(KEYCODE_J, CODE_OR, JOYCODE_3_LEFT) },
	{ (IPT_DIAL | IPF_PLAYER3)+IPT_EXTENSION,               "Dial 3",      SEQ_DEF_3(KEYCODE_L, CODE_OR, JOYCODE_3_RIGHT) },
	{ IPT_DIAL | IPF_PLAYER4,    "Dial 4",        SEQ_DEF_1(JOYCODE_4_LEFT) },
	{ (IPT_DIAL | IPF_PLAYER4)+IPT_EXTENSION,               "Dial 4",      SEQ_DEF_1(JOYCODE_4_RIGHT) },
	{ IPT_DIAL_V | IPF_PLAYER1,  "Dial V",          SEQ_DEF_3(KEYCODE_UP, CODE_OR, JOYCODE_1_UP) },
	{ (IPT_DIAL_V | IPF_PLAYER1)+IPT_EXTENSION,             "Dial V",          SEQ_DEF_3(KEYCODE_DOWN, CODE_OR, JOYCODE_1_DOWN) },
	{ IPT_DIAL_V | IPF_PLAYER2,  "Dial V 2",        SEQ_DEF_3(KEYCODE_R, CODE_OR, JOYCODE_2_UP) },
	{ (IPT_DIAL_V | IPF_PLAYER2)+IPT_EXTENSION,             "Dial V 2",      SEQ_DEF_3(KEYCODE_F, CODE_OR, JOYCODE_2_DOWN) },
	{ IPT_DIAL_V | IPF_PLAYER3,  "Dial V 3",        SEQ_DEF_3(KEYCODE_I, CODE_OR, JOYCODE_3_UP) },
	{ (IPT_DIAL_V | IPF_PLAYER3)+IPT_EXTENSION,             "Dial V 3",      SEQ_DEF_3(KEYCODE_K, CODE_OR, JOYCODE_3_DOWN) },
	{ IPT_DIAL_V | IPF_PLAYER4,  "Dial V 4",        SEQ_DEF_1(JOYCODE_4_UP) },
	{ (IPT_DIAL_V | IPF_PLAYER4)+IPT_EXTENSION,             "Dial V 4",      SEQ_DEF_1(JOYCODE_4_DOWN) },

	{ IPT_TRACKBALL_X | IPF_PLAYER1, "Track X",   SEQ_DEF_3(KEYCODE_LEFT, CODE_OR, JOYCODE_1_LEFT) },
	{ (IPT_TRACKBALL_X | IPF_PLAYER1)+IPT_EXTENSION,                 "Track X",   SEQ_DEF_3(KEYCODE_RIGHT, CODE_OR, JOYCODE_1_RIGHT) },
	{ IPT_TRACKBALL_X | IPF_PLAYER2, "Track X 2", SEQ_DEF_3(KEYCODE_D, CODE_OR, JOYCODE_2_LEFT) },
	{ (IPT_TRACKBALL_X | IPF_PLAYER2)+IPT_EXTENSION,                 "Track X 2", SEQ_DEF_3(KEYCODE_G, CODE_OR, JOYCODE_2_RIGHT) },
	{ IPT_TRACKBALL_X | IPF_PLAYER3, "Track X 3", SEQ_DEF_3(KEYCODE_J, CODE_OR, JOYCODE_3_LEFT) },
	{ (IPT_TRACKBALL_X | IPF_PLAYER3)+IPT_EXTENSION,                 "Track X 3", SEQ_DEF_3(KEYCODE_L, CODE_OR, JOYCODE_3_RIGHT) },
	{ IPT_TRACKBALL_X | IPF_PLAYER4, "Track X 4", SEQ_DEF_1(JOYCODE_4_LEFT) },
	{ (IPT_TRACKBALL_X | IPF_PLAYER4)+IPT_EXTENSION,                 "Track X 4", SEQ_DEF_1(JOYCODE_4_RIGHT) },

	{ IPT_TRACKBALL_Y | IPF_PLAYER1, "Track Y",   SEQ_DEF_3(KEYCODE_UP, CODE_OR, JOYCODE_1_UP) },
	{ (IPT_TRACKBALL_Y | IPF_PLAYER1)+IPT_EXTENSION,                 "Track Y",   SEQ_DEF_3(KEYCODE_DOWN, CODE_OR, JOYCODE_1_DOWN) },
	{ IPT_TRACKBALL_Y | IPF_PLAYER2, "Track Y 2", SEQ_DEF_3(KEYCODE_R, CODE_OR, JOYCODE_2_UP) },
	{ (IPT_TRACKBALL_Y | IPF_PLAYER2)+IPT_EXTENSION,                 "Track Y 2", SEQ_DEF_3(KEYCODE_F, CODE_OR, JOYCODE_2_DOWN) },
	{ IPT_TRACKBALL_Y | IPF_PLAYER3, "Track Y 3", SEQ_DEF_3(KEYCODE_I, CODE_OR, JOYCODE_3_UP) },
	{ (IPT_TRACKBALL_Y | IPF_PLAYER3)+IPT_EXTENSION,                 "Track Y 3", SEQ_DEF_3(KEYCODE_K, CODE_OR, JOYCODE_3_DOWN) },
	{ IPT_TRACKBALL_Y | IPF_PLAYER4, "Track Y 4", SEQ_DEF_1(JOYCODE_4_UP) },
	{ (IPT_TRACKBALL_Y | IPF_PLAYER4)+IPT_EXTENSION,                 "Track Y 4", SEQ_DEF_1(JOYCODE_4_DOWN) },

	{ IPT_AD_STICK_X | IPF_PLAYER1, "AD Stick X",   SEQ_DEF_3(KEYCODE_LEFT, CODE_OR, JOYCODE_1_LEFT) },
	{ (IPT_AD_STICK_X | IPF_PLAYER1)+IPT_EXTENSION,                "AD Stick X",   SEQ_DEF_3(KEYCODE_RIGHT, CODE_OR, JOYCODE_1_RIGHT) },
	{ IPT_AD_STICK_X | IPF_PLAYER2, "AD Stick X 2", SEQ_DEF_3(KEYCODE_D, CODE_OR, JOYCODE_2_LEFT) },
	{ (IPT_AD_STICK_X | IPF_PLAYER2)+IPT_EXTENSION,                "AD Stick X 2", SEQ_DEF_3(KEYCODE_G, CODE_OR, JOYCODE_2_RIGHT) },
	{ IPT_AD_STICK_X | IPF_PLAYER3, "AD Stick X 3", SEQ_DEF_3(KEYCODE_J, CODE_OR, JOYCODE_3_LEFT) },
	{ (IPT_AD_STICK_X | IPF_PLAYER3)+IPT_EXTENSION,                "AD Stick X 3", SEQ_DEF_3(KEYCODE_L, CODE_OR, JOYCODE_3_RIGHT) },
	{ IPT_AD_STICK_X | IPF_PLAYER4, "AD Stick X 4", SEQ_DEF_1(JOYCODE_4_LEFT) },
	{ (IPT_AD_STICK_X | IPF_PLAYER4)+IPT_EXTENSION,                "AD Stick X 4", SEQ_DEF_1(JOYCODE_4_RIGHT) },

	{ IPT_AD_STICK_Y | IPF_PLAYER1, "AD Stick Y",   SEQ_DEF_3(KEYCODE_UP, CODE_OR, JOYCODE_1_UP) },
	{ (IPT_AD_STICK_Y | IPF_PLAYER1)+IPT_EXTENSION,                "AD Stick Y",   SEQ_DEF_3(KEYCODE_DOWN, CODE_OR, JOYCODE_1_DOWN) },
	{ IPT_AD_STICK_Y | IPF_PLAYER2, "AD Stick Y 2", SEQ_DEF_3(KEYCODE_R, CODE_OR, JOYCODE_2_UP) },
	{ (IPT_AD_STICK_Y | IPF_PLAYER2)+IPT_EXTENSION,                "AD Stick Y 2", SEQ_DEF_3(KEYCODE_F, CODE_OR, JOYCODE_2_DOWN) },
	{ IPT_AD_STICK_Y | IPF_PLAYER3, "AD Stick Y 3", SEQ_DEF_3(KEYCODE_I, CODE_OR, JOYCODE_3_UP) },
	{ (IPT_AD_STICK_Y | IPF_PLAYER3)+IPT_EXTENSION,                "AD Stick Y 3", SEQ_DEF_3(KEYCODE_K, CODE_OR, JOYCODE_3_DOWN) },
	{ IPT_AD_STICK_Y | IPF_PLAYER4, "AD Stick Y 4", SEQ_DEF_1(JOYCODE_4_UP) },
	{ (IPT_AD_STICK_Y | IPF_PLAYER4)+IPT_EXTENSION,                "AD Stick Y 4", SEQ_DEF_1(JOYCODE_4_DOWN) },

	{ IPT_AD_STICK_Z | IPF_PLAYER1, "AD Stick Z",   SEQ_DEF_0 },
	{ (IPT_AD_STICK_Z | IPF_PLAYER1)+IPT_EXTENSION,                "AD Stick Z",   SEQ_DEF_0 },
	{ IPT_AD_STICK_Z | IPF_PLAYER2, "AD Stick Z 2", SEQ_DEF_0 },
	{ (IPT_AD_STICK_Z | IPF_PLAYER2)+IPT_EXTENSION,                "AD Stick Z 2", SEQ_DEF_0 },
	{ IPT_AD_STICK_Z | IPF_PLAYER3, "AD Stick Z 3", SEQ_DEF_0 },
	{ (IPT_AD_STICK_Z | IPF_PLAYER3)+IPT_EXTENSION,                "AD Stick Z 3", SEQ_DEF_0 },
	{ IPT_AD_STICK_Z | IPF_PLAYER4, "AD Stick Z 4", SEQ_DEF_0 },
	{ (IPT_AD_STICK_Z | IPF_PLAYER4)+IPT_EXTENSION,                "AD Stick Z 4", SEQ_DEF_0 },

	{ IPT_LIGHTGUN_X | IPF_PLAYER1, "Lightgun X",   SEQ_DEF_3(KEYCODE_LEFT, CODE_OR, JOYCODE_1_LEFT) },
	{ (IPT_LIGHTGUN_X | IPF_PLAYER1)+IPT_EXTENSION,                "Lightgun X",   SEQ_DEF_3(KEYCODE_RIGHT, CODE_OR, JOYCODE_1_RIGHT) },
	{ IPT_LIGHTGUN_X | IPF_PLAYER2, "Lightgun X 2", SEQ_DEF_3(KEYCODE_D, CODE_OR, JOYCODE_2_LEFT) },
	{ (IPT_LIGHTGUN_X | IPF_PLAYER2)+IPT_EXTENSION,                "Lightgun X 2", SEQ_DEF_3(KEYCODE_G, CODE_OR, JOYCODE_2_RIGHT) },
	{ IPT_LIGHTGUN_X | IPF_PLAYER3, "Lightgun X 3", SEQ_DEF_3(KEYCODE_J, CODE_OR, JOYCODE_3_LEFT) },
	{ (IPT_LIGHTGUN_X | IPF_PLAYER3)+IPT_EXTENSION,                "Lightgun X 3", SEQ_DEF_3(KEYCODE_L, CODE_OR, JOYCODE_3_RIGHT) },
	{ IPT_LIGHTGUN_X | IPF_PLAYER4, "Lightgun X 4", SEQ_DEF_1(JOYCODE_4_LEFT) },
	{ (IPT_LIGHTGUN_X | IPF_PLAYER4)+IPT_EXTENSION,                "Lightgun X 4", SEQ_DEF_1(JOYCODE_4_RIGHT) },

	{ IPT_LIGHTGUN_Y | IPF_PLAYER1, "Lightgun Y",   SEQ_DEF_3(KEYCODE_UP, CODE_OR, JOYCODE_1_UP) },
	{ (IPT_LIGHTGUN_Y | IPF_PLAYER1)+IPT_EXTENSION,                "Lightgun Y",   SEQ_DEF_3(KEYCODE_DOWN, CODE_OR, JOYCODE_1_DOWN) },
	{ IPT_LIGHTGUN_Y | IPF_PLAYER2, "Lightgun Y 2", SEQ_DEF_3(KEYCODE_R, CODE_OR, JOYCODE_2_UP) },
	{ (IPT_LIGHTGUN_Y | IPF_PLAYER2)+IPT_EXTENSION,                "Lightgun Y 2", SEQ_DEF_3(KEYCODE_F, CODE_OR, JOYCODE_2_DOWN) },
	{ IPT_LIGHTGUN_Y | IPF_PLAYER3, "Lightgun Y 3", SEQ_DEF_3(KEYCODE_I, CODE_OR, JOYCODE_3_UP) },
	{ (IPT_LIGHTGUN_Y | IPF_PLAYER3)+IPT_EXTENSION,                "Lightgun Y 3", SEQ_DEF_3(KEYCODE_K, CODE_OR, JOYCODE_3_DOWN) },
	{ IPT_LIGHTGUN_Y | IPF_PLAYER4, "Lightgun Y 4", SEQ_DEF_1(JOYCODE_4_UP) },
	{ (IPT_LIGHTGUN_Y | IPF_PLAYER4)+IPT_EXTENSION,                "Lightgun Y 4", SEQ_DEF_1(JOYCODE_4_DOWN) },

	{ IPT_UNKNOWN,             "UNKNOWN",         SEQ_DEF_0 },
	{ IPT_OSD_RESERVED,        "",                SEQ_DEF_0 },
	{ IPT_OSD_RESERVED,        "",                SEQ_DEF_0 },
	{ IPT_OSD_RESERVED,        "",                SEQ_DEF_0 },
	{ IPT_OSD_RESERVED,        "",                SEQ_DEF_0 },
	{ IPT_END,                 0,                 SEQ_DEF_0 }	/* returned when there is no match */
};

struct ipd inputport_defaults_backup[sizeof(inputport_defaults)/sizeof(struct ipd)];


struct ik *osd_input_keywords = NULL;

struct ik input_keywords[] =
{
	{ "KEYCODE_A",		   		IKT_STD,		KEYCODE_A },
	{ "KEYCODE_B",		   		IKT_STD,		KEYCODE_B },
	{ "KEYCODE_C",		   		IKT_STD,		KEYCODE_C },
	{ "KEYCODE_D",		   		IKT_STD,		KEYCODE_D },
	{ "KEYCODE_E",		   		IKT_STD,		KEYCODE_E },
	{ "KEYCODE_F",		   		IKT_STD,		KEYCODE_F },
	{ "KEYCODE_G",		   		IKT_STD,		KEYCODE_G },
	{ "KEYCODE_H",		   		IKT_STD,		KEYCODE_H },
	{ "KEYCODE_I",		   		IKT_STD,		KEYCODE_I },
	{ "KEYCODE_J",		   		IKT_STD,		KEYCODE_J },
	{ "KEYCODE_K",		   		IKT_STD,		KEYCODE_K },
	{ "KEYCODE_L",		   		IKT_STD,		KEYCODE_L },
	{ "KEYCODE_M",		   		IKT_STD,		KEYCODE_M },
	{ "KEYCODE_N",		   		IKT_STD,		KEYCODE_N },
	{ "KEYCODE_O",		   		IKT_STD,		KEYCODE_O },
	{ "KEYCODE_P",		   		IKT_STD,		KEYCODE_P },
	{ "KEYCODE_Q",		   		IKT_STD,		KEYCODE_Q },
	{ "KEYCODE_R",		   		IKT_STD,		KEYCODE_R },
	{ "KEYCODE_S",		   		IKT_STD,		KEYCODE_S },
	{ "KEYCODE_T",		   		IKT_STD,		KEYCODE_T },
	{ "KEYCODE_U",		   		IKT_STD,		KEYCODE_U },
	{ "KEYCODE_V",		   		IKT_STD,		KEYCODE_V },
	{ "KEYCODE_W",		   		IKT_STD,		KEYCODE_W },
	{ "KEYCODE_X",		   		IKT_STD,		KEYCODE_X },
	{ "KEYCODE_Y",		   		IKT_STD,		KEYCODE_Y },
	{ "KEYCODE_Z",		   		IKT_STD,		KEYCODE_Z },
	{ "KEYCODE_0",		   		IKT_STD,		KEYCODE_0 },
	{ "KEYCODE_1",		   		IKT_STD,		KEYCODE_1 },
	{ "KEYCODE_2",		   		IKT_STD,		KEYCODE_2 },
	{ "KEYCODE_3",		   		IKT_STD,		KEYCODE_3 },
	{ "KEYCODE_4",		   		IKT_STD,		KEYCODE_4 },
	{ "KEYCODE_5",		   		IKT_STD,		KEYCODE_5 },
	{ "KEYCODE_6",		   		IKT_STD,		KEYCODE_6 },
	{ "KEYCODE_7",		   		IKT_STD,		KEYCODE_7 },
	{ "KEYCODE_8",		   		IKT_STD,		KEYCODE_8 },
	{ "KEYCODE_9",		   		IKT_STD,		KEYCODE_9 },
	{ "KEYCODE_0_PAD",	   		IKT_STD,		KEYCODE_0_PAD },
	{ "KEYCODE_1_PAD",	   		IKT_STD,		KEYCODE_1_PAD },
	{ "KEYCODE_2_PAD",	   		IKT_STD,		KEYCODE_2_PAD },
	{ "KEYCODE_3_PAD",	   		IKT_STD,		KEYCODE_3_PAD },
	{ "KEYCODE_4_PAD",	   		IKT_STD,		KEYCODE_4_PAD },
	{ "KEYCODE_5_PAD",	   		IKT_STD,		KEYCODE_5_PAD },
	{ "KEYCODE_6_PAD",	   		IKT_STD,		KEYCODE_6_PAD },
	{ "KEYCODE_7_PAD",	   		IKT_STD,		KEYCODE_7_PAD },
	{ "KEYCODE_8_PAD",	      	IKT_STD,		KEYCODE_8_PAD },
	{ "KEYCODE_9_PAD",	      	IKT_STD,		KEYCODE_9_PAD },
	{ "KEYCODE_F1",		   		IKT_STD,		KEYCODE_F1 },
	{ "KEYCODE_F2",			  	IKT_STD,		KEYCODE_F2 },
	{ "KEYCODE_F3",			  	IKT_STD,		KEYCODE_F3 },
	{ "KEYCODE_F4",			  	IKT_STD,		KEYCODE_F4 },
	{ "KEYCODE_F5",			  	IKT_STD,		KEYCODE_F5 },
	{ "KEYCODE_F6",			  	IKT_STD,		KEYCODE_F6 },
	{ "KEYCODE_F7",			  	IKT_STD,		KEYCODE_F7 },
	{ "KEYCODE_F8",			  	IKT_STD,		KEYCODE_F8 },
	{ "KEYCODE_F9",			  	IKT_STD,		KEYCODE_F9 },
	{ "KEYCODE_F10",		  	IKT_STD,		KEYCODE_F10 },
	{ "KEYCODE_F11",		  	IKT_STD,		KEYCODE_F11 },
	{ "KEYCODE_F12",		  	IKT_STD,		KEYCODE_F12 },
	{ "KEYCODE_ESC",		  	IKT_STD,		KEYCODE_ESC },
	{ "KEYCODE_TILDE",		  	IKT_STD,		KEYCODE_TILDE },
	{ "KEYCODE_MINUS",		  	IKT_STD,		KEYCODE_MINUS },
	{ "KEYCODE_EQUALS",		  	IKT_STD,		KEYCODE_EQUALS },
	{ "KEYCODE_BACKSPACE",	  	IKT_STD,		KEYCODE_BACKSPACE },
	{ "KEYCODE_TAB",		  	IKT_STD,		KEYCODE_TAB },
	{ "KEYCODE_OPENBRACE",	  	IKT_STD,		KEYCODE_OPENBRACE },
	{ "KEYCODE_CLOSEBRACE",	  	IKT_STD,		KEYCODE_CLOSEBRACE },
	{ "KEYCODE_ENTER",		  	IKT_STD,		KEYCODE_ENTER },
	{ "KEYCODE_COLON",		  	IKT_STD,		KEYCODE_COLON },
	{ "KEYCODE_QUOTE",		  	IKT_STD,		KEYCODE_QUOTE },
	{ "KEYCODE_BACKSLASH",	  	IKT_STD,		KEYCODE_BACKSLASH },
	{ "KEYCODE_BACKSLASH2",	  	IKT_STD,		KEYCODE_BACKSLASH2 },
	{ "KEYCODE_COMMA",		  	IKT_STD,		KEYCODE_COMMA },
	{ "KEYCODE_STOP",		  	IKT_STD,		KEYCODE_STOP },
	{ "KEYCODE_SLASH",		  	IKT_STD,		KEYCODE_SLASH },
	{ "KEYCODE_SPACE",		  	IKT_STD,		KEYCODE_SPACE },
	{ "KEYCODE_INSERT",		  	IKT_STD,		KEYCODE_INSERT },
	{ "KEYCODE_DEL",		  	IKT_STD,		KEYCODE_DEL },
	{ "KEYCODE_HOME",		  	IKT_STD,		KEYCODE_HOME },
	{ "KEYCODE_END",		  	IKT_STD,		KEYCODE_END },
	{ "KEYCODE_PGUP",		  	IKT_STD,		KEYCODE_PGUP },
	{ "KEYCODE_PGDN",		  	IKT_STD,		KEYCODE_PGDN },
	{ "KEYCODE_LEFT",		  	IKT_STD,		KEYCODE_LEFT },
	{ "KEYCODE_RIGHT",		  	IKT_STD,		KEYCODE_RIGHT },
	{ "KEYCODE_UP",			  	IKT_STD,		KEYCODE_UP },
	{ "KEYCODE_DOWN",		  	IKT_STD,		KEYCODE_DOWN },
	{ "KEYCODE_SLASH_PAD",	  	IKT_STD,		KEYCODE_SLASH_PAD },
	{ "KEYCODE_ASTERISK",	  	IKT_STD,		KEYCODE_ASTERISK },
	{ "KEYCODE_MINUS_PAD",	  	IKT_STD,		KEYCODE_MINUS_PAD },
	{ "KEYCODE_PLUS_PAD",	  	IKT_STD,		KEYCODE_PLUS_PAD },
	{ "KEYCODE_DEL_PAD",	  	IKT_STD,		KEYCODE_DEL_PAD },
	{ "KEYCODE_ENTER_PAD",	  	IKT_STD,		KEYCODE_ENTER_PAD },
	{ "KEYCODE_PRTSCR",		  	IKT_STD,		KEYCODE_PRTSCR },
	{ "KEYCODE_PAUSE",		  	IKT_STD,		KEYCODE_PAUSE },
	{ "KEYCODE_LSHIFT",		  	IKT_STD,		KEYCODE_LSHIFT },
	{ "KEYCODE_RSHIFT",		  	IKT_STD,		KEYCODE_RSHIFT },
	{ "KEYCODE_LCONTROL",	  	IKT_STD,		KEYCODE_LCONTROL },
	{ "KEYCODE_RCONTROL",	  	IKT_STD,		KEYCODE_RCONTROL },
	{ "KEYCODE_LALT",		  	IKT_STD,		KEYCODE_LALT },
	{ "KEYCODE_RALT",		  	IKT_STD,		KEYCODE_RALT },
	{ "KEYCODE_SCRLOCK",	  	IKT_STD,		KEYCODE_SCRLOCK },
	{ "KEYCODE_NUMLOCK",	  	IKT_STD,		KEYCODE_NUMLOCK },
	{ "KEYCODE_CAPSLOCK",	  	IKT_STD,		KEYCODE_CAPSLOCK },
	{ "KEYCODE_LWIN",		  	IKT_STD,		KEYCODE_LWIN },
	{ "KEYCODE_RWIN",		  	IKT_STD,		KEYCODE_RWIN },
	{ "KEYCODE_MENU",		  	IKT_STD,		KEYCODE_MENU },

	{ "JOYCODE_1_LEFT",		  	IKT_STD,		JOYCODE_1_LEFT },
	{ "JOYCODE_1_RIGHT",	  	IKT_STD,		JOYCODE_1_RIGHT },
	{ "JOYCODE_1_UP",		  	IKT_STD,		JOYCODE_1_UP },
	{ "JOYCODE_1_DOWN",		  	IKT_STD,		JOYCODE_1_DOWN },
	{ "JOYCODE_1_BUTTON1",	  	IKT_STD,		JOYCODE_1_BUTTON1 },
	{ "JOYCODE_1_BUTTON2",	  	IKT_STD,		JOYCODE_1_BUTTON2 },
	{ "JOYCODE_1_BUTTON3",	  	IKT_STD,		JOYCODE_1_BUTTON3 },
	{ "JOYCODE_1_BUTTON4",	  	IKT_STD,		JOYCODE_1_BUTTON4 },
	{ "JOYCODE_1_BUTTON5",	  	IKT_STD,		JOYCODE_1_BUTTON5 },
	{ "JOYCODE_1_BUTTON6",	  	IKT_STD,		JOYCODE_1_BUTTON6 },
	{ "JOYCODE_1_START",	  	IKT_STD,		JOYCODE_1_START },
	{ "JOYCODE_1_SELECT",	  	IKT_STD,		JOYCODE_1_SELECT },
	{ "JOYCODE_2_LEFT",		  	IKT_STD,		JOYCODE_2_LEFT },
	{ "JOYCODE_2_RIGHT",	  	IKT_STD,		JOYCODE_2_RIGHT },
	{ "JOYCODE_2_UP",		  	IKT_STD,		JOYCODE_2_UP },
	{ "JOYCODE_2_DOWN",		  	IKT_STD,		JOYCODE_2_DOWN },
	{ "JOYCODE_2_BUTTON1",	  	IKT_STD,		JOYCODE_2_BUTTON1 },
	{ "JOYCODE_2_BUTTON2",	  	IKT_STD,		JOYCODE_2_BUTTON2 },
	{ "JOYCODE_2_BUTTON3",	  	IKT_STD,		JOYCODE_2_BUTTON3 },
	{ "JOYCODE_2_BUTTON4",	  	IKT_STD,		JOYCODE_2_BUTTON4 },
	{ "JOYCODE_2_BUTTON5",	  	IKT_STD,		JOYCODE_2_BUTTON5 },
	{ "JOYCODE_2_BUTTON6",	  	IKT_STD,		JOYCODE_2_BUTTON6 },
	{ "JOYCODE_2_START",	  	IKT_STD,		JOYCODE_2_START },
	{ "JOYCODE_2_SELECT",	  	IKT_STD,		JOYCODE_2_SELECT },
	{ "JOYCODE_3_LEFT",		  	IKT_STD,		JOYCODE_3_LEFT },
	{ "JOYCODE_3_RIGHT",	  	IKT_STD,		JOYCODE_3_RIGHT },
	{ "JOYCODE_3_UP",		  	IKT_STD,		JOYCODE_3_UP },
	{ "JOYCODE_3_DOWN",		  	IKT_STD,		JOYCODE_3_DOWN },
	{ "JOYCODE_3_BUTTON1",	  	IKT_STD,		JOYCODE_3_BUTTON1 },
	{ "JOYCODE_3_BUTTON2",	  	IKT_STD,		JOYCODE_3_BUTTON2 },
	{ "JOYCODE_3_BUTTON3",	  	IKT_STD,		JOYCODE_3_BUTTON3 },
	{ "JOYCODE_3_BUTTON4",	  	IKT_STD,		JOYCODE_3_BUTTON4 },
	{ "JOYCODE_3_BUTTON5",	  	IKT_STD,		JOYCODE_3_BUTTON5 },
	{ "JOYCODE_3_BUTTON6",	  	IKT_STD,		JOYCODE_3_BUTTON6 },
	{ "JOYCODE_3_START",	  	IKT_STD,		JOYCODE_3_START },
	{ "JOYCODE_3_SELECT",	  	IKT_STD,		JOYCODE_3_SELECT },
	{ "JOYCODE_4_LEFT",		  	IKT_STD,		JOYCODE_4_LEFT },
	{ "JOYCODE_4_RIGHT",	  	IKT_STD,		JOYCODE_4_RIGHT },
	{ "JOYCODE_4_UP",		  	IKT_STD,		JOYCODE_4_UP },
	{ "JOYCODE_4_DOWN",		  	IKT_STD,		JOYCODE_4_DOWN },
	{ "JOYCODE_4_BUTTON1",	  	IKT_STD,		JOYCODE_4_BUTTON1 },
	{ "JOYCODE_4_BUTTON2",	  	IKT_STD,		JOYCODE_4_BUTTON2 },
	{ "JOYCODE_4_BUTTON3",	  	IKT_STD,		JOYCODE_4_BUTTON3 },
	{ "JOYCODE_4_BUTTON4",	  	IKT_STD,		JOYCODE_4_BUTTON4 },
	{ "JOYCODE_4_BUTTON5",	  	IKT_STD,		JOYCODE_4_BUTTON5 },
	{ "JOYCODE_4_BUTTON6",	  	IKT_STD,		JOYCODE_4_BUTTON6 },
	{ "JOYCODE_4_START",	  	IKT_STD,		JOYCODE_4_START },
	{ "JOYCODE_4_SELECT",	  	IKT_STD,		JOYCODE_4_SELECT },

	{ "MOUSECODE_1_BUTTON1", 	IKT_STD,		JOYCODE_MOUSE_1_BUTTON1 },
	{ "MOUSECODE_1_BUTTON2", 	IKT_STD,		JOYCODE_MOUSE_1_BUTTON2 },
	{ "MOUSECODE_1_BUTTON3", 	IKT_STD,		JOYCODE_MOUSE_1_BUTTON3 },

	{ "KEYCODE_NONE",			IKT_STD,		CODE_NONE },
	{ "CODE_NONE",			  	IKT_STD,		CODE_NONE },
	{ "CODE_OTHER",				IKT_STD,		CODE_OTHER },
	{ "CODE_DEFAULT",			IKT_STD,		CODE_DEFAULT },
	{ "CODE_PREVIOUS",			IKT_STD,		CODE_PREVIOUS },
	{ "CODE_NOT",				IKT_STD,		CODE_NOT },
	{ "CODE_OR",			   	IKT_STD,		CODE_OR },
	{ "!",						IKT_STD,		CODE_NOT },
	{ "|",					   	IKT_STD,		CODE_OR },

	{ "UI_CONFIGURE", 			IKT_IPT,	 	IPT_UI_CONFIGURE },
	{ "UI_ON_SCREEN_DISPLAY",	IKT_IPT,		IPT_UI_ON_SCREEN_DISPLAY },
	{ "UI_PAUSE",				IKT_IPT,		IPT_UI_PAUSE },
	{ "UI_RESET_MACHINE",		IKT_IPT,		IPT_UI_RESET_MACHINE },
	{ "UI_SHOW_GFX",			IKT_IPT,		IPT_UI_SHOW_GFX },
	{ "UI_FRAMESKIP_DEC",		IKT_IPT,		IPT_UI_FRAMESKIP_DEC },
	{ "UI_FRAMESKIP_INC",		IKT_IPT,		IPT_UI_FRAMESKIP_INC },
	{ "UI_THROTTLE",			IKT_IPT,		IPT_UI_THROTTLE },
	{ "UI_SHOW_FPS",			IKT_IPT,		IPT_UI_SHOW_FPS },
	{ "UI_SHOW_PROFILER",		IKT_IPT,		IPT_UI_SHOW_PROFILER },
#ifdef MESS
	{ "UI_TOGGLE_UI",			IKT_IPT,		IPT_UI_TOGGLE_UI },
#endif
#ifdef KAILLERA
	{ "UI_CHAT_OPEN",			IKT_IPT,		IPT_UI_CHAT_OPEN },
	{ "UI_CHAT_CHANGE_BG",		IKT_IPT,		IPT_UI_CHAT_CHANGE_BG },
      { "UI_TOGGLE_AUTOSAVE",		IKT_IPT,		IPT_UI_TOGGLE_AUTOSAVE },
      { "UI_LOAD_AUTOSAVE",		IKT_IPT,		IPT_UI_LOAD_AUTOSAVE },
	{ "UI_SEND_DIP",			IKT_IPT,		IPT_UI_SEND_DIP },
	{ "UI_VERSION",			IKT_IPT,		IPT_UI_VERSION },
      { "UI_P1_SHIFT_DOWN",		IKT_IPT,		IPT_UI_P1_SHIFT_DOWN },
      { "UI_P1_SHIFT_UP",		IKT_IPT,		IPT_UI_P1_SHIFT_UP },
      { "UI_SWAP_CONTROL",		IKT_IPT,		IPT_UI_SWAP_CONTROL }, 
#endif /* KAILLERA */
	{ "UI_SNAPSHOT",			IKT_IPT,		IPT_UI_SNAPSHOT },
	{ "UI_TOGGLE_CHEAT",		IKT_IPT,		IPT_UI_TOGGLE_CHEAT },
	{ "UI_UP",					IKT_IPT,		IPT_UI_UP },
	{ "UI_DOWN",				IKT_IPT,		IPT_UI_DOWN },
	{ "UI_LEFT",				IKT_IPT,		IPT_UI_LEFT },
	{ "UI_RIGHT",				IKT_IPT,		IPT_UI_RIGHT },
	{ "UI_SELECT",				IKT_IPT,		IPT_UI_SELECT },
	{ "UI_CANCEL",				IKT_IPT,		IPT_UI_CANCEL },
	{ "UI_PAN_UP",				IKT_IPT,		IPT_UI_PAN_UP },
	{ "UI_PAN_DOWN",			IKT_IPT,		IPT_UI_PAN_DOWN },
	{ "UI_PAN_LEFT",			IKT_IPT,		IPT_UI_PAN_LEFT },
	{ "UI_PAN_RIGHT",			IKT_IPT,		IPT_UI_PAN_RIGHT },
	{ "UI_TOGGLE_DEBUG",		IKT_IPT,		IPT_UI_TOGGLE_DEBUG },
	{ "UI_SAVE_STATE",			IKT_IPT,		IPT_UI_SAVE_STATE },
	{ "UI_LOAD_STATE",			IKT_IPT,		IPT_UI_LOAD_STATE },
	{ "UI_ADD_CHEAT",			IKT_IPT,		IPT_UI_ADD_CHEAT },
	{ "UI_DELETE_CHEAT",		IKT_IPT,		IPT_UI_DELETE_CHEAT },
	{ "UI_SAVE_CHEAT",			IKT_IPT,		IPT_UI_SAVE_CHEAT },
	{ "UI_WATCH_VALUE",			IKT_IPT,		IPT_UI_WATCH_VALUE },
	{ "UI_EDIT_CHEAT",			IKT_IPT,		IPT_UI_EDIT_CHEAT },
	{ "UI_TOGGLE_CROSSHAIR",	IKT_IPT,		IPT_UI_TOGGLE_CROSSHAIR },
	{ "START1",					IKT_IPT,		IPT_START1 },
	{ "START2",					IKT_IPT,		IPT_START2 },
	{ "START3",					IKT_IPT,		IPT_START3 },
	{ "START4",					IKT_IPT,		IPT_START4 },
	{ "COIN1",					IKT_IPT,		IPT_COIN1 },
	{ "COIN2",					IKT_IPT,		IPT_COIN2 },
	{ "COIN3",					IKT_IPT,		IPT_COIN3 },
	{ "COIN4",					IKT_IPT,		IPT_COIN4 },
	{ "SERVICE1",				IKT_IPT,		IPT_SERVICE1 },
	{ "SERVICE2",				IKT_IPT,		IPT_SERVICE2 },
	{ "SERVICE3",				IKT_IPT,		IPT_SERVICE3 },
	{ "SERVICE4",				IKT_IPT,		IPT_SERVICE4 },
	{ "TILT",					IKT_IPT,		IPT_TILT },

	{ "P1_JOYSTICK_UP",			IKT_IPT,		IPF_PLAYER1 | IPT_JOYSTICK_UP },
	{ "P1_JOYSTICK_DOWN",		IKT_IPT,		IPF_PLAYER1 | IPT_JOYSTICK_DOWN },
	{ "P1_JOYSTICK_LEFT",		IKT_IPT,		IPF_PLAYER1 | IPT_JOYSTICK_LEFT },
	{ "P1_JOYSTICK_RIGHT",		IKT_IPT,		IPF_PLAYER1 | IPT_JOYSTICK_RIGHT },
	{ "P1_BUTTON1",				IKT_IPT,		IPF_PLAYER1 | IPT_BUTTON1 },
	{ "P1_BUTTON2",				IKT_IPT,		IPF_PLAYER1 | IPT_BUTTON2 },
	{ "P1_BUTTON3",				IKT_IPT,		IPF_PLAYER1 | IPT_BUTTON3 },
	{ "P1_BUTTON4",				IKT_IPT,		IPF_PLAYER1 | IPT_BUTTON4 },
	{ "P1_BUTTON5",				IKT_IPT,		IPF_PLAYER1 | IPT_BUTTON5 },
	{ "P1_BUTTON6",				IKT_IPT,		IPF_PLAYER1 | IPT_BUTTON6 },
	{ "P1_BUTTON7",				IKT_IPT,		IPF_PLAYER1 | IPT_BUTTON7 },
	{ "P1_BUTTON8",				IKT_IPT,		IPF_PLAYER1 | IPT_BUTTON8 },
	{ "P1_BUTTON9",				IKT_IPT,		IPF_PLAYER1 | IPT_BUTTON9 },
	{ "P1_BUTTON10",			IKT_IPT,		IPF_PLAYER1 | IPT_BUTTON10 },
#ifdef KAILLERA
	{ "P1_3_Kicks", 			IKT_IPT,		IPF_PLAYER1 | IPT_3KICKS },
	{ "P1_3_Punches", 		IKT_IPT,		IPF_PLAYER1 | IPT_3PUNCHES },
	{ "P1_Special_Atk1", 		IKT_IPT,		IPF_PLAYER1 | IPT_SPEC1 },
	{ "P1_Special_Atk2", 		IKT_IPT,		IPF_PLAYER1 | IPT_SPEC2 },
	{ "P1_Special_Atk3", 		IKT_IPT,		IPF_PLAYER1 | IPT_SPEC3 },
	{ "P1_A+B_(NG)", 			IKT_IPT,		IPF_PLAYER1 | IPT_AB },
	{ "P1_C+D_(NG)", 			IKT_IPT,		IPF_PLAYER1 | IPT_CD },
	{ "P1_B+C_(NG)", 			IKT_IPT,		IPF_PLAYER1 | IPT_BC },
	{ "P1_A+C_(NG)", 			IKT_IPT,		IPF_PLAYER1 | IPT_AC },
	{ "P1_B+D_(NG)", 			IKT_IPT,		IPF_PLAYER1 | IPT_BD },
	{ "P1_A+B+C_(NG)", 		IKT_IPT,		IPF_PLAYER1 | IPT_ABC },
	{ "P1_B+C+D_(NG)", 		IKT_IPT,		IPF_PLAYER1 | IPT_BCD },
	{ "P1_A+B+C+D_(NG)", 		IKT_IPT,		IPF_PLAYER1 | IPT_ABCD },
#endif
	{ "P1_JOYSTICKRIGHT_UP",	IKT_IPT,		IPF_PLAYER1 | IPT_JOYSTICKRIGHT_UP },
	{ "P1_JOYSTICKRIGHT_DOWN",	IKT_IPT,		IPF_PLAYER1 | IPT_JOYSTICKRIGHT_DOWN },
	{ "P1_JOYSTICKRIGHT_LEFT",	IKT_IPT,		IPF_PLAYER1 | IPT_JOYSTICKRIGHT_LEFT },
	{ "P1_JOYSTICKRIGHT_RIGHT",	IKT_IPT,		IPF_PLAYER1 | IPT_JOYSTICKRIGHT_RIGHT },
	{ "P1_JOYSTICKLEFT_UP",		IKT_IPT,		IPF_PLAYER1 | IPT_JOYSTICKLEFT_UP },
	{ "P1_JOYSTICKLEFT_DOWN",	IKT_IPT,		IPF_PLAYER1 | IPT_JOYSTICKLEFT_DOWN },
	{ "P1_JOYSTICKLEFT_LEFT",	IKT_IPT,		IPF_PLAYER1 | IPT_JOYSTICKLEFT_LEFT },
	{ "P1_JOYSTICKLEFT_RIGHT",	IKT_IPT,		IPF_PLAYER1 | IPT_JOYSTICKLEFT_RIGHT },

	{ "P2_JOYSTICK_UP",			IKT_IPT,		IPF_PLAYER2 | IPT_JOYSTICK_UP },
	{ "P2_JOYSTICK_DOWN",		IKT_IPT,		IPF_PLAYER2 | IPT_JOYSTICK_DOWN },
	{ "P2_JOYSTICK_LEFT",		IKT_IPT,		IPF_PLAYER2 | IPT_JOYSTICK_LEFT },
	{ "P2_JOYSTICK_RIGHT",		IKT_IPT,		IPF_PLAYER2 | IPT_JOYSTICK_RIGHT },
	{ "P2_BUTTON1",				IKT_IPT,		IPF_PLAYER2 | IPT_BUTTON1 },
	{ "P2_BUTTON2",				IKT_IPT,		IPF_PLAYER2 | IPT_BUTTON2 },
	{ "P2_BUTTON3",				IKT_IPT,		IPF_PLAYER2 | IPT_BUTTON3 },
	{ "P2_BUTTON4",				IKT_IPT,		IPF_PLAYER2 | IPT_BUTTON4 },
	{ "P2_BUTTON5",				IKT_IPT,		IPF_PLAYER2 | IPT_BUTTON5 },
	{ "P2_BUTTON6",				IKT_IPT,		IPF_PLAYER2 | IPT_BUTTON6 },
	{ "P2_BUTTON7",				IKT_IPT,		IPF_PLAYER2 | IPT_BUTTON7 },
	{ "P2_BUTTON8",				IKT_IPT,		IPF_PLAYER2 | IPT_BUTTON8 },
	{ "P2_BUTTON9",				IKT_IPT,		IPF_PLAYER2 | IPT_BUTTON9 },
	{ "P2_BUTTON10",			IKT_IPT,		IPF_PLAYER2 | IPT_BUTTON10 },
#ifdef KAILLERA
	{ "P2_3_Kicks", 			IKT_IPT,		IPF_PLAYER2 | IPT_3KICKS },
	{ "P2_3_Punches", 		IKT_IPT,		IPF_PLAYER2 | IPT_3PUNCHES },
	{ "P2_Special_Atk1", 		IKT_IPT,		IPF_PLAYER2 | IPT_SPEC1 },
	{ "P2_Special_Atk2", 		IKT_IPT,		IPF_PLAYER2 | IPT_SPEC2 },
	{ "P2_Special_Atk3", 		IKT_IPT,		IPF_PLAYER2 | IPT_SPEC3 },
	{ "P2_A+B_(NG)", 			IKT_IPT,		IPF_PLAYER2 | IPT_AB },
	{ "P2_C+D_(NG)", 			IKT_IPT,		IPF_PLAYER2 | IPT_CD },
	{ "P2_B+C_(NG)", 			IKT_IPT,		IPF_PLAYER2 | IPT_BC },
	{ "P2_A+C_(NG)", 			IKT_IPT,		IPF_PLAYER2 | IPT_AC },
	{ "P2_B+D_(NG)", 			IKT_IPT,		IPF_PLAYER2 | IPT_BD },
	{ "P2_A+B+C_(NG)", 		IKT_IPT,		IPF_PLAYER2 | IPT_ABC },
	{ "P2_B+C+D_(NG)", 		IKT_IPT,		IPF_PLAYER2 | IPT_BCD },
	{ "P2_A+B+C+D_(NG)", 		IKT_IPT,		IPF_PLAYER2 | IPT_ABCD },
#endif
	{ "P2_JOYSTICKRIGHT_UP",	IKT_IPT,		IPF_PLAYER2 | IPT_JOYSTICKRIGHT_UP },
	{ "P2_JOYSTICKRIGHT_DOWN",	IKT_IPT,		IPF_PLAYER2 | IPT_JOYSTICKRIGHT_DOWN },
	{ "P2_JOYSTICKRIGHT_LEFT",	IKT_IPT,		IPF_PLAYER2 | IPT_JOYSTICKRIGHT_LEFT },
	{ "P2_JOYSTICKRIGHT_RIGHT",	IKT_IPT,		IPF_PLAYER2 | IPT_JOYSTICKRIGHT_RIGHT },
	{ "P2_JOYSTICKLEFT_UP",		IKT_IPT,		IPF_PLAYER2 | IPT_JOYSTICKLEFT_UP },
	{ "P2_JOYSTICKLEFT_DOWN",	IKT_IPT,		IPF_PLAYER2 | IPT_JOYSTICKLEFT_DOWN },
	{ "P2_JOYSTICKLEFT_LEFT",	IKT_IPT,		IPF_PLAYER2 | IPT_JOYSTICKLEFT_LEFT },
	{ "P2_JOYSTICKLEFT_RIGHT",	IKT_IPT,		IPF_PLAYER2 | IPT_JOYSTICKLEFT_RIGHT },

	{ "P3_JOYSTICK_UP",			IKT_IPT,		IPF_PLAYER3 | IPT_JOYSTICK_UP },
	{ "P3_JOYSTICK_DOWN",		IKT_IPT,		IPF_PLAYER3 | IPT_JOYSTICK_DOWN },
	{ "P3_JOYSTICK_LEFT",		IKT_IPT,		IPF_PLAYER3 | IPT_JOYSTICK_LEFT },
	{ "P3_JOYSTICK_RIGHT",		IKT_IPT,		IPF_PLAYER3 | IPT_JOYSTICK_RIGHT },
	{ "P3_BUTTON1",				IKT_IPT,		IPF_PLAYER3 | IPT_BUTTON1 },
	{ "P3_BUTTON2",				IKT_IPT,		IPF_PLAYER3 | IPT_BUTTON2 },
	{ "P3_BUTTON3",				IKT_IPT,		IPF_PLAYER3 | IPT_BUTTON3 },
	{ "P3_BUTTON4",				IKT_IPT,		IPF_PLAYER3 | IPT_BUTTON4 },
#ifdef KAILLERA
	{ "P3_BUTTON5",				IKT_IPT,		IPF_PLAYER3 | IPT_BUTTON5 },
	{ "P3_BUTTON6",				IKT_IPT,		IPF_PLAYER3 | IPT_BUTTON6 },
	{ "P3_BUTTON7",				IKT_IPT,		IPF_PLAYER3 | IPT_BUTTON7 },
	{ "P3_BUTTON8",				IKT_IPT,		IPF_PLAYER3 | IPT_BUTTON8 },
	{ "P3_BUTTON9",				IKT_IPT,		IPF_PLAYER3 | IPT_BUTTON9 },
	{ "P3_BUTTON10",			IKT_IPT,		IPF_PLAYER3 | IPT_BUTTON10 },
	{ "P3_3_Kicks", 			IKT_IPT,		IPF_PLAYER3 | IPT_3KICKS },
	{ "P3_3_Punches", 		IKT_IPT,		IPF_PLAYER3 | IPT_3PUNCHES },
	{ "P3_Special_Atk1", 		IKT_IPT,		IPF_PLAYER3 | IPT_SPEC1 },
	{ "P3_Special_Atk2", 		IKT_IPT,		IPF_PLAYER3 | IPT_SPEC2 },
	{ "P3_Special_Atk3", 		IKT_IPT,		IPF_PLAYER3 | IPT_SPEC3 },
	{ "P3_A+B_(NG)", 			IKT_IPT,		IPF_PLAYER3 | IPT_AB },
	{ "P3_C+D_(NG)", 			IKT_IPT,		IPF_PLAYER3 | IPT_CD },
	{ "P3_B+C_(NG)", 			IKT_IPT,		IPF_PLAYER3 | IPT_BC },
	{ "P3_A+C_(NG)", 			IKT_IPT,		IPF_PLAYER3 | IPT_AC },
	{ "P3_B+D_(NG)", 			IKT_IPT,		IPF_PLAYER3 | IPT_BD },
	{ "P3_A+B+C_(NG)", 		IKT_IPT,		IPF_PLAYER3 | IPT_ABC },
	{ "P3_B+C+D_(NG)", 		IKT_IPT,		IPF_PLAYER3 | IPT_BCD },
	{ "P3_A+B+C+D_(NG)", 		IKT_IPT,		IPF_PLAYER3 | IPT_ABCD },
#endif

	{ "P4_JOYSTICK_UP",			IKT_IPT,		IPF_PLAYER4 | IPT_JOYSTICK_UP },
	{ "P4_JOYSTICK_DOWN",		IKT_IPT,		IPF_PLAYER4 | IPT_JOYSTICK_DOWN },
	{ "P4_JOYSTICK_LEFT",		IKT_IPT,		IPF_PLAYER4 | IPT_JOYSTICK_LEFT },
	{ "P4_JOYSTICK_RIGHT",		IKT_IPT,		IPF_PLAYER4 | IPT_JOYSTICK_RIGHT },
	{ "P4_BUTTON1",				IKT_IPT,		IPF_PLAYER4 | IPT_BUTTON1 },
	{ "P4_BUTTON2",				IKT_IPT,		IPF_PLAYER4 | IPT_BUTTON2 },
	{ "P4_BUTTON3",				IKT_IPT,		IPF_PLAYER4 | IPT_BUTTON3 },
	{ "P4_BUTTON4",				IKT_IPT,		IPF_PLAYER4 | IPT_BUTTON4 },
#ifdef KAILLERA
	{ "P4_BUTTON5",				IKT_IPT,		IPF_PLAYER4 | IPT_BUTTON5 },
	{ "P4_BUTTON6",				IKT_IPT,		IPF_PLAYER4 | IPT_BUTTON6 },
	{ "P4_BUTTON7",				IKT_IPT,		IPF_PLAYER4 | IPT_BUTTON7 },
	{ "P4_BUTTON8",				IKT_IPT,		IPF_PLAYER4 | IPT_BUTTON8 },
	{ "P4_BUTTON9",				IKT_IPT,		IPF_PLAYER4 | IPT_BUTTON9 },
	{ "P4_BUTTON10",			IKT_IPT,		IPF_PLAYER4 | IPT_BUTTON10 },
	{ "P4_3_Kicks", 			IKT_IPT,		IPF_PLAYER4 | IPT_3KICKS },
	{ "P4_3_Punches", 		IKT_IPT,		IPF_PLAYER4 | IPT_3PUNCHES },
	{ "P4_Special_Atk1", 		IKT_IPT,		IPF_PLAYER4 | IPT_SPEC1 },
	{ "P4_Special_Atk2", 		IKT_IPT,		IPF_PLAYER4 | IPT_SPEC2 },
	{ "P4_Special_Atk3", 		IKT_IPT,		IPF_PLAYER4 | IPT_SPEC3 },
	{ "P4_A+B_(NG)", 			IKT_IPT,		IPF_PLAYER4 | IPT_AB },
	{ "P4_C+D_(NG)", 			IKT_IPT,		IPF_PLAYER4 | IPT_CD },
	{ "P4_B+C_(NG)", 			IKT_IPT,		IPF_PLAYER4 | IPT_BC },
	{ "P4_A+C_(NG)", 			IKT_IPT,		IPF_PLAYER4 | IPT_AC },
	{ "P4_B+D_(NG)", 			IKT_IPT,		IPF_PLAYER4 | IPT_BD },
	{ "P4_A+B+C_(NG)", 		IKT_IPT,		IPF_PLAYER4 | IPT_ABC },
	{ "P4_B+C+D_(NG)", 		IKT_IPT,		IPF_PLAYER4 | IPT_BCD },
	{ "P4_A+B+C+D_(NG)", 		IKT_IPT,		IPF_PLAYER4 | IPT_ABCD },
#endif

	{ "P1_PEDAL",				IKT_IPT,		IPF_PLAYER1 | IPT_PEDAL },
	{ "P1_PEDAL_EXT",			IKT_IPT_EXT,	IPF_PLAYER1 | IPT_PEDAL },
	{ "P2_PEDAL",				IKT_IPT,		IPF_PLAYER2 | IPT_PEDAL },
	{ "P2_PEDAL_EXT",			IKT_IPT_EXT,	IPF_PLAYER2 | IPT_PEDAL },
	{ "P3_PEDAL",				IKT_IPT,		IPF_PLAYER3 | IPT_PEDAL },
	{ "P3_PEDAL_EXT",			IKT_IPT_EXT,	IPF_PLAYER3 | IPT_PEDAL },
	{ "P4_PEDAL",				IKT_IPT,		IPF_PLAYER4 | IPT_PEDAL },
	{ "P4_PEDAL_EXT",			IKT_IPT_EXT,	IPF_PLAYER4 | IPT_PEDAL },

	{ "P1_PEDAL2",				IKT_IPT,		IPF_PLAYER1 | IPT_PEDAL2 },
	{ "P1_PEDAL2_EXT",			IKT_IPT_EXT,	IPF_PLAYER1 | IPT_PEDAL2 },
	{ "P2_PEDAL2",				IKT_IPT,		IPF_PLAYER2 | IPT_PEDAL2 },
	{ "P2_PEDAL2_EXT",			IKT_IPT_EXT,	IPF_PLAYER2 | IPT_PEDAL2 },
	{ "P3_PEDAL2",				IKT_IPT,		IPF_PLAYER3 | IPT_PEDAL2 },
	{ "P3_PEDAL2_EXT",			IKT_IPT_EXT,	IPF_PLAYER3 | IPT_PEDAL2 },
	{ "P4_PEDAL2",				IKT_IPT,		IPF_PLAYER4 | IPT_PEDAL2 },
	{ "P4_PEDAL2_EXT",			IKT_IPT_EXT,	IPF_PLAYER4 | IPT_PEDAL2 },

	{ "P1_PADDLE",				IKT_IPT,		IPF_PLAYER1 | IPT_PADDLE },
	{ "P1_PADDLE_EXT",			IKT_IPT_EXT,	IPF_PLAYER1 | IPT_PADDLE },
	{ "P2_PADDLE",				IKT_IPT,		IPF_PLAYER2 | IPT_PADDLE },
	{ "P2_PADDLE_EXT",			IKT_IPT_EXT,	IPF_PLAYER2 | IPT_PADDLE },
	{ "P3_PADDLE",				IKT_IPT,		IPF_PLAYER3 | IPT_PADDLE },
	{ "P3_PADDLE_EXT",			IKT_IPT_EXT,	IPF_PLAYER3 | IPT_PADDLE },
	{ "P4_PADDLE",				IKT_IPT,		IPF_PLAYER4 | IPT_PADDLE },
	{ "P4_PADDLE_EXT",			IKT_IPT_EXT,	IPF_PLAYER4 | IPT_PADDLE },
	{ "P1_PADDLE_V",			IKT_IPT,		IPF_PLAYER1 | IPT_PADDLE_V },
	{ "P1_PADDLE_V_EXT",		IKT_IPT_EXT,	IPF_PLAYER1 | IPT_PADDLE_V },
	{ "P2_PADDLE_V",			IKT_IPT,		IPF_PLAYER2 | IPT_PADDLE_V },
	{ "P2_PADDLE_V_EXT",		IKT_IPT_EXT,	IPF_PLAYER2 | IPT_PADDLE_V },
	{ "P3_PADDLE_V",			IKT_IPT,		IPF_PLAYER3 | IPT_PADDLE_V },
	{ "P3_PADDLE_V_EXT",		IKT_IPT_EXT,	IPF_PLAYER3 | IPT_PADDLE_V },
	{ "P4_PADDLE_V",			IKT_IPT,		IPF_PLAYER4 | IPT_PADDLE_V },
	{ "P4_PADDLE_V_EXT",		IKT_IPT_EXT,	IPF_PLAYER4 | IPT_PADDLE_V },

	{ "P1_DIAL",				IKT_IPT,		IPF_PLAYER1 | IPT_DIAL },
	{ "P1_DIAL_EXT",			IKT_IPT_EXT,	IPF_PLAYER1 | IPT_DIAL },
	{ "P2_DIAL",				IKT_IPT,		IPF_PLAYER2 | IPT_DIAL },
	{ "P2_DIAL_EXT",			IKT_IPT_EXT,	IPF_PLAYER2 | IPT_DIAL },
	{ "P3_DIAL",				IKT_IPT,		IPF_PLAYER3 | IPT_DIAL },
	{ "P3_DIAL_EXT",			IKT_IPT_EXT,	IPF_PLAYER3 | IPT_DIAL },
	{ "P4_DIAL",				IKT_IPT,		IPF_PLAYER4 | IPT_DIAL },
	{ "P4_DIAL_EXT",			IKT_IPT_EXT,	IPF_PLAYER4 | IPT_DIAL },
	{ "P1_DIAL_V",				IKT_IPT,		IPF_PLAYER1 | IPT_DIAL_V },
	{ "P1_DIAL_V_EXT",			IKT_IPT_EXT,	IPF_PLAYER1 | IPT_DIAL_V },
	{ "P2_DIAL_V",				IKT_IPT,		IPF_PLAYER2 | IPT_DIAL_V },
	{ "P2_DIAL_V_EXT",			IKT_IPT_EXT,	IPF_PLAYER2 | IPT_DIAL_V },
	{ "P3_DIAL_V",				IKT_IPT,		IPF_PLAYER3 | IPT_DIAL_V },
	{ "P3_DIAL_V_EXT",			IKT_IPT_EXT,	IPF_PLAYER3 | IPT_DIAL_V },
	{ "P4_DIAL_V",				IKT_IPT,		IPF_PLAYER4 | IPT_DIAL_V },
	{ "P4_DIAL_V_EXT",			IKT_IPT_EXT,	IPF_PLAYER4 | IPT_DIAL_V },

	{ "P1_TRACKBALL_X",			IKT_IPT,		IPF_PLAYER1 | IPT_TRACKBALL_X },
	{ "P1_TRACKBALL_X_EXT",		IKT_IPT_EXT,	IPF_PLAYER1 | IPT_TRACKBALL_X },
	{ "P2_TRACKBALL_X",			IKT_IPT,		IPF_PLAYER2 | IPT_TRACKBALL_X },
	{ "P2_TRACKBALL_X_EXT",		IKT_IPT_EXT,	IPF_PLAYER2 | IPT_TRACKBALL_X },
	{ "P3_TRACKBALL_X",			IKT_IPT,		IPF_PLAYER3 | IPT_TRACKBALL_X },
	{ "P3_TRACKBALL_X_EXT",		IKT_IPT_EXT,	IPF_PLAYER3 | IPT_TRACKBALL_X },
	{ "P4_TRACKBALL_X",			IKT_IPT,		IPF_PLAYER4 | IPT_TRACKBALL_X },
	{ "P4_TRACKBALL_X_EXT",		IKT_IPT_EXT,	IPF_PLAYER4 | IPT_TRACKBALL_X },

	{ "P1_TRACKBALL_Y",			IKT_IPT,		IPF_PLAYER1 | IPT_TRACKBALL_Y },
	{ "P1_TRACKBALL_Y_EXT",		IKT_IPT_EXT,	IPF_PLAYER1 | IPT_TRACKBALL_Y },
	{ "P2_TRACKBALL_Y",			IKT_IPT,		IPF_PLAYER2 | IPT_TRACKBALL_Y },
	{ "P2_TRACKBALL_Y_EXT",		IKT_IPT_EXT,	IPF_PLAYER2 | IPT_TRACKBALL_Y },
	{ "P3_TRACKBALL_Y",			IKT_IPT,		IPF_PLAYER3 | IPT_TRACKBALL_Y },
	{ "P3_TRACKBALL_Y_EXT",		IKT_IPT_EXT,	IPF_PLAYER3 | IPT_TRACKBALL_Y },
	{ "P4_TRACKBALL_Y",			IKT_IPT,		IPF_PLAYER4 | IPT_TRACKBALL_Y },
	{ "P4_TRACKBALL_Y_EXT",		IKT_IPT_EXT,	IPF_PLAYER4 | IPT_TRACKBALL_Y },

	{ "P1_AD_STICK_X",			IKT_IPT,		IPF_PLAYER1 | IPT_AD_STICK_X },
	{ "P1_AD_STICK_X_EXT",		IKT_IPT_EXT,	IPF_PLAYER1 | IPT_AD_STICK_X },
	{ "P2_AD_STICK_X",			IKT_IPT,		IPF_PLAYER2 | IPT_AD_STICK_X },
	{ "P2_AD_STICK_X_EXT",		IKT_IPT_EXT,	IPF_PLAYER2 | IPT_AD_STICK_X },
	{ "P3_AD_STICK_X",			IKT_IPT,		IPF_PLAYER3 | IPT_AD_STICK_X },
	{ "P3_AD_STICK_X_EXT",		IKT_IPT_EXT,	IPF_PLAYER3 | IPT_AD_STICK_X },
	{ "P4_AD_STICK_X",			IKT_IPT,		IPF_PLAYER4 | IPT_AD_STICK_X },
	{ "P4_AD_STICK_X_EXT",		IKT_IPT_EXT,	IPF_PLAYER4 | IPT_AD_STICK_X },

	{ "P1_AD_STICK_Y",			IKT_IPT,		IPF_PLAYER1 | IPT_AD_STICK_Y },
	{ "P1_AD_STICK_Y_EXT",		IKT_IPT_EXT,	IPF_PLAYER1 | IPT_AD_STICK_Y },
	{ "P2_AD_STICK_Y",			IKT_IPT,		IPF_PLAYER2 | IPT_AD_STICK_Y },
	{ "P2_AD_STICK_Y_EXT",		IKT_IPT_EXT,	IPF_PLAYER2 | IPT_AD_STICK_Y },
	{ "P3_AD_STICK_Y",			IKT_IPT,		IPF_PLAYER3 | IPT_AD_STICK_Y },
	{ "P3_AD_STICK_Y_EXT",		IKT_IPT_EXT,	IPF_PLAYER3 | IPT_AD_STICK_Y },
	{ "P4_AD_STICK_Y",			IKT_IPT,		IPF_PLAYER4 | IPT_AD_STICK_Y },
	{ "P4_AD_STICK_Y_EXT",		IKT_IPT_EXT,	IPF_PLAYER4 | IPT_AD_STICK_Y },

	{ "P1_LIGHTGUN_X",			IKT_IPT,		IPF_PLAYER1 | IPT_LIGHTGUN_X },
	{ "P1_LIGHTGUN_X_EXT",		IKT_IPT_EXT,	IPF_PLAYER1 | IPT_LIGHTGUN_X },
	{ "P2_LIGHTGUN_X",			IKT_IPT,		IPF_PLAYER2 | IPT_LIGHTGUN_X },
	{ "P2_LIGHTGUN_X_EXT",		IKT_IPT_EXT,	IPF_PLAYER2 | IPT_LIGHTGUN_X },
	{ "P3_LIGHTGUN_X",			IKT_IPT,		IPF_PLAYER3 | IPT_LIGHTGUN_X },
	{ "P3_LIGHTGUN_X_EXT",		IKT_IPT_EXT,	IPF_PLAYER3 | IPT_LIGHTGUN_X },
	{ "P4_LIGHTGUN_X",			IKT_IPT,		IPF_PLAYER4 | IPT_LIGHTGUN_X },
	{ "P4_LIGHTGUN_X_EXT",		IKT_IPT_EXT,	IPF_PLAYER4 | IPT_LIGHTGUN_X },

	{ "P1_LIGHTGUN_Y",			IKT_IPT,		IPF_PLAYER1 | IPT_LIGHTGUN_Y },
	{ "P1_LIGHTGUN_Y_EXT",		IKT_IPT_EXT,	IPF_PLAYER1 | IPT_LIGHTGUN_Y },
	{ "P2_LIGHTGUN_Y",			IKT_IPT,		IPF_PLAYER2 | IPT_LIGHTGUN_Y },
	{ "P2_LIGHTGUN_Y_EXT",		IKT_IPT_EXT,	IPF_PLAYER2 | IPT_LIGHTGUN_Y },
	{ "P3_LIGHTGUN_Y",			IKT_IPT,		IPF_PLAYER3 | IPT_LIGHTGUN_Y },
	{ "P3_LIGHTGUN_Y_EXT",		IKT_IPT_EXT,	IPF_PLAYER3 | IPT_LIGHTGUN_Y },
	{ "P4_LIGHTGUN_Y",			IKT_IPT,		IPF_PLAYER4 | IPT_LIGHTGUN_Y },
	{ "P4_LIGHTGUN_Y_EXT",		IKT_IPT_EXT,	IPF_PLAYER4 | IPT_LIGHTGUN_Y },

	{ "P1_AD_STICK_Z",			IKT_IPT,		IPF_PLAYER1 | IPT_AD_STICK_Z },
	{ "P1_AD_STICK_Z_EXT",		IKT_IPT_EXT,	IPF_PLAYER1 | IPT_AD_STICK_Z },
	{ "P2_AD_STICK_Z",			IKT_IPT,		IPF_PLAYER2 | IPT_AD_STICK_Z },
	{ "P2_AD_STICK_Z_EXT",		IKT_IPT_EXT,	IPF_PLAYER2 | IPT_AD_STICK_Z },
	{ "P3_AD_STICK_Z",			IKT_IPT,		IPF_PLAYER3 | IPT_AD_STICK_Z },
	{ "P3_AD_STICK_Z_EXT",		IKT_IPT_EXT,	IPF_PLAYER3 | IPT_AD_STICK_Z },
	{ "P4_AD_STICK_Z",			IKT_IPT,		IPF_PLAYER4 | IPT_AD_STICK_Z },
	{ "P4_AD_STICK_Z_EXT",		IKT_IPT_EXT,	IPF_PLAYER4 | IPT_AD_STICK_Z },

	{ "OSD_1",					IKT_IPT,		IPT_OSD_1 },
	{ "OSD_2",					IKT_IPT,		IPT_OSD_2 },
	{ "OSD_3",					IKT_IPT,		IPT_OSD_3 },
	{ "OSD_4",					IKT_IPT,		IPT_OSD_4 },

	{ "UNKNOWN",				IKT_IPT,		IPT_UNKNOWN },
	{ "END",					IKT_IPT,		IPT_END },

	{ "",						0,	0 }
};

int num_ik = sizeof(input_keywords)/sizeof(struct ik);

/***************************************************************************/
/* Generic IO */

static int readint(mame_file *f,UINT32 *num)
{
	unsigned i;

	*num = 0;
	for (i = 0;i < sizeof(UINT32);i++)
	{
		unsigned char c;


		*num <<= 8;
		if (mame_fread(f,&c,1) != 1)
			return -1;
		*num |= c;
	}

	return 0;
}

static void writeint(mame_file *f,UINT32 num)
{
	unsigned i;

	for (i = 0;i < sizeof(UINT32);i++)
	{
		unsigned char c;


		c = (num >> 8 * (sizeof(UINT32)-1)) & 0xff;
		mame_fwrite(f,&c,1);
		num <<= 8;
	}
}

static int readword(mame_file *f,UINT16 *num)
{
	unsigned i;
	int res;

	res = 0;
	for (i = 0;i < sizeof(UINT16);i++)
	{
		unsigned char c;


		res <<= 8;
		if (mame_fread(f,&c,1) != 1)
			return -1;
		res |= c;
	}

	*num = res;
	return 0;
}

#ifdef KAILLERA
void writeword(mame_file *f,UINT16 num)
#else
static void writeword(mame_file *f,UINT16 num)
#endif
{
	unsigned i;

	for (i = 0;i < sizeof(UINT16);i++)
	{
		unsigned char c;


		c = (num >> 8 * (sizeof(UINT16)-1)) & 0xff;
		mame_fwrite(f,&c,1);
		num <<= 8;
	}
}

#ifndef NOLEGACY
#include "legacy.h"
#endif

static int seq_read_ver_8(void* f, InputSeq* seq)
{
	int j,len;
	UINT32 i;
	UINT16 w;

	if (readword(f,&w) != 0)
		return -1;

	len = w;
	seq_set_0(seq);
	for(j=0;j<len;++j)
	{
		if (readint(f,&i) != 0)
 			return -1;
		(*seq)[j] = savecode_to_code(i);
 	}

 	return 0;
  }

static int seq_read(void* f, InputSeq* seq, int ver)
  {
#ifdef NOLEGACY
	if (ver==8)
		return seq_read_ver_8(f,seq);
#else
	switch (ver) {
		case 5 : return seq_read_ver_5(f,seq);
		case 6 : return seq_read_ver_6(f,seq);
		case 7 : return seq_read_ver_7(f,seq);
		case 8 : return seq_read_ver_8(f,seq);
	}
#endif
	return -1;
  }

static void seq_write(void* f, InputSeq* seq)
  {
	int j,len;
        for(len=0;len<SEQ_MAX;++len)
		if ((*seq)[len] == CODE_NONE)
			break;
	writeword(f,len);
	for(j=0;j<len;++j)
		writeint(f, code_to_savecode( (*seq)[j] ));
  }

/***************************************************************************/
/* Load */

static void load_default_keys(void)
{
	mame_file *f;


	osd_customize_inputport_defaults(inputport_defaults);
	memcpy(inputport_defaults_backup,inputport_defaults,sizeof(inputport_defaults));

	if ((f = mame_fopen("default",0,FILETYPE_CONFIG,0)) != 0)
	{
		char buf[8];
		int version;

		/* read header */
		if (mame_fread(f,buf,8) != 8)
			goto getout;

		if (memcmp(buf,MAMEDEFSTRING_V5,8) == 0)
			version = 5;
		else if (memcmp(buf,MAMEDEFSTRING_V6,8) == 0)
			version = 6;
		else if (memcmp(buf,MAMEDEFSTRING_V7,8) == 0)
			version = 7;
		else if (memcmp(buf,MAMEDEFSTRING_V8,8) == 0)
			version = 8;
		else
			goto getout;	/* header invalid */

		for (;;)
		{
			UINT32 type;
			InputSeq def_seq;
			InputSeq seq;
			int i;

			if (readint(f,&type) != 0)
				goto getout;

			if (seq_read(f,&def_seq,version)!=0)
				goto getout;
			if (seq_read(f,&seq,version)!=0)
				goto getout;

			i = 0;
			while (inputport_defaults[i].type != IPT_END)
			{
				if (inputport_defaults[i].type == type)
				{
					/* load stored settings only if the default hasn't changed */
					if (seq_cmp(&inputport_defaults[i].seq,&def_seq)==0)
						seq_copy(&inputport_defaults[i].seq,&seq);
				}

				i++;
			}
		}

getout:
		mame_fclose(f);
	}
}

static void save_default_keys(void)
{
	mame_file *f;


	if ((f = mame_fopen("default",0,FILETYPE_CONFIG,1)) != 0)
	{
		int i;


		/* write header */
		mame_fwrite(f,MAMEDEFSTRING_V8,8);

		i = 0;
		while (inputport_defaults[i].type != IPT_END)
		{
			if (inputport_defaults[i].type != IPT_OSD_RESERVED)
			{
				writeint(f,inputport_defaults[i].type);

				seq_write(f,&inputport_defaults_backup[i].seq);
				seq_write(f,&inputport_defaults[i].seq);
			}

			i++;
		}

		mame_fclose(f);
	}
	memcpy(inputport_defaults,inputport_defaults_backup,sizeof(inputport_defaults_backup));
}

static int input_port_read_ver_8(void *f,struct InputPort *in)
{
	UINT32 i;
	UINT16 w;
	if (readint(f,&i) != 0)
		return -1;
	in->type = i;

	if (readword(f,&w) != 0)
		return -1;
	in->mask = w;

	if (readword(f,&w) != 0)
		return -1;
	in->default_value = w;

	if (seq_read_ver_8(f,&in->seq) != 0)
		return -1;

	return 0;
}

static int input_port_read(void *f,struct InputPort *in, int ver)
{
#ifdef NOLEGACY
	if (ver==8)
		return input_port_read_ver_8(f,in);
#else
	switch (ver) {
		case 5 : return	input_port_read_ver_5(f,in);
		case 6 : return	input_port_read_ver_6(f,in);
		case 7 : return	input_port_read_ver_7(f,in);
		case 8 : return	input_port_read_ver_8(f,in);
	}
#endif
	return -1;
}

static void input_port_write(void *f,struct InputPort *in)
{
	writeint(f,in->type);
	writeword(f,in->mask);
	writeword(f,in->default_value);
	seq_write(f,&in->seq);
}


int load_input_port_settings(void)
{
	mame_file *f;
#ifdef MAME_NET
    struct InputPort *in;
    int port, player;
#endif /* MAME_NET */


	load_default_keys();

	if ((f = mame_fopen(Machine->gamedrv->name,0,FILETYPE_CONFIG,0)) != 0)
	{
#ifndef MAME_NET
		struct InputPort *in;
#endif
		unsigned int total,savedtotal;
		char buf[8];
		int i;
		int version;

		in = Machine->input_ports_default;

		/* calculate the size of the array */
		total = 0;
		while (in->type != IPT_END)
		{
			total++;
			in++;
		}

		/* read header */
		if (mame_fread(f,buf,8) != 8)
			goto getout;

		if (memcmp(buf,MAMECFGSTRING_V5,8) == 0)
			version = 5;
		else if (memcmp(buf,MAMECFGSTRING_V6,8) == 0)
			version = 6;
		else if (memcmp(buf,MAMECFGSTRING_V7,8) == 0)
			version = 7;
		else if (memcmp(buf,MAMECFGSTRING_V8,8) == 0)
			version = 8;
		else
			goto getout;	/* header invalid */

		/* read array size */
		if (readint(f,&savedtotal) != 0)
			goto getout;
		if (total != savedtotal)
			goto getout;	/* different size */

		/* read the original settings and compare them with the ones defined in the driver */
		in = Machine->input_ports_default;
		while (in->type != IPT_END)
		{
			struct InputPort saved;

			if (input_port_read(f,&saved,version) != 0)
				goto getout;

			if (in->mask != saved.mask ||
				in->default_value != saved.default_value ||
				in->type != saved.type ||
				seq_cmp(&in->seq,&saved.seq) !=0 )
			goto getout;	/* the default values are different */

			in++;
		}

		/* read the current settings */
		in = Machine->input_ports;
		while (in->type != IPT_END)
		{
#ifdef KAILLERA
			if (kPlay && ((in->type & ~IPF_MASK) == IPT_DIPSWITCH_NAME)) {
				struct InputPort temp;
				if (input_port_read(f,&temp,version) != 0)
					goto getout;
                  } else 
			if (kPlay && ((in->type & ~IPF_MASK) == IPT_EXTENSION)) {
				struct InputPort temp;
				if (input_port_read(f,&temp,version) != 0)
					goto getout;
                  } else 
			if (kPlay && (((in->type & ~IPF_MASK) > IPT_ANALOG_START)
				&& ((in->type & ~IPF_MASK) < IPT_ANALOG_END)) ) {
				struct InputPort temp;
				if (input_port_read(f,&temp,version) != 0)
					goto getout;
                  } else 
#endif /* KAILLERA */
			if (input_port_read(f,in,version) != 0)
				goto getout;
			in++;
		}

		/* Clear the coin & ticket counters/flags - LBO 042898 */
		for (i = 0; i < COIN_COUNTERS; i ++)
			coins[i] = lastcoin[i] = coinlockedout[i] = 0;
		dispensed_tickets = 0;

		/* read in the coin/ticket counters */
		for (i = 0; i < COIN_COUNTERS; i ++)
		{
			if (readint(f,&coins[i]) != 0)
				goto getout;
		}
		if (readint(f,&dispensed_tickets) != 0)
			goto getout;

		mixer_read_config(f);

#ifdef KAILLERA
		if(!kPlay) {
			overclock_read_config(f);
		}
#endif
getout:
		mame_fclose(f);
	}

	/* All analog ports need initialization */
	{
		int i;
		for (i = 0; i < MAX_INPUT_PORTS; i++)
			input_analog_init[i] = 1;
	}
#ifdef MAME_NET
	/* Find out what port is used by what player and swap regular inputs */
	in = Machine->input_ports;

//	if (in->type == IPT_END) return; 	/* nothing to do */

	/* make sure the InputPort definition is correct */
//	if (in->type != IPT_PORT)
//	{
//		logerror("Error in InputPort definition: expecting PORT_START\n");
//		return;
//	}
//	else in++;
	in++;

	/* scan all the input ports */
	port = 0;
	while (in->type != IPT_END && port < MAX_INPUT_PORTS)
	{
		/* now check the input bits. */
		while (in->type != IPT_END && in->type != IPT_PORT)
		{
			if ((in->type & ~IPF_MASK) != IPT_DIPSWITCH_SETTING &&	/* skip dipswitch definitions */
				(in->type & ~IPF_MASK) != IPT_EXTENSION &&			/* skip analog extension fields */
				(in->type & IPF_UNUSED) == 0 &&						/* skip unused bits */
				!(!options.cheat && (in->type & IPF_CHEAT)) &&				/* skip cheats if cheats disabled */
				(in->type & ~IPF_MASK) != IPT_VBLANK &&				/* skip vblank stuff */
				((in->type & ~IPF_MASK) >= IPT_COIN1 &&				/* skip if coin input and it's locked out */
				(in->type & ~IPF_MASK) <= IPT_COIN4 &&
                 coinlockedout[(in->type & ~IPF_MASK) - IPT_COIN1]))
			{
				player = 0;
				if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER2) player = 1;
				else if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER3) player = 2;
				else if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER4) player = 3;

				if (((in->type & ~IPF_MASK) > IPT_ANALOG_START)
					&& ((in->type & ~IPF_MASK) < IPT_ANALOG_END))
				{
					analog_player_port[port] = player;
				}
				if (((in->type & ~IPF_MASK) == IPT_BUTTON1) ||
					((in->type & ~IPF_MASK) == IPT_BUTTON2) ||
					((in->type & ~IPF_MASK) == IPT_BUTTON3) ||
					((in->type & ~IPF_MASK) == IPT_BUTTON4) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICK_UP) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICK_DOWN) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICK_LEFT) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICK_RIGHT) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKRIGHT_UP) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKRIGHT_DOWN) ||
 					((in->type & ~IPF_MASK) == IPT_JOYSTICKRIGHT_LEFT) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKRIGHT_RIGHT) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKLEFT_UP) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKLEFT_DOWN) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKLEFT_LEFT) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKLEFT_RIGHT) ||
					((in->type & ~IPF_MASK) == IPT_PADDLE) ||
					((in->type & ~IPF_MASK) == IPT_DIAL) ||
					((in->type & ~IPF_MASK) == IPT_TRACKBALL_X) ||
					((in->type & ~IPF_MASK) == IPT_TRACKBALL_Y) ||
					((in->type & ~IPF_MASK) == IPT_LIGHTGUN_X) ||
					((in->type & ~IPF_MASK) == IPT_LIGHTGUN_Y) ||
					((in->type & ~IPF_MASK) == IPT_AD_STICK_X) ||
					((in->type & ~IPF_MASK) == IPT_AD_STICK_Y) ||
					((in->type & ~IPF_MASK) == IPT_AD_STICK_Z))
				{
					switch (default_player)
					{
						case 0:
							/* do nothing */
							break;
						case 1:
							if (player == 0)
							{
								in->type &= ~IPF_PLAYER1;
								in->type |= IPF_PLAYER2;
							}
							else if (player == 1)
							{
								in->type &= ~IPF_PLAYER2;
								in->type |= IPF_PLAYER1;
							}
							break;
						case 2:
							if (player == 0)
							{
								in->type &= ~IPF_PLAYER1;
								in->type |= IPF_PLAYER3;
							}
							else if (player == 2)
							{
								in->type &= ~IPF_PLAYER3;
								in->type |= IPF_PLAYER1;
							}
							break;
						case 3:
							if (player == 0)
							{
								in->type &= ~IPF_PLAYER1;
								in->type |= IPF_PLAYER4;
							}
							else if (player == 3)
							{
								in->type &= ~IPF_PLAYER4;
								in->type |= IPF_PLAYER1;
							}
							break;
					}
				}
			}
			in++;
		}
		port++;
		if (in->type == IPT_PORT) in++;
	}

	/* TODO: at this point the games should initialize peers to same as server */

#endif /* MAME_NET */

#ifdef KAILLERA
	if (kPlay)
	{
		struct InputPort *in;
		int port;
		int i;
		control_type = 0;

		memset(&kBitsPlayValues,-1,sizeof(kBitsPlayValues));

		in = Machine->input_ports;
		in++;

		port = 0;
		while (in->type != IPT_END && port < MAX_INPUT_PORTS)
		{
			while (in->type != IPT_END && in->type != IPT_PORT)
			{
				int player=-1,pos=-1;

				if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER1) player=0;
				if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER2) player=1;
				if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER3) player=2;
				if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER4) player=3;

                        switch(in->type & ~IPF_MASK)
				{
					  case IPT_BUTTON1:
						if(kBitsPlayValues[player][0][0] != -1) {
							kBitsPlayValues[player][0][4] = port;
							kBitsPlayValues[player][0][5] = in->mask;
							break;
						} else {
							pos=0; break;
						}
	  				  case IPT_BUTTON2:
						if(kBitsPlayValues[player][1][0] != -1) {
							kBitsPlayValues[player][1][4] = port;
							kBitsPlayValues[player][1][5] = in->mask;
							break;
						} else {
							pos=1; break;
						}
					  case IPT_BUTTON3:
						if(kBitsPlayValues[player][2][0] != -1) {
							kBitsPlayValues[player][2][4] = port;
							kBitsPlayValues[player][2][5] = in->mask;
							break;
						} else {
							pos=2; break;
						}
					  case IPT_BUTTON4:
						if(kBitsPlayValues[player][3][0] != -1) {
							kBitsPlayValues[player][3][4] = port;
							kBitsPlayValues[player][3][5] = in->mask;
							break;
						} else {
							pos=3; break;
						}
					  case IPT_BUTTON5:
						if(kBitsPlayValues[player][4][0] != -1) {
							kBitsPlayValues[player][4][4] = port;
							kBitsPlayValues[player][4][5] = in->mask;
							break;
						} else {
							pos=4; break;
						}
					  case IPT_BUTTON6:
						if(kBitsPlayValues[player][5][0] != -1) {
							kBitsPlayValues[player][5][4] = port;
							kBitsPlayValues[player][5][5] = in->mask;
							break;
						} else {
							pos=5; break;
						}
                                case IPT_BUTTON7:
						if(kBitsPlayValues[player][6][0] != -1) {
							kBitsPlayValues[player][6][4] = port;
							kBitsPlayValues[player][6][5] = in->mask;
							break;
						} else {
							pos=6; break;
						}

                                case IPT_JOYSTICK_UP:
						if(kBitsPlayValues[player][7][0] != -1) {
							kBitsPlayValues[player][7][4] = port;
							kBitsPlayValues[player][7][5] = in->mask;
							break;
						} else {
							pos=7; break;
						}
				
                                case IPT_JOYSTICK_DOWN:
						if(kBitsPlayValues[player][8][0] != -1) {
							kBitsPlayValues[player][8][4] = port;
							kBitsPlayValues[player][8][5] = in->mask;
							break;
						} else {
							pos=8; break;
						}
						
                                case IPT_JOYSTICK_LEFT:
						if(kBitsPlayValues[player][9][0] != -1) {
							kBitsPlayValues[player][9][4] = port;
							kBitsPlayValues[player][9][5] = in->mask;
							break;
						} else {
							pos=9; break;
						}
						
                                case IPT_JOYSTICK_RIGHT:
						if(kBitsPlayValues[player][10][0] != -1) {
							kBitsPlayValues[player][10][4] = port;
							kBitsPlayValues[player][10][5] = in->mask;
							break;
						} else {
							pos=10; break;
						}
						
                                case IPT_COIN1:
						if(kBitsPlayValues[0][11][0] != -1) {
							kBitsPlayValues[0][11][4] = port;
							kBitsPlayValues[0][11][5] = in->mask;
							break;
						} else {
							player=0; pos=11; break;
						}
						
                                case IPT_START1:
						if(kBitsPlayValues[0][12][0] != -1) {
							kBitsPlayValues[0][12][4] = port;
							kBitsPlayValues[0][12][5] = in->mask;
							break;
						} else {
							player=0; pos=12; break;
						}
						
                                case IPT_COIN2:
						if(kBitsPlayValues[1][11][0] != -1) {
							kBitsPlayValues[1][11][4] = port;
							kBitsPlayValues[1][11][5] = in->mask;
							break;
						} else {
							player=1; pos=11; break;
						}
						
                                case IPT_START2:
						if(kBitsPlayValues[1][12][0] != -1) {
							kBitsPlayValues[1][12][4] = port;
							kBitsPlayValues[1][12][5] = in->mask;
							break;
						} else {
							player=1; pos=12; break;
						}
						
                                case IPT_COIN3:
						if(kBitsPlayValues[2][11][0] != -1) {
							kBitsPlayValues[2][11][4] = port;
							kBitsPlayValues[2][11][5] = in->mask;
							break;
						} else {
							player=2; pos=11; break;
						}
						
                                case IPT_START3:
						if(kBitsPlayValues[2][12][0] != -1) {
							kBitsPlayValues[2][12][4] = port;
							kBitsPlayValues[2][12][5] = in->mask;
							break;
						} else {
							player=2; pos=12; break;
						}
						
                                case IPT_COIN4:
						if(kBitsPlayValues[3][11][0] != -1) {
							kBitsPlayValues[3][11][4] = port;
							kBitsPlayValues[3][11][5] = in->mask;
							break;
						} else {
							player=3; pos=11; break;
						}
						
                                case IPT_START4: 
						if(kBitsPlayValues[3][12][0] != -1) {
							kBitsPlayValues[3][12][4] = port;
							kBitsPlayValues[3][12][5] = in->mask;
							break;
						} else {
							player=3; pos=12; break;
						}
						
                                case IPT_SERVICE:
						player=0; pos=13; break;
						
					  case IPT_JOYSTICKRIGHT_UP:
						if(kBitsPlayValues[player][7][0] != -1) {
							kBitsPlayValues[player][7][4] = port;
							kBitsPlayValues[player][7][5] = in->mask;
							break;
						} else {
							pos=7; break;
						}
						
				   	  case IPT_JOYSTICKRIGHT_DOWN:
						if(kBitsPlayValues[player][8][0] != -1) {
							kBitsPlayValues[player][8][4] = port;
							kBitsPlayValues[player][8][5] = in->mask;
							break;
						} else {
							pos=8; break;
						}
						
					  case IPT_JOYSTICKRIGHT_LEFT:
						if(kBitsPlayValues[player][9][0] != -1) {
							kBitsPlayValues[player][9][4] = port;
							kBitsPlayValues[player][9][5] = in->mask;
							break;
						} else {
							pos=9; break;
						}
						
					  case IPT_JOYSTICKRIGHT_RIGHT:
						if(kBitsPlayValues[player][10][0] != -1) {
							kBitsPlayValues[player][10][4] = port;
							kBitsPlayValues[player][10][5] = in->mask;
							break;
						} else {
							pos=10; break;
						}
						
					  case IPT_JOYSTICKLEFT_UP:
						if(kBitsPlayValues[player][3][0] != -1) {
							kBitsPlayValues[player][3][4] = port;
							kBitsPlayValues[player][3][5] = in->mask;
							break;
						} else {
							pos=3; break;
						}
						
					  case IPT_JOYSTICKLEFT_DOWN:
						if(kBitsPlayValues[player][4][0] != -1) {
							kBitsPlayValues[player][4][4] = port;
							kBitsPlayValues[player][4][5] = in->mask;
							break;
						} else {
							pos=4; break;
						}
						
					  case IPT_JOYSTICKLEFT_LEFT:
						if(kBitsPlayValues[player][5][0] != -1) {
							kBitsPlayValues[player][5][4] = port;
							kBitsPlayValues[player][5][5] = in->mask;
							break;
						} else {
							pos=5; break;
						}

					  case IPT_JOYSTICKLEFT_RIGHT:
						if(kBitsPlayValues[player][6][0] != -1) {
							kBitsPlayValues[player][6][4] = port;
							kBitsPlayValues[player][6][5] = in->mask;
							break;
						} else {
							pos=6; break;
						}

                                case IPT_SERVICE3:
						player=0; pos=14; break;

                                case IPT_SERVICE1:
						player=0; pos=14; break;

					  case IPT_PADDLE:
						kBitsPlayValues[player][5][0]=port;    
						kBitsPlayValues[player][5][1]=in->mask;                      
						kBitsPlayValues[player][5][2]=in->default_value;                                        
						kBitsPlayValues[player][5][3]=2048;         
						kBitsPlayValues[player][6][0]=port;    
						kBitsPlayValues[player][6][1]=in->mask;                      
						kBitsPlayValues[player][6][2]=in->default_value;                                        
						kBitsPlayValues[player][6][3]=4096;                      
						control_type = 1;
						break;

					  case IPT_PADDLE_V:
						kBitsPlayValues[player][3][0]=port;    
						kBitsPlayValues[player][3][1]=in->mask;                      
						kBitsPlayValues[player][3][2]=in->default_value;                                        
						kBitsPlayValues[player][3][3]=512;         
						kBitsPlayValues[player][4][0]=port;    
						kBitsPlayValues[player][4][1]=in->mask;                      
						kBitsPlayValues[player][4][2]=in->default_value;                                        
						kBitsPlayValues[player][4][3]=1024;                      
						control_type = 1;
						break;

					  case IPT_DIAL:
						kBitsPlayValues[player][5][0]=port;    
						kBitsPlayValues[player][5][1]=in->mask;                      
						kBitsPlayValues[player][5][2]=in->default_value;                                        
						kBitsPlayValues[player][5][3]=2048;         
						kBitsPlayValues[player][6][0]=port;    
						kBitsPlayValues[player][6][1]=in->mask;                      
						kBitsPlayValues[player][6][2]=in->default_value;                                        
						kBitsPlayValues[player][6][3]=4096;                      
						control_type = 1;
						break;

					  case IPT_DIAL_V:
						kBitsPlayValues[player][3][0]=port;    
						kBitsPlayValues[player][3][1]=in->mask;                      
						kBitsPlayValues[player][3][2]=in->default_value;                                        
						kBitsPlayValues[player][3][3]=512;         
						kBitsPlayValues[player][4][0]=port;    
						kBitsPlayValues[player][4][1]=in->mask;                      
						kBitsPlayValues[player][4][2]=in->default_value;                                        
						kBitsPlayValues[player][4][3]=1024;                      
						control_type = 1;
						break;

					  case IPT_TRACKBALL_X:
						kBitsPlayValues[player][5][0]=port;    
						kBitsPlayValues[player][5][1]=in->mask;                      
						kBitsPlayValues[player][5][2]=in->default_value;                                        
						kBitsPlayValues[player][5][3]=2048;         
						kBitsPlayValues[player][6][0]=port;    
						kBitsPlayValues[player][6][1]=in->mask;                      
						kBitsPlayValues[player][6][2]=in->default_value;                                        
						kBitsPlayValues[player][6][3]=4096;                      
						control_type = 1;
						break;

					  case IPT_TRACKBALL_Y:
						kBitsPlayValues[player][3][0]=port;    
						kBitsPlayValues[player][3][1]=in->mask;                      
						kBitsPlayValues[player][3][2]=in->default_value;                                        
						kBitsPlayValues[player][3][3]=512;         
						kBitsPlayValues[player][4][0]=port;    
						kBitsPlayValues[player][4][1]=in->mask;                      
						kBitsPlayValues[player][4][2]=in->default_value;                                        
						kBitsPlayValues[player][4][3]=1024;                      
						control_type = 1;
						break;

					  case IPT_AD_STICK_X:
						kBitsPlayValues[player][5][0]=port;    
						kBitsPlayValues[player][5][1]=in->mask;                      
						kBitsPlayValues[player][5][2]=in->default_value;                                        
						kBitsPlayValues[player][5][3]=2048;         
						kBitsPlayValues[player][6][0]=port;    
						kBitsPlayValues[player][6][1]=in->mask;                      
						kBitsPlayValues[player][6][2]=in->default_value;                                        
						kBitsPlayValues[player][6][3]=4096;
						control_type = 1;
						break;

					  case IPT_AD_STICK_Y:
						kBitsPlayValues[player][3][0]=port;    
						kBitsPlayValues[player][3][1]=in->mask;                      
						kBitsPlayValues[player][3][2]=in->default_value;                                        
						kBitsPlayValues[player][3][3]=512;         
						kBitsPlayValues[player][4][0]=port;    
						kBitsPlayValues[player][4][1]=in->mask;                      
						kBitsPlayValues[player][4][2]=in->default_value;                                        
						kBitsPlayValues[player][4][3]=1024;                      
						control_type = 1;
						break;

					  case IPT_LIGHTGUN_X:
						kBitsPlayValues[player][5][0]=port;    
						kBitsPlayValues[player][5][1]=in->mask;                      
						kBitsPlayValues[player][5][2]=in->default_value;                                        
						kBitsPlayValues[player][5][3]=2048;         
						kBitsPlayValues[player][6][0]=port;    
						kBitsPlayValues[player][6][1]=in->mask;                      
						kBitsPlayValues[player][6][2]=in->default_value;                                        
						kBitsPlayValues[player][6][3]=4096;
						control_type = 1;
						break;

					  case IPT_LIGHTGUN_Y:
						kBitsPlayValues[player][3][0]=port;    
						kBitsPlayValues[player][3][1]=in->mask;                      
						kBitsPlayValues[player][3][2]=in->default_value;                                        
						kBitsPlayValues[player][3][3]=512;         
						kBitsPlayValues[player][4][0]=port;    
						kBitsPlayValues[player][4][1]=in->mask;                      
						kBitsPlayValues[player][4][2]=in->default_value;                                        
						kBitsPlayValues[player][4][3]=1024;                      
						control_type = 1;
						break;

					  case IPT_PEDAL:
						kBitsPlayValues[player][4][0]=port;    
						kBitsPlayValues[player][4][1]=in->mask;                      
						kBitsPlayValues[player][4][2]=in->default_value;                                        
						kBitsPlayValues[player][4][3]=1;
						control_type = 1;
						break;      

					  case IPT_PEDAL2:
						kBitsPlayValues[player][4][0]=port;    
						kBitsPlayValues[player][4][1]=in->mask;                      
						kBitsPlayValues[player][4][2]=in->default_value;                                        
						kBitsPlayValues[player][4][3]=1;
						control_type = 1;
						break;      

					  case 0:
					{
						if((in->type == IPT_UNUSED) ||
						   (in->type == IPT_SPECIAL))
						{
						}
						else if(in->name && !strcmp(in->name, "Test Switch"))
						{
	     	                              player=0; pos=13;
						}
						else if((in->name && !strcmp(in->name, "P1 Kan")) ||
							  (in->name && !strcmp(in->name, "Kan")))
						{
							player=0; pos=0; control_type = 2;
						}
						else if((in->name && !strcmp(in->name, "P1 M")) ||
							  (in->name && !strcmp(in->name, "M")))
						{
							player=0; pos=1; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 I")) ||
							  (in->name && !strcmp(in->name, "I")))
						{
							player=0; pos=2; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 E")) ||
							  (in->name && !strcmp(in->name, "E")))
						{
							player=0; pos=3; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 A")) ||
							  (in->name && !strcmp(in->name, "A")))
						{
							player=0; pos=4; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 Bet")) ||
							  (in->name && !strcmp(in->name, "Bet")))
						{
							player=0; pos=5; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 Reach")) ||
							  (in->name && !strcmp(in->name, "Reach")))
						{
							player=0; pos=6; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 N")) ||
							  (in->name && !strcmp(in->name, "N")))
						{
							player=0; pos=7; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 J")) ||
							  (in->name && !strcmp(in->name, "J")))
						{
							player=0; pos=8; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 F")) ||
							  (in->name && !strcmp(in->name, "F")))
						{
							player=0; pos=9; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 B")) ||
							  (in->name && !strcmp(in->name, "B")))
						{
							player=0; pos=10; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 Ron")) ||
							  (in->name && !strcmp(in->name, "Ron")))
						{
							player=0; pos=15; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 Chi")) ||
							  (in->name && !strcmp(in->name, "Chi")))
						{
							player=0; pos=16; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 K")) ||
							  (in->name && !strcmp(in->name, "K")))
						{
							player=0; pos=17; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 G")) ||
							  (in->name && !strcmp(in->name, "G")))
						{
							player=0; pos=18; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 C")) ||
							  (in->name && !strcmp(in->name, "C")))
						{
							player=0; pos=19; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 Pon")) ||
							  (in->name && !strcmp(in->name, "Pon")))
						{
							player=0; pos=20; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 L")) ||
							  (in->name && !strcmp(in->name, "L")))
						{
							player=0; pos=21; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 H")) ||
							  (in->name && !strcmp(in->name, "H")))
						{
							player=0; pos=22; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 D")) ||
							  (in->name && !strcmp(in->name, "D")))
						{
							player=0; pos=23; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 Small")) ||
							  (in->name && !strcmp(in->name, "Small")))
						{
							player=0; pos=24; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 Big")) ||
							  (in->name && !strcmp(in->name, "Big")))
						{
							player=0; pos=25; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 Flip")) ||
							  (in->name && !strcmp(in->name, "Flip")))
						{
							player=0; pos=26; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 Double Up")) ||
							  (in->name && !strcmp(in->name, "Double Up")))
						{
							player=0; pos=27; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 Take Score")) ||
							  (in->name && !strcmp(in->name, "Take Score")))
						{
							player=0; pos=28; control_type = 2; 
						}
						else if((in->name && !strcmp(in->name, "P1 Last Chance")) ||
							  (in->name && !strcmp(in->name, "Last Chance")))
						{
							player=0; pos=29; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 Kan"))
						{
							player=1; pos=0; control_type = 2;
						}
						else if(in->name && !strcmp(in->name, "P2 M"))
						{
							player=1; pos=1; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 I"))
						{
							player=1; pos=2; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 E"))
						{
							player=1; pos=3; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 A"))
						{
							player=1; pos=4; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 Bet"))
						{
							player=1; pos=5; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 Reach"))
						{
							player=1; pos=6; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 N"))
						{
							player=1; pos=7; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 J"))
						{
							player=1; pos=8; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 F"))
						{
							player=1; pos=9; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 B"))
						{
							player=1; pos=10; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 Ron"))
						{
							player=1; pos=15; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 Chi"))
						{
							player=1; pos=16; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 K"))
						{
							player=1; pos=17; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 G"))
						{
							player=1; pos=18; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 C"))
						{
							player=1; pos=19; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 Pon"))
						{
							player=1; pos=20; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 L"))
						{
							player=1; pos=21; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 H"))
						{
							player=1; pos=22; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 D"))
						{
							player=1; pos=23; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 Small"))
						{
							player=1; pos=24; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 Big"))
						{
							player=1; pos=25; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 Flip"))
						{
							player=1; pos=26; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 Double Up"))
						{
							player=1; pos=27; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 Take Score"))
						{
							player=1; pos=28; control_type = 2; 
						}
						else if(in->name && !strcmp(in->name, "P2 Last Chance"))
						{
							player=1; pos=29; control_type = 2; 
						}
					}
					break;
                        }
                    
				if(pos!=-1 && player!=-1)
				{
					kBitsPlayValues[player][pos][0]=port;
					kBitsPlayValues[player][pos][1]=in->mask;
					kBitsPlayValues[player][pos][2]=in->default_value;
				}
				in++;
			}
			port++;
			if (in->type == IPT_PORT) in++;
		}
		kFirstMsg=1;
		kUpdateDip        = 0;
		kdipcounter       = 0;
		kgotdip           = 0;
		kcrccounter       = 0;
		kgotcrc           = 0;
		ksavecounter      = 0;
		p1_pos            = 1;
		p1			= 0;
		p2			= 1;
		p3			= 2;
		p4			= 3;
		p5			= 4;
		p6			= 5;
		p7			= 6;
		p8			= 7;
		ana_p1		= 0;
		ana_p2		= 1;
		ana_p3		= 2;
		ana_p4		= 3;
		control_counter   = 0;
		kaillera_schedule = KS_NONE;
		mouse_delta_axis[0][0] = 0;
		mouse_delta_axis[0][1] = 0;
		for (i = 0; i < 4; i++) {
			deltax[i] = 0;
			deltay[i] = 0;
		}
		for (i = 0; i < 10; i++) {
			val[i] = 0;
			val2[i] = 0;
		}	

if (!strcmp(Machine->gamedrv->name,"kof2000_6p")) game = kof2000_6p;
else if (!strcmp(Machine->gamedrv->name,"kof98_6p")) game = kof98_6p;
else if (!strcmp(Machine->gamedrv->name,"mvsc4p")) game = mvsc4p;
else if (!strcmp(Machine->gamedrv->name,"mvscj4p")) game = mvsc4p;
else if (!strcmp(Machine->gamedrv->name,"mshvsfj4p")) game = mshvsf4p;
else if (!strcmp(Machine->gamedrv->name,"mshvsf4p")) game = mshvsf4p;
else if (!strcmp(Machine->gamedrv->name,"xmvsf4p")) game = xmvsf4p;
else if (!strcmp(Machine->gamedrv->name,"xmvsfj4p")) game = xmvsf4p;
else if (!strcmp(Machine->gamedrv->name,"kof99_6p")) game = kof99_6p;
else if (!strcmp(Machine->gamedrv->name,"kof97_6p")) game = kof97_6p;
else if (!strcmp(Machine->gamedrv->name,"kof96_6p")) game = kof96_6p;
else if (!strcmp(Machine->gamedrv->name,"kizuna_4p")) game = kizuna_4p;
else if (!strcmp(Machine->gamedrv->name,"lbowling_4p")) game = lbowling_4p;
else if (!strcmp(Machine->gamedrv->name,"kof2001_8p")) game = kof2001_8p;
else if (!strcmp(Machine->gamedrv->name,"kof2002_6p")) game = kof2002_6p;
else if (!strcmp(Machine->gamedrv->name,"rotd_4p")) game = rotd_4p;
else if (!strcmp(Machine->gamedrv->name,"cyberbt2p")) game = cyberbt2p;
else if (!strcmp(Machine->gamedrv->name,"loderndf_vs")) game = loderndf_vs;
else game = none;

	}

	endemu = 0;
	special_key = 0;
	init = -1;
	netplay_pause = -1;
#endif /* KAILLERA */

	init_analog_seq();

	update_input_ports();

	/* if we didn't find a saved config, return 0 so the main core knows that it */
	/* is the first time the game is run and it should diplay the disclaimer. */
	if (f) return 1;
	else return 0;
}

/***************************************************************************/
/* Save */

void save_input_port_settings(void)
{
	mame_file *f;
#ifdef MAME_NET
	struct InputPort *in;
	int port, player;

	/* Swap input port definitions back to defaults */
	in = Machine->input_ports;

	if (in->type == IPT_END) return; 	/* nothing to do */

	/* make sure the InputPort definition is correct */
	if (in->type != IPT_PORT)
	{
		logerror("Error in InputPort definition: expecting PORT_START\n");
		return;
	}
	else in++;

	/* scan all the input ports */
	port = 0;
	while (in->type != IPT_END && port < MAX_INPUT_PORTS)
	{
		/* now check the input bits. */
		while (in->type != IPT_END && in->type != IPT_PORT)
		{
			if ((in->type & ~IPF_MASK) != IPT_DIPSWITCH_SETTING &&	/* skip dipswitch definitions */
				(in->type & ~IPF_MASK) != IPT_EXTENSION &&			/* skip analog extension fields */
				(in->type & IPF_UNUSED) == 0 &&						/* skip unused bits */
				!(!options.cheat && (in->type & IPF_CHEAT)) &&				/* skip cheats if cheats disabled */
				(in->type & ~IPF_MASK) != IPT_VBLANK &&				/* skip vblank stuff */
				((in->type & ~IPF_MASK) >= IPT_COIN1 &&				/* skip if coin input and it's locked out */
				(in->type & ~IPF_MASK) <= IPT_COIN4 &&
                 coinlockedout[(in->type & ~IPF_MASK) - IPT_COIN1]))
			{
				player = 0;
				if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER2) player = 1;
				else if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER3) player = 2;
				else if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER4) player = 3;

				if (((in->type & ~IPF_MASK) == IPT_BUTTON1) ||
					((in->type & ~IPF_MASK) == IPT_BUTTON2) ||
					((in->type & ~IPF_MASK) == IPT_BUTTON3) ||
					((in->type & ~IPF_MASK) == IPT_BUTTON4) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICK_UP) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICK_DOWN) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICK_LEFT) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICK_RIGHT) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKRIGHT_UP) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKRIGHT_DOWN) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKRIGHT_LEFT) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKRIGHT_RIGHT) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKLEFT_UP) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKLEFT_DOWN) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKLEFT_LEFT) ||
					((in->type & ~IPF_MASK) == IPT_JOYSTICKLEFT_RIGHT) ||
					((in->type & ~IPF_MASK) == IPT_PADDLE) ||
					((in->type & ~IPF_MASK) == IPT_DIAL) ||
					((in->type & ~IPF_MASK) == IPT_TRACKBALL_X) ||
					((in->type & ~IPF_MASK) == IPT_TRACKBALL_Y) ||
					((in->type & ~IPF_MASK) == IPT_LIGHTGUN_X) ||
					((in->type & ~IPF_MASK) == IPT_LIGHTGUN_Y) ||
					((in->type & ~IPF_MASK) == IPT_AD_STICK_X) ||
					((in->type & ~IPF_MASK) == IPT_AD_STICK_Y) ||
					((in->type & ~IPF_MASK) == IPT_AD_STICK_Z))
				{
					switch (default_player)
					{
						case 0:
							/* do nothing */
							analog_player_port[port] = player;
							break;
						case 1:
							if (player == 0)
							{
								in->type &= ~IPF_PLAYER1;
								in->type |= IPF_PLAYER2;
								analog_player_port[port] = 1;
							}
							else if (player == 1)
							{
								in->type &= ~IPF_PLAYER2;
								in->type |= IPF_PLAYER1;
								analog_player_port[port] = 0;
							}
							break;
						case 2:
							if (player == 0)
							{
								in->type &= ~IPF_PLAYER1;
								in->type |= IPF_PLAYER3;
								analog_player_port[port] = 2;
							}
							else if (player == 2)
							{
								in->type &= ~IPF_PLAYER3;
								in->type |= IPF_PLAYER1;
								analog_player_port[port] = 0;
							}
							break;
						case 3:
							if (player == 0)
							{
								in->type &= ~IPF_PLAYER1;
								in->type |= IPF_PLAYER4;
								analog_player_port[port] = 3;
							}
							else if (player == 3)
							{
								in->type &= ~IPF_PLAYER4;
								in->type |= IPF_PLAYER1;
								analog_player_port[port] = 0;
							}
							break;
					}
				}
			}
			in++;
		}
		port++;
		if (in->type == IPT_PORT) in++;
	}
#endif /* MAME_NET */

	save_default_keys();

	if ((f = mame_fopen(Machine->gamedrv->name,0,FILETYPE_CONFIG,1)) != 0)
	{
#ifndef MAME_NET
		struct InputPort *in;
#endif /* MAME_NET */
		int total;
		int i;


		in = Machine->input_ports_default;

		/* calculate the size of the array */
		total = 0;
		while (in->type != IPT_END)
		{
			total++;
			in++;
		}

		/* write header */
		mame_fwrite(f,MAMECFGSTRING_V8,8);
		/* write array size */
		writeint(f,total);
		/* write the original settings as defined in the driver */
		in = Machine->input_ports_default;
		while (in->type != IPT_END)
		{
			input_port_write(f,in);
			in++;
		}
		/* write the current settings */
		in = Machine->input_ports;
		while (in->type != IPT_END)
		{
			input_port_write(f,in);
			in++;
		}

		/* write out the coin/ticket counters for this machine - LBO 042898 */
		for (i = 0; i < COIN_COUNTERS; i ++)
			writeint(f,coins[i]);
		writeint(f,dispensed_tickets);

		mixer_write_config(f);

#ifdef KAILLERA
		overclock_write_config(f);
#endif
		mame_fclose(f);
	}
}



/* Note that the following 3 routines have slightly different meanings with analog ports */
const char *input_port_name(const struct InputPort *in)
{
	int i;
	unsigned type;

	if (in->name != IP_NAME_DEFAULT) return in->name;

	i = 0;

	if ((in->type & ~IPF_MASK) == IPT_EXTENSION)
		type = (in-1)->type & (~IPF_MASK | IPF_PLAYERMASK);
	else
		type = in->type & (~IPF_MASK | IPF_PLAYERMASK);

	while (inputport_defaults[i].type != IPT_END &&
			inputport_defaults[i].type != type)
		i++;

	if ((in->type & ~IPF_MASK) == IPT_EXTENSION)
		return inputport_defaults[i+1].name;
	else
		return inputport_defaults[i].name;
}

InputSeq* input_port_type_seq(int type)
{
	unsigned i;

	i = 0;

	while (inputport_defaults[i].type != IPT_END &&
			inputport_defaults[i].type != type)
		i++;

	return &inputport_defaults[i].seq;
}

InputSeq* input_port_seq(const struct InputPort *in)
{
	int i,type;

	static InputSeq ip_none = SEQ_DEF_1(CODE_NONE);

	while (seq_get_1((InputSeq*)&in->seq) == CODE_PREVIOUS) in--;

	if ((in->type & ~IPF_MASK) == IPT_EXTENSION)
	{
		type = (in-1)->type & (~IPF_MASK | IPF_PLAYERMASK);
		/* if port is disabled, or cheat with cheats disabled, return no key */
		if (((in-1)->type & IPF_UNUSED) || (!options.cheat && ((in-1)->type & IPF_CHEAT)))
			return &ip_none;
	}
	else
	{
		type = in->type & (~IPF_MASK | IPF_PLAYERMASK);
		/* if port is disabled, or cheat with cheats disabled, return no key */
		if ((in->type & IPF_UNUSED) || (!options.cheat && (in->type & IPF_CHEAT)))
			return &ip_none;
	}

	if (seq_get_1((InputSeq*)&in->seq) != CODE_DEFAULT)
		return (InputSeq*)&in->seq;

	i = 0;

	while (inputport_defaults[i].type != IPT_END &&
			inputport_defaults[i].type != type)
		i++;

	if ((in->type & ~IPF_MASK) == IPT_EXTENSION)
		return &inputport_defaults[i+1].seq;
	else
		return &inputport_defaults[i].seq;
}

void update_analog_port(int port)
{
	struct InputPort *in;
	int current, delta, type, sensitivity, min, max, default_value;
	int axis, is_stick, is_gun, check_bounds;
	InputSeq* incseq;
	InputSeq* decseq;
	int keydelta;
	int player;

	/* get input definition */
	in = input_analog[port];

	/* if we're not cheating and this is a cheat-only port, bail */
	if (!options.cheat && (in->type & IPF_CHEAT)) return;
	type=(in->type & ~IPF_MASK);

	decseq = input_port_seq(in);
	incseq = input_port_seq(in+1);

	keydelta = IP_GET_DELTA(in);

	switch (type)
	{
		case IPT_PADDLE:
			axis = X_AXIS; is_stick = 1; is_gun=0; check_bounds = 1; break;
		case IPT_PADDLE_V:
			axis = Y_AXIS; is_stick = 1; is_gun=0; check_bounds = 1; break;
		case IPT_DIAL:
			axis = X_AXIS; is_stick = 0; is_gun=0; check_bounds = 0; break;
		case IPT_DIAL_V:
			axis = Y_AXIS; is_stick = 0; is_gun=0; check_bounds = 0; break;
		case IPT_TRACKBALL_X:
			axis = X_AXIS; is_stick = 0; is_gun=0; check_bounds = 0; break;
		case IPT_TRACKBALL_Y:
			axis = Y_AXIS; is_stick = 0; is_gun=0; check_bounds = 0; break;
		case IPT_AD_STICK_X:
			axis = X_AXIS; is_stick = 1; is_gun=0; check_bounds = 1; break;
		case IPT_AD_STICK_Y:
			axis = Y_AXIS; is_stick = 1; is_gun=0; check_bounds = 1; break;
		case IPT_AD_STICK_Z:
			axis = Z_AXIS; is_stick = 1; is_gun=0; check_bounds = 1; break;
		case IPT_LIGHTGUN_X:
			axis = X_AXIS; is_stick = 1; is_gun=1; check_bounds = 1; break;
		case IPT_LIGHTGUN_Y:
			axis = Y_AXIS; is_stick = 1; is_gun=1; check_bounds = 1; break;
		case IPT_PEDAL:
			axis = PEDAL_AXIS; is_stick = 1; is_gun=0; check_bounds = 1; break;
		case IPT_PEDAL2:
			axis = Z_AXIS; is_stick = 1; is_gun=0; check_bounds = 1; break;
		default:
			/* Use some defaults to prevent crash */
			axis = X_AXIS; is_stick = 0; is_gun=0; check_bounds = 0;
			logerror("Oops, polling non analog device in update_analog_port()????\n");
	}


	sensitivity = IP_GET_SENSITIVITY(in);
	min = IP_GET_MIN(in);
	max = IP_GET_MAX(in);
	default_value = in->default_value * 100 / sensitivity;
	/* extremes can be either signed or unsigned */
	if (min > max)
	{
		if (in->mask > 0xff) min = min - 0x10000;
		else min = min - 0x100;
	}

	input_analog_previous_value[port] = input_analog_current_value[port];

	/* if IPF_CENTER go back to the default position */
	/* sticks are handled later... */
	if ((in->type & IPF_CENTER) && (!is_stick))
		input_analog_current_value[port] = in->default_value * 100 / sensitivity;

	current = input_analog_current_value[port];

	delta = 0;

#ifdef KAILLERA
if(kPlay) {
	int b;

	switch (in->type & IPF_PLAYERMASK)
	{
		case IPF_PLAYER2:          player = ana_p2; break;
		case IPF_PLAYER3:          player = ana_p3; break;
		case IPF_PLAYER4:          player = ana_p4; break;
		case IPF_PLAYER1: default: player = ana_p1; break;
	}

	if (type != IPT_PEDAL && type != IPT_PEDAL2) {
		if (axis == X_AXIS)
			delta = deltax[player];
		else
			delta = deltay[player];
	}

	if(kBitsPlayValues[player][3][0] == port) {
		b = 1;
		b = b << 3;
		if (val2[player] & b) delta -= keydelta;
	}
	if(kBitsPlayValues[player][4][0] == port) {
		b = 1;
		b = b << 4;
		if (type != IPT_PEDAL && type != IPT_PEDAL2)
		{
			if (val2[player] & b) delta += keydelta;
		}
		else
		{
			if (val2[player] & b) delta += keydelta;
			else delta -= keydelta;
		}
	}
	if(kBitsPlayValues[player][5][0] == port) {
		b = 1;
		b = b << 5;
		if (val2[player] & b) delta -= keydelta;
	}
	if(kBitsPlayValues[player][6][0] == port) {
		b = 1;
		b = b << 6;
		if (val2[player] & b) delta += keydelta;
	}
	if (in->type & IPF_REVERSE) delta = -delta;
	if (is_gun) input_analog_scale[port] = 0;
}
else {
#endif
	switch (in->type & IPF_PLAYERMASK)
	{
		case IPF_PLAYER2:          player = 1; break;
		case IPF_PLAYER3:          player = 2; break;
		case IPF_PLAYER4:          player = 3; break;
		case IPF_PLAYER1: default: player = 0; break;
	}

	delta = mouse_delta_axis[player][axis];

	if (seq_pressed(decseq)) delta -= keydelta;

	if (type != IPT_PEDAL && type != IPT_PEDAL2)
	{
		if (seq_pressed(incseq)) delta += keydelta;
	}
	else
	{
		/* is this cheesy or what? */
		if (!delta && seq_get_1(incseq) == KEYCODE_Y) delta += keydelta;
		delta = -delta;
	}

	if (in->type & IPF_REVERSE) delta = -delta;

	if (is_gun)
	{
		/* The OSD lightgun call should return the delta from the middle of the screen
		when the gun is fired (not the absolute pixel value), and 0 when the gun is
		inactive.  We take advantage of this to provide support for other controllers
		in place of a physical lightgun.  When the OSD lightgun returns 0, then control
		passes through to the analog joystick, and mouse, in that order.  When the OSD
		lightgun returns a value it overrides both mouse & analog joystick.

		The value returned by the OSD layer should be -128 to 128, same as analog
		joysticks.

		There is an ugly hack to stop scaling of lightgun returned values.  It really
		needs rewritten...
		*/
		if (axis == X_AXIS) {
			if (lightgun_delta_axis[player][X_AXIS] || lightgun_delta_axis[player][Y_AXIS]) {
				analog_previous_axis[player][X_AXIS]=0;
				analog_current_axis[player][X_AXIS]=lightgun_delta_axis[player][X_AXIS];
				input_analog_scale[port]=0;
				sensitivity=100;
			}
		}
		else
		{
			if (lightgun_delta_axis[player][X_AXIS] || lightgun_delta_axis[player][Y_AXIS]) {
				analog_previous_axis[player][Y_AXIS]=0;
				analog_current_axis[player][Y_AXIS]=lightgun_delta_axis[player][Y_AXIS];
				input_analog_scale[port]=0;
				sensitivity=100;
			}
		}
	}

	if (is_stick)
	{
		int new, prev;

		/* center stick */
		if ((delta == 0) && (in->type & IPF_CENTER))
		{
			if (current > default_value)
			delta = -100 / sensitivity;
			if (current < default_value)
			delta = 100 / sensitivity;
		}

		/* An analog joystick which is not at zero position (or has just */
		/* moved there) takes precedence over all other computations */
		/* analog_x/y holds values from -128 to 128 (yes, 128, not 127) */

		new  = analog_current_axis[player][axis];
		prev = analog_previous_axis[player][axis];

		if ((new != 0) || (new-prev != 0))
		{
			delta=0;

			/* for pedals, need to change to possitive number */
			/* and, if needed, reverse pedal input */
			if (type == IPT_PEDAL || type == IPT_PEDAL2)
			{
				new  = -new;
				prev = -prev;
				if (in->type & IPF_REVERSE)		// a reversed pedal is diff than normal reverse
				{								// 128 = no gas, 0 = all gas
					new  = 128-new;				// the default "new=-new" doesn't handle this
					prev = 128-prev;
				}
			}
			else if (in->type & IPF_REVERSE)
			{
				new  = -new;
				prev = -prev;
			}

			/* apply sensitivity using a logarithmic scale */
			if (in->mask > 0xff)
			{
				if (new > 0)
				{
					current = (pow(new / 32768.0, 100.0 / sensitivity) * (max-in->default_value)
							+ in->default_value) * 100 / sensitivity;
				}
				else
				{
					current = (pow(-new / 32768.0, 100.0 / sensitivity) * (min-in->default_value)
							+ in->default_value) * 100 / sensitivity;
				}
			}
			else
			{
				if (new > 0)
				{
					current = (pow(new / 128.0, 100.0 / sensitivity) * (max-in->default_value)
							+ in->default_value) * 100 / sensitivity;
				}
				else
				{
					current = (pow(-new / 128.0, 100.0 / sensitivity) * (min-in->default_value)
							+ in->default_value) * 100 / sensitivity;
				}
			}
		}
	}
#ifdef KAILLERA
}
#endif

	current += delta;

	if (check_bounds)
	{
		int temp;

		if (current >= 0)
			temp = (current * sensitivity + 50) / 100;
		else
			temp = (-current * sensitivity + 50) / -100;

		if (temp < min)
		{
			if (min >= 0)
				current = (min * 100 + sensitivity/2) / sensitivity;
			else
				current = (-min * 100 + sensitivity/2) / -sensitivity;
		}
		if (temp > max)
		{
			if (max >= 0)
				current = (max * 100 + sensitivity/2) / sensitivity;
			else
				current = (-max * 100 + sensitivity/2) / -sensitivity;
		}
	}

	input_analog_current_value[port] = current;
}

static void scale_analog_port(int port)
{
	struct InputPort *in;
	int delta,current,sensitivity;

profiler_mark(PROFILER_INPUT);
	in = input_analog[port];
	sensitivity = IP_GET_SENSITIVITY(in);

	/* apply scaling fairly in both positive and negative directions */
	delta = input_analog_current_value[port] - input_analog_previous_value[port];
	if (delta >= 0)
		delta = cpu_scalebyfcount(delta);
	else
		delta = -cpu_scalebyfcount(-delta);

	current = input_analog_previous_value[port] + delta;

	/* An ugly hack to remove scaling on lightgun ports */
	if (input_analog_scale[port]) {
		/* apply scaling fairly in both positive and negative directions */
		if (current >= 0)
			current = (current * sensitivity + 50) / 100;
		else
			current = (-current * sensitivity + 50) / -100;
	}

	input_port_value[port] &= ~in->mask;
	input_port_value[port] |= current & in->mask;

#ifdef KAILLERA
	if (playback) {
		if (playback_trc) readword(playback_trc,&playback_value[port]);
		readword(playback,&input_port_value[port]);
	}
	if (record && netplay_pause == -1) {
		writeword(record,input_port_value[port]);
		writeword(trace,0x0);
	}
#else
	if (playback)
		readword(playback,&input_port_value[port]);
	if (record)
		writeword(record,input_port_value[port]);
#endif
#ifdef MAME_NET
	if ( net_active() && (default_player != NET_SPECTATOR) )
		net_analog_sync((unsigned char *) input_port_value, port, analog_player_port, default_player);
#endif /* MAME_NET */
profiler_mark(PROFILER_END);
}

#define MAX_JOYSTICKS 3
#define MAX_PLAYERS 4
static int mJoyCurrent[MAX_JOYSTICKS*MAX_PLAYERS];
static int mJoyPrevious[MAX_JOYSTICKS*MAX_PLAYERS];
static int mJoy4Way[MAX_JOYSTICKS*MAX_PLAYERS];
/*
The above "Joy" states contain packed bits:
	0001	up
	0010	down
	0100	left
	1000	right
*/

static void
ScanJoysticks( struct InputPort *in )
{
	int i;
	int port = 0;

	/* Save old Joystick state. */
	memcpy( mJoyPrevious, mJoyCurrent, sizeof(mJoyPrevious) );

	/* Initialize bits of mJoyCurrent to zero. */
	memset( mJoyCurrent, 0, sizeof(mJoyCurrent) );

	/* Now iterate over the input port structure to populate mJoyCurrent. */
	while( in->type != IPT_END && port < MAX_INPUT_PORTS )
	{
		while (in->type != IPT_END && in->type != IPT_PORT)
		{
			if ((in->type & ~IPF_MASK) >= IPT_JOYSTICK_UP &&
				(in->type & ~IPF_MASK) <= IPT_JOYSTICKLEFT_RIGHT)
			{
				InputSeq* seq;
				seq = input_port_seq(in);
				if( seq_pressed(seq) )
				{
					int joynum,joydir,player;
					player = 0;
					if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER2)
						player = 1;
					else if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER3)
						player = 2;
					else if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER4)
						player = 3;

					joynum = player * MAX_JOYSTICKS +
							 ((in->type & ~IPF_MASK) - IPT_JOYSTICK_UP) / 4;
					joydir = ((in->type & ~IPF_MASK) - IPT_JOYSTICK_UP) % 4;

					mJoyCurrent[joynum] |= 1<<joydir;
				}
			}
			in++;
		}
		port++;
		if (in->type == IPT_PORT) in++;
	}

	/* Process the joystick states, to filter out illegal combinations of switches. */
	for( i=0; i<MAX_JOYSTICKS*MAX_PLAYERS; i++ )
	{
		if( (mJoyCurrent[i]&0x3)==0x3 ) /* both up and down are pressed */
		{
			mJoyCurrent[i]&=0xc; /* clear up and down */
		}
		if( (mJoyCurrent[i]&0xc)==0xc ) /* both left and right are pressed */
		{
			mJoyCurrent[i]&=0x3; /* clear left and right */
		}

		/* Only update mJoy4Way if the joystick has moved. */
		if( mJoyCurrent[i]!=mJoyPrevious[i] )
		{
			mJoy4Way[i] = mJoyCurrent[i];

			if( (mJoy4Way[i] & 0x3) && (mJoy4Way[i] & 0xc) )
			{
				/* If joystick is pointing at a diagonal, acknowledge that the player moved
				 * the joystick by favoring a direction change.  This minimizes frustration
				 * when using a keyboard for input, and maximizes responsiveness.
				 *
				 * For example, if you are holding "left" then switch to "up" (where both left
				 * and up are briefly pressed at the same time), we'll transition immediately
				 * to "up."
				 *
				 * Under the old "sticky" key implentation, "up" wouldn't be triggered until
				 * left was released.
				 *
				 * Zero any switches that didn't change from the previous to current state.
				 */
				mJoy4Way[i] ^= (mJoy4Way[i] & mJoyPrevious[i]);
			}

			if( (mJoy4Way[i] & 0x3) && (mJoy4Way[i] & 0xc) )
			{
				/* If we are still pointing at a diagonal, we are in an indeterminant state.
				 *
				 * This could happen if the player moved the joystick from the idle position directly
				 * to a diagonal, or from one diagonal directly to an extreme diagonal.
				 *
				 * The chances of this happening with a keyboard are slim, but we still need to
				 * constrain this case.
				 *
				 * For now, just resolve randomly.
				 */
				if( rand()&1 )
				{
					mJoy4Way[i] &= 0x3; /* eliminate horizontal component */
				}
				else
				{
					mJoy4Way[i] &= 0xc; /* eliminate vertical component */
				}
			}
		}
	}
} /* ScanJoysticks */

void update_input_ports(void)
{
	int port,ib;
	struct InputPort *in;

#define MAX_INPUT_BITS 1024
	static int impulsecount[MAX_INPUT_BITS];
	static int waspressed[MAX_INPUT_BITS];
	static int pbwaspressed[MAX_INPUT_BITS];

#ifdef MAME_NET
	int player;
#endif /* MAME_NET */

#ifdef KAILLERA
	special_key = 0;
#endif

profiler_mark(PROFILER_INPUT);

	/* clear all the values before proceeding */
	for (port = 0;port < MAX_INPUT_PORTS;port++)
	{
		input_port_value[port] = 0;
		input_vblank[port] = 0;
		input_analog[port] = 0;
	}

	in = Machine->input_ports;
	if (in->type == IPT_END) return; 	/* nothing to do */

	/* make sure the InputPort definition is correct */
	if (in->type != IPT_PORT)
	{
		logerror("Error in InputPort definition: expecting PORT_START\n");
		return;
	}
	else
	{
		in++;
	}

	ScanJoysticks( in ); /* populates mJoyCurrent[] */

	/* scan all the input ports */
	port = 0;
	ib = 0;
	while (in->type != IPT_END && port < MAX_INPUT_PORTS)
	{
		struct InputPort *start;
		/* first of all, scan the whole input port definition and build the */
		/* default value. I must do it before checking for input because otherwise */
		/* multiple keys associated with the same input bit wouldn't work (the bit */
		/* would be reset to its default value by the second entry, regardless if */
		/* the key associated with the first entry was pressed) */
		start = in;
		while (in->type != IPT_END && in->type != IPT_PORT)
		{
			if ((in->type & ~IPF_MASK) != IPT_DIPSWITCH_SETTING &&	/* skip dipswitch definitions */
				(in->type & ~IPF_MASK) != IPT_EXTENSION)			/* skip analog extension fields */
			{
				input_port_value[port] =
						(input_port_value[port] & ~in->mask) | (in->default_value & in->mask);
#ifdef MAME_NET
				if ( net_active() )
					input_port_defaults[port] = input_port_value[port];
#endif /* MAME_NET */
			}

			in++;
		}

		/* now get back to the beginning of the input port and check the input bits. */
		for (in = start;
			 in->type != IPT_END && in->type != IPT_PORT;
			 in++, ib++)
		{
#ifdef MAME_NET
			player = 0;
			if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER2) player = 1;
			else if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER3) player = 2;
			else if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER4) player = 3;
#endif /* MAME_NET */
			if ((in->type & ~IPF_MASK) != IPT_DIPSWITCH_SETTING &&	/* skip dipswitch definitions */
					(in->type & ~IPF_MASK) != IPT_EXTENSION)		/* skip analog extension fields */
			{
				if ((in->type & ~IPF_MASK) == IPT_VBLANK)
				{
					input_vblank[port] ^= in->mask;
					input_port_value[port] ^= in->mask;
if (Machine->drv->vblank_duration == 0)
	logerror("Warning: you are using IPT_VBLANK with vblank_duration = 0. You need to increase vblank_duration for IPT_VBLANK to work.\n");
				}
				/* If it's an analog control, handle it appropriately */
				else if (((in->type & ~IPF_MASK) > IPT_ANALOG_START)
					  && ((in->type & ~IPF_MASK) < IPT_ANALOG_END  )) /* LBO 120897 */
				{
					input_analog[port]=in;

#ifdef KAILLERA
					if(kPlay) {
						InputSeq* incseq;
						InputSeq* decseq;
						decseq = input_port_seq(in);
						incseq = input_port_seq(in+1);
						switch (in->type & ~IPF_MASK)
						{
							case IPT_PADDLE:
								if (seq_pressed(decseq)) input_port_value[port] ^= 2048;
								if (seq_pressed(incseq)) input_port_value[port] ^= 4096;
								break;
							case IPT_PADDLE_V:
								if (seq_pressed(decseq)) input_port_value[port] ^= 512;
								if (seq_pressed(incseq)) input_port_value[port] ^= 1024;
								break;
							case IPT_DIAL:
								if (seq_pressed(decseq)) input_port_value[port] ^= 2048;
								if (seq_pressed(incseq)) input_port_value[port] ^= 4096;
								break;
							case IPT_DIAL_V:
								if (seq_pressed(decseq)) input_port_value[port] ^= 512;
								if (seq_pressed(incseq)) input_port_value[port] ^= 1024;
								break;
							case IPT_TRACKBALL_X:
								if (seq_pressed(decseq)) input_port_value[port] ^= 2048;
								if (seq_pressed(incseq)) input_port_value[port] ^= 4096;
								break;
							case IPT_TRACKBALL_Y:
								if (seq_pressed(decseq)) input_port_value[port] ^= 512;
								if (seq_pressed(incseq)) input_port_value[port] ^= 1024;
								break;
							case IPT_AD_STICK_X:
								if (seq_pressed(decseq)) input_port_value[port] ^= 2048;
								if (seq_pressed(incseq)) input_port_value[port] ^= 4096;
								break;
							case IPT_AD_STICK_Y:
								if (seq_pressed(decseq)) input_port_value[port] ^= 512;
								if (seq_pressed(incseq)) input_port_value[port] ^= 1024;
								break;
							case IPT_LIGHTGUN_X:
								if (seq_pressed(decseq)) input_port_value[port] ^= 2048;
								if (seq_pressed(incseq)) input_port_value[port] ^= 4096;
								break;
							case IPT_LIGHTGUN_Y:
								if (seq_pressed(decseq)) input_port_value[port] ^= 512;
								if (seq_pressed(incseq)) input_port_value[port] ^= 1024;
								break;
							case IPT_PEDAL:
								if (seq_pressed(decseq)) input_port_value[port] ^= 1;
								break;
							case IPT_PEDAL2:
								if (seq_pressed(decseq)) input_port_value[port] ^= 1;
								break;
						}
					}
#endif
					/* reset the analog port on first access */
					if (input_analog_init[port])
					{
						input_analog_init[port] = 0;
						input_analog_scale[port] = 1;
						input_analog_current_value[port] = input_analog_previous_value[port]
							= in->default_value * 100 / IP_GET_SENSITIVITY(in);
					}
				}
				else
				{
					InputSeq* seq;
					seq = input_port_seq(in);
					if (seq_pressed(seq))
					{
						/* skip if coin input and it's locked out */
						if ((in->type & ~IPF_MASK) >= IPT_COIN1 &&
							(in->type & ~IPF_MASK) <= IPT_COIN4 &&
                            coinlockedout[(in->type & ~IPF_MASK) - IPT_COIN1])
						{
							continue;
						}

						/* if IPF_RESET set, reset the first CPU */
						if ((in->type & IPF_RESETCPU) && waspressed[ib] == 0 && !playback)
						{
							cpu_set_reset_line(0,PULSE_LINE);
						}

						if (in->type & IPF_IMPULSE)
						{
if (IP_GET_IMPULSE(in) == 0)
	logerror("error in input port definition: IPF_IMPULSE with length = 0\n");
							if (waspressed[ib] == 0)
								impulsecount[ib] = IP_GET_IMPULSE(in);
								/* the input bit will be toggled later */
						}
						else if (in->type & IPF_TOGGLE)
						{
							if (waspressed[ib] == 0)
							{
								in->default_value ^= in->mask;
								input_port_value[port] ^= in->mask;
							}
						}
						else if ((in->type & ~IPF_MASK) >= IPT_JOYSTICK_UP &&
								(in->type & ~IPF_MASK) <= IPT_JOYSTICKLEFT_RIGHT)
						{
#ifndef MAME_NET
							int joynum,joydir,mask,player;


							player = 0;
							if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER2) player = 1;
							else if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER3) player = 2;
							else if ((in->type & IPF_PLAYERMASK) == IPF_PLAYER4) player = 3;
#else
							int joynum,joydir,mask;
#endif /* !MAME_NET */
							joynum = player * MAX_JOYSTICKS +
									((in->type & ~IPF_MASK) - IPT_JOYSTICK_UP) / 4;

							joydir = ((in->type & ~IPF_MASK) - IPT_JOYSTICK_UP) % 4;

							mask = in->mask;

							if( in->type & IPF_4WAY )
							{
								/* apply 4-way joystick constraint */
								if( ((mJoy4Way[joynum]>>joydir)&1) == 0 )
								{
									mask = 0;
								}
							}
							else
							{
								/* filter up+down and left+right */
								if( ((mJoyCurrent[joynum]>>joydir)&1) == 0 )
								{
									mask = 0;
								}
							}

							input_port_value[port] ^= mask;
						} /* joystick */
						else
						{
							input_port_value[port] ^= in->mask;
						}
						waspressed[ib] = 1;
					}
					else
						waspressed[ib] = 0;

					if ((in->type & IPF_IMPULSE) && impulsecount[ib] > 0)
					{
						impulsecount[ib]--;
						waspressed[ib] = 1;
						input_port_value[port] ^= in->mask;
					}
				}
			}
		}

		port++;
		if (in->type == IPT_PORT) in++;
	}

#ifdef KAILLERA
	if (playback && playback_trc)
	{
		int i;

		for (i = 0; i < MAX_INPUT_PORTS; i ++)
		{
			readword(playback_trc,&playback_value[i]);

			if(playback_value[i] == IPT_UI_RESET_MACHINE) {
				machine_reset();
				usrintf_showmessage("Reset");
			}
			else if(playback_value[i] == IPT_UI_LOAD_STATE) {
				cpu_loadsave_schedule(LOADSAVE_LOAD, '@');
				usrintf_showmessage("State loaded");
			}
			else if(playback_value[i] == IPT_UI_SAVE_STATE) {
                        cpu_loadsave_schedule(LOADSAVE_SAVE, '@');
                        usrintf_showmessage("State saved");
			}
			else if(playback_value[i] == IPT_UI_CANCEL) {
				endemu = 1;
			}
		}
	}
#endif

	if (playback)
	{
		int i;

		ib=0;
		in = Machine->input_ports;
		in++;
		for (i = 0; i < MAX_INPUT_PORTS; i ++)
		{
			readword(playback,&input_port_value[i]);

			/* check if the input port includes an IPF_RESETCPU bit
			   and reset the CPU on first "press", no need to check
			   the impulse count as this was done during recording */
			for (; in->type != IPT_END && in->type != IPT_PORT; in++, ib++)
			{
				if (in->type & IPF_RESETCPU)
				{
					if((input_port_value[i] ^ in->default_value) & in->mask)
					{
						if (pbwaspressed[ib] == 0)
							cpu_set_reset_line(0,PULSE_LINE);
						pbwaspressed[ib] = 1;
					}
					else
						pbwaspressed[ib] = 0;
				}
			}
			if (in->type == IPT_PORT) in++;
		}
	}

#ifdef KAILLERA
	if (kPlay)
	{
		if(kUpdateDip) {
			UINT16	mask;
			in = Machine->input_ports;
			in++;
			port = 0;
			while (in->type != IPT_END && port < MAX_INPUT_PORTS)
			{
				mask = 0;
				while (in->type != IPT_END && in->type != IPT_PORT)
				{
					if ((in->type & ~IPF_MASK) == IPT_DIPSWITCH_NAME)
					{
						mask |= in->mask;
						in->default_value =
							(in->default_value & ~in->mask) | (kDipSwitch[port] & in->mask);
					}
					in++;
				}
				if(mask){
					port++;
				}
				if (in->type == IPT_PORT) in++;
			}
			kUpdateDip = 0;
		}

		if (kFirstMsg) kFirstMsg=0;
		else
		{
			LONGLONG st;
			int i;
			unsigned long b;
			int recvLen = 0;
			unsigned long ui_key;
			unsigned long K_UI_MASK_L  = 0x7fffffff;
			unsigned long K_UI_UIBIT_L = 0x80000000;

			enum {
				K_UI_NONE = 0,
				K_UI_RESET_MACHINE,
				K_UI_LOAD_STATE,
				K_UI_SAVE_STATE,
				K_UI_APPLY_DIP,
                        K_UI_SHIFT_DOWN,
                        K_UI_SHIFT_UP,
                        K_UI_SWAP_CONTROL,
                        K_UI_AUTO_SAVE,
				K_UI_LOAD_AUTOSAVE,
				K_UI_PAUSE,
			      K_UI_MASK  = 0x7fff,
			      K_UI_UIBIT = 0x8000
			};
			ui_key = K_UI_NONE;

/* MULTIPLAYER GAME HACKS */
switch(game)
{
case kof2000_6p:
{
	int energy1 = cpunum_read_byte(0, 0x108239) | 0x0F;
	int energy2 = cpunum_read_byte(0, 0x108439) | 0x0F;
        if( (cpunum_read_byte(0, 0x10A7F9) == 0 && cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF && cpunum_read_byte(0, 0x10A7FC) == 0xFF) ||
            (cpunum_read_byte(0, 0x10A80E) == 0 && cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF && cpunum_read_byte(0, 0x10A811) == 0xFF) ||
            (cpunum_read_byte(0, 0x10A7F9) == 0 && energy1 == 0xFF) ||
		(cpunum_read_byte(0, 0x10A80E) == 0 && energy2 == 0xFF) ||
             cpunum_read_byte(0, 0x10A805) == 0xFF ||
             cpunum_read_byte(0, 0x10A81A) == 0xFF )
             init = 0;
        if(init == 0)
	{
            if(kPlayers == 4 || kPlayers == 2)
                {
		if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(1,0,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(1,0,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
                        change_position(1,0,2,3,4,5);
                }
                else if(kPlayers == 5)
                {
		if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
                        change_position(0,1,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
                        change_position(1,0,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
                        change_position(1,2,0,4,3,5);
                }
                else if(kPlayers == 3 || kPlayers >= 6)
                {
		if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(0,1,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(1,0,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(1,2,0,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
			change_position(0,1,2,4,5,3);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
			change_position(1,0,2,4,5,3);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
			change_position(1,2,0,4,5,3);
                }

		if( cpunum_read_byte(0, 0x10A7E6) == 0x60 &&
                cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF && cpunum_read_byte(0, 0x10A7FC) != 0xFF && cpunum_read_byte(0, 0x10A7FD) != 0xFF &&
                cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF && cpunum_read_byte(0, 0x10A811) != 0xFF && cpunum_read_byte(0, 0x10A812) != 0xFF &&
		    cpunum_read_byte(0, 0x10A805) != 0xFF && cpunum_read_byte(0, 0x10A81A) != 0xFF )
		{
                        init = 1;
		}
	}
	else
	{
		p1_1st = cpunum_read_byte(0, 0x10A802);
		p1_2nd = cpunum_read_byte(0, 0x10A803);
		p1_3rd = cpunum_read_byte(0, 0x10A804);
		p2_1st = cpunum_read_byte(0, 0x10A817);
		p2_2nd = cpunum_read_byte(0, 0x10A818);
		p2_3rd = cpunum_read_byte(0, 0x10A819);

                if( cpunum_read_byte(0, 0x10A7E6) == 0x60 )
                {
		if(cpunum_read_byte(0, 0x10A7F9) == 0 && cpunum_read_byte(0, 0x10A80E) == 0)
			kof_swap(p1_1st, p2_1st);
		else if(cpunum_read_byte(0, 0x10A7F9) == 0 && cpunum_read_byte(0, 0x10A80E) == 1)
			kof_swap(p1_1st, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A7F9) == 0 && cpunum_read_byte(0, 0x10A80E) == 2)  
			kof_swap(p1_1st, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A7F9) == 1 && cpunum_read_byte(0, 0x10A80E) == 0)  
			kof_swap(p1_2nd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A7F9) == 1 && cpunum_read_byte(0, 0x10A80E) == 1)  
			kof_swap(p1_2nd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A7F9) == 1 && cpunum_read_byte(0, 0x10A80E) == 2)  
			kof_swap(p1_2nd, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A7F9) == 2 && cpunum_read_byte(0, 0x10A80E) == 0)  
			kof_swap(p1_3rd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A7F9) == 2 && cpunum_read_byte(0, 0x10A80E) == 1)  
			kof_swap(p1_3rd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A7F9) == 2 && cpunum_read_byte(0, 0x10A80E) == 2)  
			kof_swap(p1_3rd, p2_3rd);
                }
	}
	break;
}
case kof2001_8p:
{
        if( (cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF && cpunum_read_byte(0, 0x10A7E9) == 0xFF) ||
            (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF && cpunum_read_byte(0, 0x10A80F) == 0xFF) )
             init = 0;
        if(init == 0)
	{
            if(kPlayers == 4 || kPlayers == 2)
                {
		if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,0,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,0,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,0,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,0,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position(1,0,2,3,4,5);
                }
                else if(kPlayers == 3)
                {
		if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF))
                        change_position(1,0,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF))
                        change_position(1,0,3,2,4,5);
                }
                else if(kPlayers == 5)
                {
		if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(0,1,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,0,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,2,0,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,2,0,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position(0,1,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position(1,0,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position(1,2,0,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position(1,2,0,4,3,5);
                }
                else if(kPlayers == 6)
                {
		if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(0,1,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,0,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,2,0,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,2,0,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(0,1,2,4,5,3);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,0,2,4,5,3);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,2,0,4,5,3);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position(1,2,0,4,5,3);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position(0,1,2,4,5,3);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position(1,0,2,4,5,3);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position(1,2,0,4,5,3);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position(1,2,0,4,5,3);
                }
                else if(kPlayers == 7)
                {
		if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(0,1,1,1,3,1,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,0,1,1,3,1,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,1,0,1,3,1,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,1,1,0,3,1,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(0,1,1,1,1,3,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,0,1,1,1,3,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,1,0,1,1,3,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,1,1,0,1,3,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(0,1,1,1,1,1,3,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,0,1,1,1,1,3,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,1,0,1,1,1,3,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,1,1,0,1,1,3,1);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position2(0,1,1,1,1,1,3,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position2(1,0,1,1,1,1,3,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position2(1,1,0,1,1,1,3,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position2(1,1,1,0,1,1,3,1);
                }
                else if(kPlayers >= 8)
                {
		if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(0,1,1,1,3,1,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,0,1,1,3,1,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,1,0,1,3,1,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,1,1,0,3,1,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(0,1,1,1,1,3,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,0,1,1,1,3,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,1,0,1,1,3,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,1,1,0,1,3,1,1);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(0,1,1,1,1,1,3,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,0,1,1,1,1,3,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,1,0,1,1,1,3,1);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF))
                        change_position2(1,1,1,0,1,1,3,1);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position2(0,1,1,1,1,1,1,3);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position2(1,0,1,1,1,1,1,3);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position2(1,1,0,1,1,1,1,3);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF && cpunum_read_byte(0, 0x10A7E8) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF && cpunum_read_byte(0, 0x10A80E) != 0xFF))
                        change_position2(1,1,1,0,1,1,1,3);
                }

		if( cpunum_read_byte(0, 0x10A7D2) == 0x60 && cpunum_read_byte(0, 0x10A7D3) == 0x32 ) 
		{
                  init = 1;
		}
	}
	else
	{
                if( cpunum_read_byte(0, 0x10A7D2) == 0x60 )
                {
			p1_1st = cpunum_read_byte(0, 0x10A7EE);
			p1_2nd = cpunum_read_byte(0, 0x10A7EF);
			p1_3rd = cpunum_read_byte(0, 0x10A7F0);
			p1_4th = cpunum_read_byte(0, 0x10A7F1);
			p2_1st = cpunum_read_byte(0, 0x10A814);
			p2_2nd = cpunum_read_byte(0, 0x10A815);
			p2_3rd = cpunum_read_byte(0, 0x10A816);
			p2_4th = cpunum_read_byte(0, 0x10A817);
			p1_1c = cpunum_read_byte(0, 0x10A7E6);
			p1_2c = cpunum_read_byte(0, 0x10A7E7);
			p1_3c = cpunum_read_byte(0, 0x10A7E8);
			p1_4c = cpunum_read_byte(0, 0x10A7E9);
			p2_1c = cpunum_read_byte(0, 0x10A80F);
			p2_2c = cpunum_read_byte(0, 0x10A80E);
			p2_3c = cpunum_read_byte(0, 0x10A80D);
			p2_4c = cpunum_read_byte(0, 0x10A80C);

		if(cpunum_read_byte(0, 0x10A7F3) == 0 && cpunum_read_byte(0, 0x10A819) == 0)
			kof_swap2(p1_1st, p2_1st);
		else if(cpunum_read_byte(0, 0x10A7F3) == 0 && cpunum_read_byte(0, 0x10A819) == 1)
			kof_swap2(p1_1st, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A7F3) == 0 && cpunum_read_byte(0, 0x10A819) == 2)  
			kof_swap2(p1_1st, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A7F3) == 0 && cpunum_read_byte(0, 0x10A819) == 3)  
			kof_swap2(p1_1st, p2_4th);
		else if(cpunum_read_byte(0, 0x10A7F3) == 1 && cpunum_read_byte(0, 0x10A819) == 0)  
			kof_swap2(p1_2nd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A7F3) == 1 && cpunum_read_byte(0, 0x10A819) == 1)  
			kof_swap2(p1_2nd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A7F3) == 1 && cpunum_read_byte(0, 0x10A819) == 2)  
			kof_swap2(p1_2nd, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A7F3) == 1 && cpunum_read_byte(0, 0x10A819) == 3)  
			kof_swap2(p1_2nd, p2_4th);
		else if(cpunum_read_byte(0, 0x10A7F3) == 2 && cpunum_read_byte(0, 0x10A819) == 0)  
			kof_swap2(p1_3rd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A7F3) == 2 && cpunum_read_byte(0, 0x10A819) == 1)  
			kof_swap2(p1_3rd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A7F3) == 2 && cpunum_read_byte(0, 0x10A819) == 2)  
			kof_swap2(p1_3rd, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A7F3) == 2 && cpunum_read_byte(0, 0x10A819) == 3)  
			kof_swap2(p1_3rd, p2_4th);
		else if(cpunum_read_byte(0, 0x10A7F3) == 3 && cpunum_read_byte(0, 0x10A819) == 0)  
			kof_swap2(p1_4th, p2_1st);
		else if(cpunum_read_byte(0, 0x10A7F3) == 3 && cpunum_read_byte(0, 0x10A819) == 1)  
			kof_swap2(p1_4th, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A7F3) == 3 && cpunum_read_byte(0, 0x10A819) == 2)  
			kof_swap2(p1_4th, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A7F3) == 3 && cpunum_read_byte(0, 0x10A819) == 3)  
			kof_swap2(p1_4th, p2_4th);
                }
	}
	break;
}
case kof2002_6p:
{
//	int energy1 = cpunum_read_byte(0, 0x108239) | 0x0F;
//	int energy2 = cpunum_read_byte(0, 0x108439) | 0x0F;
        if( (cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF && cpunum_read_byte(0, 0x10A7E8) == 0xFF) ||
            (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF && cpunum_read_byte(0, 0x10A80E) == 0xFF) )
             init = 0;
        if(init == 0)
	{
                if(kPlayers == 4 || kPlayers == 2)
                {
		if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
                        change_position(1,0,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
                        change_position(1,0,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF))
                        change_position(1,0,2,3,4,5);
                }
                else if(kPlayers == 5)
                {
		if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
			change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
			change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
			change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
                        change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
                        change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF))
                        change_position(0,1,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF))
                        change_position(1,0,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF))
                        change_position(1,2,0,4,3,5);
                }
                else if(kPlayers == 3 || kPlayers >= 6)
                {
		if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
			change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
			change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) == 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
			change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
			change_position(0,1,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
			change_position(1,0,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) == 0xFF))
			change_position(1,2,0,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7E6) == 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF))
			change_position(0,1,2,4,5,3);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF))
			change_position(1,0,2,4,5,3);
		else if((cpunum_read_byte(0, 0x10A7E6) != 0xFF && cpunum_read_byte(0, 0x10A7E7) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80C) != 0xFF && cpunum_read_byte(0, 0x10A80D) != 0xFF))
			change_position(1,2,0,4,5,3);
                }

		if( cpunum_read_byte(0, 0x10A7D2) == 0x60 && cpunum_read_byte(0, 0x10A7D3) == 0x32 ) 
		{
                  init = 1;
		}
	}
	else
	{
		p1_1st = cpunum_read_byte(0, 0x10A7FC);
		p1_2nd = cpunum_read_byte(0, 0x10A7FD);
		p1_3rd = cpunum_read_byte(0, 0x10A7FE);
		p2_1st = cpunum_read_byte(0, 0x10A822);
		p2_2nd = cpunum_read_byte(0, 0x10A823);
		p2_3rd = cpunum_read_byte(0, 0x10A824);

                if( cpunum_read_byte(0, 0x10A7D2) == 0x60 && cpunum_read_byte(0, 0x10A7D3) == 0x32 )
                {
		if(cpunum_read_byte(0, 0x10A7F3) == 0 && cpunum_read_byte(0, 0x10A819) == 0)
			kof_swap(p1_1st, p2_1st);
		else if(cpunum_read_byte(0, 0x10A7F3) == 0 && cpunum_read_byte(0, 0x10A819) == 1)
			kof_swap(p1_1st, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A7F3) == 0 && cpunum_read_byte(0, 0x10A819) == 2)  
			kof_swap(p1_1st, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A7F3) == 1 && cpunum_read_byte(0, 0x10A819) == 0)  
			kof_swap(p1_2nd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A7F3) == 1 && cpunum_read_byte(0, 0x10A819) == 1)  
			kof_swap(p1_2nd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A7F3) == 1 && cpunum_read_byte(0, 0x10A819) == 2)  
			kof_swap(p1_2nd, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A7F3) == 2 && cpunum_read_byte(0, 0x10A819) == 0)  
			kof_swap(p1_3rd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A7F3) == 2 && cpunum_read_byte(0, 0x10A819) == 1)  
			kof_swap(p1_3rd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A7F3) == 2 && cpunum_read_byte(0, 0x10A819) == 2)  
			kof_swap(p1_3rd, p2_3rd);
                }
	}
	break;
}
case kof98_6p:
{
	int energy1 = cpunum_read_byte(0, 0x108239) | 0x0F;
	int energy2 = cpunum_read_byte(0, 0x108439) | 0x0F;
        if( (cpunum_read_byte(0, 0x10A84D) == 0 && cpunum_read_byte(0, 0x10A84E) == 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF && cpunum_read_byte(0, 0x10A850) == 0xFF) ||
            (cpunum_read_byte(0, 0x10A85E) == 0 && cpunum_read_byte(0, 0x10A85F) == 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF && cpunum_read_byte(0, 0x10A861) == 0xFF) ||
            (cpunum_read_byte(0, 0x10A84D) == 0 && energy1 == 0xFF) ||
		(cpunum_read_byte(0, 0x10A85E) == 0 && energy2 == 0xFF) )
             init = 0;
        if(init == 0)
	{
                if(kPlayers == 4 || kPlayers == 2)
                {
		if((cpunum_read_byte(0, 0x10A84E) == 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A85F) == 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) == 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) == 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
                        change_position(1,0,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) == 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
                        change_position(1,0,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) == 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) != 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) != 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) != 0xFF))
                        change_position(1,0,2,3,4,5);
                }
                else if(kPlayers == 5)
                {
		if((cpunum_read_byte(0, 0x10A84E) == 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A85F) == 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
			change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) == 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
			change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) == 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
			change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) == 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
                        change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
                        change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) == 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) != 0xFF))
                        change_position(0,1,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) != 0xFF))
                        change_position(1,0,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) != 0xFF))
                        change_position(1,2,0,4,3,5);
                }
                else if(kPlayers == 3 || kPlayers >= 6)
                {
		if((cpunum_read_byte(0, 0x10A84E) == 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A85F) == 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
			change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) == 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
			change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) == 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
			change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A84E) == 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
			change_position(0,1,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
			change_position(1,0,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) == 0xFF))
			change_position(1,2,0,4,3,5);
		else if((cpunum_read_byte(0, 0x10A84E) == 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) != 0xFF))
			change_position(0,1,2,4,5,3);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) != 0xFF))
			change_position(1,0,2,4,5,3);
		else if((cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) != 0xFF))
			change_position(1,2,0,4,5,3);
                }

		if( cpunum_read_byte(0, 0x10A83A) == 0x60 &&
		    cpunum_read_byte(0, 0x10A84E) != 0xFF && cpunum_read_byte(0, 0x10A84F) != 0xFF && cpunum_read_byte(0, 0x10A850) != 0xFF &&
                cpunum_read_byte(0, 0x10A85F) != 0xFF && cpunum_read_byte(0, 0x10A860) != 0xFF && cpunum_read_byte(0, 0x10A861) != 0xFF )
		{
                        init = 1;
		}
	}
	else
	{
		p1_1st = cpunum_read_byte(0, 0x10A854);
		p1_2nd = cpunum_read_byte(0, 0x10A855);
		p1_3rd = cpunum_read_byte(0, 0x10A856);
		p2_1st = cpunum_read_byte(0, 0x10A865);
		p2_2nd = cpunum_read_byte(0, 0x10A866);
		p2_3rd = cpunum_read_byte(0, 0x10A867);

                if( cpunum_read_byte(0, 0x10A83A) == 0x60 )
                {
		if(cpunum_read_byte(0, 0x10A84D) == 0 && cpunum_read_byte(0, 0x10A85E) == 0)
			kof_swap(p1_1st, p2_1st);
		else if(cpunum_read_byte(0, 0x10A84D) == 0 && cpunum_read_byte(0, 0x10A85E) == 1)
			kof_swap(p1_1st, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A84D) == 0 && cpunum_read_byte(0, 0x10A85E) == 2)  
			kof_swap(p1_1st, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A84D) == 1 && cpunum_read_byte(0, 0x10A85E) == 0)  
			kof_swap(p1_2nd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A84D) == 1 && cpunum_read_byte(0, 0x10A85E) == 1)  
			kof_swap(p1_2nd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A84D) == 1 && cpunum_read_byte(0, 0x10A85E) == 2)  
			kof_swap(p1_2nd, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A84D) == 2 && cpunum_read_byte(0, 0x10A85E) == 0)  
			kof_swap(p1_3rd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A84D) == 2 && cpunum_read_byte(0, 0x10A85E) == 1)  
			kof_swap(p1_3rd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A84D) == 2 && cpunum_read_byte(0, 0x10A85E) == 2)  
			kof_swap(p1_3rd, p2_3rd);
                }
	}
	break;
}
case mvsc4p:
{
        if( cpunum_read_byte(0, 0xFF5C2B) == 1 )
		init = 0;
	if(init == 0)
	{
		if(kPlayers == 2 || kPlayers >= 4)
		{
			if(cpunum_read_byte(0, 0xFF5E4C) == 0 && cpunum_read_byte(0, 0xFF5DDC) == 0)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 0 && cpunum_read_byte(0, 0xFF5DDC) == 1)
				change_position(0,1,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 0 && cpunum_read_byte(0, 0xFF5DDC) == 2)
				change_position(0,1,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 1 && cpunum_read_byte(0, 0xFF5DDC) == 0)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 1 && cpunum_read_byte(0, 0xFF5DDC) == 1)
				change_position(1,0,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 1 && cpunum_read_byte(0, 0xFF5DDC) == 2)
				change_position(1,0,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 2 && cpunum_read_byte(0, 0xFF5DDC) == 0)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 2 && cpunum_read_byte(0, 0xFF5DDC) == 1)
				change_position(1,0,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 2 && cpunum_read_byte(0, 0xFF5DDC) == 2)
				change_position(1,0,3,2,4,5);
		}
		else if(kPlayers == 3)
		{
			if(cpunum_read_byte(0, 0xFF5E4C) == 0 && cpunum_read_byte(0, 0xFF5DDC) == 0)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 0 && cpunum_read_byte(0, 0xFF5DDC) == 1)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 0 && cpunum_read_byte(0, 0xFF5DDC) == 2)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 1 && cpunum_read_byte(0, 0xFF5DDC) == 0)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 1 && cpunum_read_byte(0, 0xFF5DDC) == 1)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 1 && cpunum_read_byte(0, 0xFF5DDC) == 2)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 2 && cpunum_read_byte(0, 0xFF5DDC) == 0)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 2 && cpunum_read_byte(0, 0xFF5DDC) == 1)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5E4C) == 2 && cpunum_read_byte(0, 0xFF5DDC) == 2)
				change_position(1,0,2,3,4,5);
		}

		if( cpunum_read_byte(0, 0xFF5C2B) == 0 )
		{
			init = 1;
               	change_position(0,1,2,3,4,5);
		}
	}
	else
	{
		if(kPlayers == 1) {}
		else if(kPlayers == 2 || kPlayers == 3)
		{
			if( cpunum_read_byte(0, 0xFF3A81) == 1 )
                        change_position(0,1,2,3,4,5);
			else if( cpunum_read_byte(0, 0xFF3A81) == 0 )
                        change_position(1,0,2,3,4,5);
		}
		else if(kPlayers >= 4)
		{
                        if( cpunum_read_byte(0, 0xFF3A81) == 1 && cpunum_read_byte(0, 0xFF3E81) == 1 )
                                change_position(0,1,2,3,4,5);
                        else if( cpunum_read_byte(0, 0xFF3A81) == 0 && cpunum_read_byte(0, 0xFF3E81) == 1 )
                                change_position(1,0,2,3,4,5);
                        else if( cpunum_read_byte(0, 0xFF3A81) == 1 && cpunum_read_byte(0, 0xFF3E81) == 0 )
                                change_position(0,1,3,2,4,5);
                        else if( cpunum_read_byte(0, 0xFF3A81) == 0 && cpunum_read_byte(0, 0xFF3E81) == 0 )
                                change_position(1,0,3,2,4,5);
		}
	}
	break;
}
case mshvsf4p:
{
        if( cpunum_read_byte(0, 0xFF2492) == 1 )
		init = 0;
	if(init == 0)
	{
		if(kPlayers == 2 || kPlayers >= 4)
		{
			if(cpunum_read_byte(0, 0xFF4983) == 0 && cpunum_read_byte(0, 0xFF49A3) == 0)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 0 && cpunum_read_byte(0, 0xFF49A3) == 1)
				change_position(0,1,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 0 && cpunum_read_byte(0, 0xFF49A3) == 2)
				change_position(0,1,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 1 && cpunum_read_byte(0, 0xFF49A3) == 0)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 1 && cpunum_read_byte(0, 0xFF49A3) == 1)
				change_position(1,0,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 1 && cpunum_read_byte(0, 0xFF49A3) == 2)
				change_position(1,0,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 2 && cpunum_read_byte(0, 0xFF49A3) == 0)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 2 && cpunum_read_byte(0, 0xFF49A3) == 1)
				change_position(1,0,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 2 && cpunum_read_byte(0, 0xFF49A3) == 2)
				change_position(1,0,3,2,4,5);
		}
		else if(kPlayers == 3)
		{
			if(cpunum_read_byte(0, 0xFF4983) == 0 && cpunum_read_byte(0, 0xFF49A3) == 0)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 0 && cpunum_read_byte(0, 0xFF49A3) == 1)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 0 && cpunum_read_byte(0, 0xFF49A3) == 2)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 1 && cpunum_read_byte(0, 0xFF49A3) == 0)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 1 && cpunum_read_byte(0, 0xFF49A3) == 1)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 1 && cpunum_read_byte(0, 0xFF49A3) == 2)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 2 && cpunum_read_byte(0, 0xFF49A3) == 0)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 2 && cpunum_read_byte(0, 0xFF49A3) == 1)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF4983) == 2 && cpunum_read_byte(0, 0xFF49A3) == 2)
				change_position(1,0,2,3,4,5);
		}

		if( cpunum_read_byte(0, 0xFF2492) == 0 )
		{
			init = 1;
               	change_position(0,1,2,3,4,5);
		}
	}
	else
	{
		if(kPlayers == 1) {}
		else if(kPlayers == 2 || kPlayers == 3)
		{
			if( cpunum_read_byte(0, 0xFF3A61) == 0 )
                        change_position(0,1,2,3,4,5);
			else if( cpunum_read_byte(0, 0xFF3A61) == 1 )
                        change_position(1,0,2,3,4,5);
		}
		else if(kPlayers >= 4)
		{
                        if( cpunum_read_byte(0, 0xFF3A61) == 0 && cpunum_read_byte(0, 0xFF3E61) == 0 )
                                change_position(0,1,2,3,4,5);
                        else if( cpunum_read_byte(0, 0xFF3A61) == 1 && cpunum_read_byte(0, 0xFF3E61) == 0 )
                                change_position(1,0,2,3,4,5);
                        else if( cpunum_read_byte(0, 0xFF3A61) == 0 && cpunum_read_byte(0, 0xFF3E61) == 1 )
                                change_position(0,1,3,2,4,5);
                        else if( cpunum_read_byte(0, 0xFF3A61) == 1 && cpunum_read_byte(0, 0xFF3E61) == 1 )
                                change_position(1,0,3,2,4,5);
		}
	}
	break;
}
case xmvsf4p:
{
	if( (cpunum_read_byte(0, 0xFF4211) == 0 && cpunum_read_byte(0, 0xFF4213) == 0 && cpunum_read_byte(0, 0xFF4214) == 0) ||
          (cpunum_read_byte(0, 0xFF4611) == 0 && cpunum_read_byte(0, 0xFF4613) == 0 && cpunum_read_byte(0, 0xFF4614) == 0) )
		init = 0;
	if(init == 0)
	{
		if(kPlayers == 2 || kPlayers >= 4)
		{
			if(cpunum_read_byte(0, 0xFF5183) == 0 && cpunum_read_byte(0, 0xFF51A3) == 0)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 0 && cpunum_read_byte(0, 0xFF51A3) == 1)
				change_position(0,1,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 0 && cpunum_read_byte(0, 0xFF51A3) == 2)
				change_position(0,1,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 1 && cpunum_read_byte(0, 0xFF51A3) == 0)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 1 && cpunum_read_byte(0, 0xFF51A3) == 1)
				change_position(1,0,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 1 && cpunum_read_byte(0, 0xFF51A3) == 2)
				change_position(1,0,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 2 && cpunum_read_byte(0, 0xFF51A3) == 0)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 2 && cpunum_read_byte(0, 0xFF51A3) == 1)
				change_position(1,0,3,2,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 2 && cpunum_read_byte(0, 0xFF51A3) == 2)
				change_position(1,0,3,2,4,5);
		}
		else if(kPlayers == 3)
		{
			if(cpunum_read_byte(0, 0xFF5183) == 0 && cpunum_read_byte(0, 0xFF51A3) == 0)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 0 && cpunum_read_byte(0, 0xFF51A3) == 1)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 0 && cpunum_read_byte(0, 0xFF51A3) == 2)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 1 && cpunum_read_byte(0, 0xFF51A3) == 0)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 1 && cpunum_read_byte(0, 0xFF51A3) == 1)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 1 && cpunum_read_byte(0, 0xFF51A3) == 2)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 2 && cpunum_read_byte(0, 0xFF51A3) == 0)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 2 && cpunum_read_byte(0, 0xFF51A3) == 1)
				change_position(1,0,2,3,4,5);
			else if(cpunum_read_byte(0, 0xFF5183) == 2 && cpunum_read_byte(0, 0xFF51A3) == 2)
				change_position(1,0,2,3,4,5);
		}

		player1_c = cpunum_read_byte(0, 0xFF4053);
		player2_c = cpunum_read_byte(0, 0xFF4853);
		player3_c = cpunum_read_byte(0, 0xFF4453);
		player4_c = cpunum_read_byte(0, 0xFF4C53);
		if( cpunum_read_byte(0, 0xFF4211) != 0 &&
                cpunum_read_byte(0, 0xFF4611) != 0 )
		{
			init = 1;
                        change_position(0,1,2,3,4,5);
		}
	}
	else
	{
		if(kPlayers == 1) {}
		else if(kPlayers == 2 || kPlayers == 3)
		{
			if( cpunum_read_byte(0, 0xFF4053) == player1_c )
                                change_position(0,1,2,3,4,5);
			else if( cpunum_read_byte(0, 0xFF4053) == player2_c )
                                change_position(1,0,2,3,4,5);
		}
		else if(kPlayers >= 4)
		{
			if( cpunum_read_byte(0, 0xFF4053) == player1_c &&
			    cpunum_read_byte(0, 0xFF4453) == player3_c )
                                change_position(0,1,2,3,4,5);
			else if( cpunum_read_byte(0, 0xFF4053) == player2_c &&
			         cpunum_read_byte(0, 0xFF4453) == player3_c )
                                change_position(1,0,2,3,4,5);
			else if( cpunum_read_byte(0, 0xFF4053) == player1_c &&
			         cpunum_read_byte(0, 0xFF4453) == player4_c )
                                change_position(0,1,3,2,4,5);
			else if( cpunum_read_byte(0, 0xFF4053) == player2_c &&
			         cpunum_read_byte(0, 0xFF4453) == player4_c )
                                change_position(1,0,3,2,4,5);
		}
	}
	break;
}
case kof99_6p:
{
	int energy1 = cpunum_read_byte(0, 0x108239) | 0x0F;
	int energy2 = cpunum_read_byte(0, 0x108439) | 0x0F;
        if( (cpunum_read_byte(0, 0x10A7F9) == 0 && cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF && cpunum_read_byte(0, 0x10A7FC) == 0xFF) ||
            (cpunum_read_byte(0, 0x10A80E) == 0 && cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF && cpunum_read_byte(0, 0x10A811) == 0xFF) ||
            (cpunum_read_byte(0, 0x10A7F9) == 0 && energy1 == 0xFF) ||
		(cpunum_read_byte(0, 0x10A80E) == 0 && energy2 == 0xFF) ||
             cpunum_read_byte(0, 0x10A805) == 0xFF ||
             cpunum_read_byte(0, 0x10A81A) == 0xFF )
             init = 0;
        if(init == 0)
	{
            if(kPlayers == 4 || kPlayers == 2)
                {
		if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(1,0,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(0,1,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(1,0,3,2,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
                        change_position(1,0,2,3,4,5);
                }
                else if(kPlayers == 5)
                {
		if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
                        change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
                        change_position(0,1,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
                        change_position(1,0,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
                        change_position(1,2,0,4,3,5);
                }
                else if(kPlayers == 3 || kPlayers >= 6)
                {
		if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		   (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(0,1,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(1,0,2,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) == 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(1,2,0,3,4,5);
		else if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(0,1,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(1,0,2,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) == 0xFF))
			change_position(1,2,0,4,3,5);
		else if((cpunum_read_byte(0, 0x10A7FA) == 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
			change_position(0,1,2,4,5,3);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) == 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
			change_position(1,0,2,4,5,3);
		else if((cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF) &&
		        (cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF))
			change_position(1,2,0,4,5,3);
                }

		if( cpunum_read_byte(0, 0x10A7E6) == 0x60 &&
                cpunum_read_byte(0, 0x10A7FA) != 0xFF && cpunum_read_byte(0, 0x10A7FB) != 0xFF && cpunum_read_byte(0, 0x10A7FC) != 0xFF && cpunum_read_byte(0, 0x10A7FD) != 0xFF &&
                cpunum_read_byte(0, 0x10A80F) != 0xFF && cpunum_read_byte(0, 0x10A810) != 0xFF && cpunum_read_byte(0, 0x10A811) != 0xFF && cpunum_read_byte(0, 0x10A812) != 0xFF &&
		    cpunum_read_byte(0, 0x10A805) != 0xFF && cpunum_read_byte(0, 0x10A81A) != 0xFF )
		{
                        init = 1;
		}
	}
	else
	{
		p1_1st = cpunum_read_byte(0, 0x10A802);
		p1_2nd = cpunum_read_byte(0, 0x10A803);
		p1_3rd = cpunum_read_byte(0, 0x10A804);
		p2_1st = cpunum_read_byte(0, 0x10A817);
		p2_2nd = cpunum_read_byte(0, 0x10A818);
		p2_3rd = cpunum_read_byte(0, 0x10A819);

                if( cpunum_read_byte(0, 0x10A7E6) == 0x60 )
                {
		if(cpunum_read_byte(0, 0x10A7F9) == 0 && cpunum_read_byte(0, 0x10A80E) == 0)
			kof_swap(p1_1st, p2_1st);
		else if(cpunum_read_byte(0, 0x10A7F9) == 0 && cpunum_read_byte(0, 0x10A80E) == 1)
			kof_swap(p1_1st, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A7F9) == 0 && cpunum_read_byte(0, 0x10A80E) == 2)  
			kof_swap(p1_1st, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A7F9) == 1 && cpunum_read_byte(0, 0x10A80E) == 0)  
			kof_swap(p1_2nd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A7F9) == 1 && cpunum_read_byte(0, 0x10A80E) == 1)  
			kof_swap(p1_2nd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A7F9) == 1 && cpunum_read_byte(0, 0x10A80E) == 2)  
			kof_swap(p1_2nd, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A7F9) == 2 && cpunum_read_byte(0, 0x10A80E) == 0)  
			kof_swap(p1_3rd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A7F9) == 2 && cpunum_read_byte(0, 0x10A80E) == 1)  
			kof_swap(p1_3rd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A7F9) == 2 && cpunum_read_byte(0, 0x10A80E) == 2)  
			kof_swap(p1_3rd, p2_3rd);
                }
	}
	break;
}
case kof97_6p:
{
	int energy1 = cpunum_read_byte(0, 0x108239) | 0x0F;
	int energy2 = cpunum_read_byte(0, 0x108439) | 0x0F;

        if( (cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x108239) == 0 && cpunum_read_byte(0, 0x10A851) == 0 && cpunum_read_byte(0, 0x10A852) == 0 && cpunum_read_byte(0, 0x10A853) == 0) ||
          (cpunum_read_byte(0, 0x10A84A) == 0 && energy1 == 0xFF ) ||
          (cpunum_read_byte(0, 0x10A85B) == 0 && cpunum_read_byte(0, 0x108439) == 0 && cpunum_read_byte(0, 0x10A862) == 0 && cpunum_read_byte(0, 0x10A863) == 0 && cpunum_read_byte(0, 0x10A864) == 0) ||
          (cpunum_read_byte(0, 0x10A85B) == 0 && energy2 == 0xFF ) )
            init = 0;
	if(init == 0)
	{
                if(kPlayers == 4 || kPlayers == 2)
                {
		if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 0)
                        change_position(0,1,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 1)
                        change_position(0,1,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 2)
                        change_position(0,1,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 3)  
                        change_position(0,1,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 0)  
                        change_position(0,1,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 1)  
                        change_position(0,1,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 2)  
                        change_position(0,1,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 3)  
                        change_position(0,1,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 0)  
                        change_position(1,0,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 1)  
                        change_position(1,0,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 2)  
                        change_position(1,0,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 3)  
                        change_position(1,0,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 3 && cpunum_read_byte(0, 0x10A85B) == 0)  
                        change_position(1,0,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 3 && cpunum_read_byte(0, 0x10A85B) == 1)  
                        change_position(1,0,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 3 && cpunum_read_byte(0, 0x10A85B) == 2)  
                        change_position(1,0,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 3 && cpunum_read_byte(0, 0x10A85B) == 3)  
                        change_position(1,0,2,3,4,5);
                }
                else if(kPlayers == 5)
                {
		if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 0)
			change_position(0,1,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 1)
			change_position(0,1,2,4,3,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 2)
			change_position(0,1,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 3)  
			change_position(0,1,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 0)  
			change_position(1,0,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 1)  
			change_position(1,0,2,4,3,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 2)  
			change_position(1,0,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 3)  
			change_position(1,0,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 0)  
			change_position(1,2,0,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 1)  
			change_position(1,2,0,4,3,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 2)  
			change_position(1,2,0,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 3)  
			change_position(1,2,0,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 3 && cpunum_read_byte(0, 0x10A85B) == 0)  
			change_position(1,2,0,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 3 && cpunum_read_byte(0, 0x10A85B) == 1)  
			change_position(1,2,0,4,3,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 3 && cpunum_read_byte(0, 0x10A85B) == 2)  
			change_position(1,2,0,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 3 && cpunum_read_byte(0, 0x10A85B) == 3)  
			change_position(1,2,0,4,5,3);
                }
                else if(kPlayers == 3 || kPlayers >= 6)
                {
		if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 0)
			change_position(0,1,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 1)
			change_position(0,1,2,4,3,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 2)
			change_position(0,1,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 3)  
			change_position(0,1,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 0)  
			change_position(1,0,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 1)  
			change_position(1,0,2,4,3,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 2)  
			change_position(1,0,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 3)  
			change_position(1,0,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 0)  
			change_position(1,2,0,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 1)  
			change_position(1,2,0,4,3,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 2)  
			change_position(1,2,0,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 3)  
			change_position(1,2,0,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 3 && cpunum_read_byte(0, 0x10A85B) == 0)  
			change_position(1,2,0,3,4,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 3 && cpunum_read_byte(0, 0x10A85B) == 1)  
			change_position(1,2,0,4,3,5);
		else if(cpunum_read_byte(0, 0x10A84A) == 3 && cpunum_read_byte(0, 0x10A85B) == 2)  
			change_position(1,2,0,4,5,3);
		else if(cpunum_read_byte(0, 0x10A84A) == 3 && cpunum_read_byte(0, 0x10A85B) == 3)  
			change_position(1,2,0,4,5,3);
                }

		if( cpunum_read_byte(0, 0x10A83A) == 0x60 )
		{
			init = 1;
		}
	}
	else
	{
		p1_1st = cpunum_read_byte(0, 0x10A851);
		p1_2nd = cpunum_read_byte(0, 0x10A852);
		p1_3rd = cpunum_read_byte(0, 0x10A853);
		p2_1st = cpunum_read_byte(0, 0x10A862);
		p2_2nd = cpunum_read_byte(0, 0x10A863);
		p2_3rd = cpunum_read_byte(0, 0x10A864);

                if( cpunum_read_byte(0, 0x10A83A) == 0x60 )
                {
		if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 0)
			kof_swap(p1_1st, p2_1st);
		else if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 1)
			kof_swap(p1_1st, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A84A) == 0 && cpunum_read_byte(0, 0x10A85B) == 2)  
			kof_swap(p1_1st, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 0)  
			kof_swap(p1_2nd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 1)  
			kof_swap(p1_2nd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A84A) == 1 && cpunum_read_byte(0, 0x10A85B) == 2)  
			kof_swap(p1_2nd, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 0)  
			kof_swap(p1_3rd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 1)  
			kof_swap(p1_3rd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A84A) == 2 && cpunum_read_byte(0, 0x10A85B) == 2)  
			kof_swap(p1_3rd, p2_3rd);
                }
	}
	break;
}
case kof96_6p:
{
	int energy1 = cpunum_read_byte(0, 0x108239) | 0x0F;
	int energy2 = cpunum_read_byte(0, 0x108439) | 0x0F;

        if( (cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x108239) == 0 && cpunum_read_byte(0, 0x10A84c) == 0 && cpunum_read_byte(0, 0x10A84d) == 0 && cpunum_read_byte(0, 0x10A84e) == 0) ||
          (cpunum_read_byte(0, 0x10A845) == 0 && energy1 == 0xFF ) ||
          (cpunum_read_byte(0, 0x10A856) == 0 && cpunum_read_byte(0, 0x108439) == 0 && cpunum_read_byte(0, 0x10A85d) == 0 && cpunum_read_byte(0, 0x10A85e) == 0 && cpunum_read_byte(0, 0x10A85f) == 0) ||
          (cpunum_read_byte(0, 0x10A856) == 0 && energy2 == 0xFF ) )
            init = 0;
	if(init == 0)
	{
                if(kPlayers == 4 || kPlayers == 2)
                {
		if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 0)
                        change_position(0,1,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 1)
                        change_position(0,1,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 2)
                        change_position(0,1,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 3)  
                        change_position(0,1,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 0)  
                        change_position(0,1,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 1)  
                        change_position(0,1,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 2)  
                        change_position(0,1,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 3)  
                        change_position(0,1,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 0)  
                        change_position(1,0,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 1)  
                        change_position(1,0,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 2)  
                        change_position(1,0,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 3)  
                        change_position(1,0,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 3 && cpunum_read_byte(0, 0x10A856) == 0)  
                        change_position(1,0,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 3 && cpunum_read_byte(0, 0x10A856) == 1)  
                        change_position(1,0,3,2,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 3 && cpunum_read_byte(0, 0x10A856) == 2)  
                        change_position(1,0,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 3 && cpunum_read_byte(0, 0x10A856) == 3)  
                        change_position(1,0,2,3,4,5);
                }
                else if(kPlayers == 5)
                {
		if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 0)
			change_position(0,1,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 1)
			change_position(0,1,2,4,3,5);
		else if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 2)
			change_position(0,1,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 3)  
			change_position(0,1,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 0)  
			change_position(1,0,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 1)  
			change_position(1,0,2,4,3,5);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 2)  
			change_position(1,0,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 3)  
			change_position(1,0,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 0)  
			change_position(1,2,0,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 1)  
			change_position(1,2,0,4,3,5);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 2)  
			change_position(1,2,0,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 3)  
			change_position(1,2,0,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 3 && cpunum_read_byte(0, 0x10A856) == 0)  
			change_position(1,2,0,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 3 && cpunum_read_byte(0, 0x10A856) == 1)  
			change_position(1,2,0,4,3,5);
		else if(cpunum_read_byte(0, 0x10A845) == 3 && cpunum_read_byte(0, 0x10A856) == 2)  
			change_position(1,2,0,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 3 && cpunum_read_byte(0, 0x10A856) == 3)  
			change_position(1,2,0,4,5,3);
                }
                else if(kPlayers == 3 || kPlayers >= 6)
                {
		if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 0)
			change_position(0,1,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 1)
			change_position(0,1,2,4,3,5);
		else if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 2)
			change_position(0,1,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 3)  
			change_position(0,1,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 0)  
			change_position(1,0,2,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 1)  
			change_position(1,0,2,4,3,5);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 2)  
			change_position(1,0,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 3)  
			change_position(1,0,2,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 0)  
			change_position(1,2,0,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 1)  
			change_position(1,2,0,4,3,5);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 2)  
			change_position(1,2,0,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 3)  
			change_position(1,2,0,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 3 && cpunum_read_byte(0, 0x10A856) == 0)  
			change_position(1,2,0,3,4,5);
		else if(cpunum_read_byte(0, 0x10A845) == 3 && cpunum_read_byte(0, 0x10A856) == 1)  
			change_position(1,2,0,4,3,5);
		else if(cpunum_read_byte(0, 0x10A845) == 3 && cpunum_read_byte(0, 0x10A856) == 2)  
			change_position(1,2,0,4,5,3);
		else if(cpunum_read_byte(0, 0x10A845) == 3 && cpunum_read_byte(0, 0x10A856) == 3)  
			change_position(1,2,0,4,5,3);
                }

		if( cpunum_read_byte(0, 0x10A836) == 0x60 )
		{
			init = 1;
		}
	}
	else
	{
		p1_1st = cpunum_read_byte(0, 0x10A84c);
		p1_2nd = cpunum_read_byte(0, 0x10A84d);
		p1_3rd = cpunum_read_byte(0, 0x10A84e);
		p2_1st = cpunum_read_byte(0, 0x10A85d);
		p2_2nd = cpunum_read_byte(0, 0x10A85e);
		p2_3rd = cpunum_read_byte(0, 0x10A85f);

                if( cpunum_read_byte(0, 0x10A836) == 0x60 )
                {
		if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 0)
			kof_swap(p1_1st, p2_1st);
		else if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 1)
			kof_swap(p1_1st, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A845) == 0 && cpunum_read_byte(0, 0x10A856) == 2)  
			kof_swap(p1_1st, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 0)  
			kof_swap(p1_2nd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 1)  
			kof_swap(p1_2nd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A845) == 1 && cpunum_read_byte(0, 0x10A856) == 2)  
			kof_swap(p1_2nd, p2_3rd);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 0)  
			kof_swap(p1_3rd, p2_1st);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 1)  
			kof_swap(p1_3rd, p2_2nd);
		else if(cpunum_read_byte(0, 0x10A845) == 2 && cpunum_read_byte(0, 0x10A856) == 2)  
			kof_swap(p1_3rd, p2_3rd);
                }
	}
	break;
}
case kizuna_4p:
{
	if( (cpunum_read_byte(0, 0x1088EC) == 0xFF && cpunum_read_byte(0, 0x1088EE) == 0xFF) ||
          (cpunum_read_byte(0, 0x1088ED) == 0xFF && cpunum_read_byte(0, 0x1088EF) == 0xFF) )
	init = 0;
	if(init == 0)
	{
		if(kPlayers == 2 || kPlayers >= 4)
		{
			if((cpunum_read_byte(0, 0x1088EC) == 0xFF && cpunum_read_byte(0, 0x1088ED) == 0xFF))
				change_position(0,1,2,3,4,5);
			else if((cpunum_read_byte(0, 0x1088EC) != 0xFF && cpunum_read_byte(0, 0x1088ED) == 0xFF))
				change_position(1,0,2,3,4,5);
			else if((cpunum_read_byte(0, 0x1088EC) == 0xFF && cpunum_read_byte(0, 0x1088ED) != 0xFF))
				change_position(0,1,3,2,4,5);
			else if((cpunum_read_byte(0, 0x1088EC) != 0xFF && cpunum_read_byte(0, 0x1088ED) != 0xFF))
				change_position(1,0,3,2,4,5);
		}
		else if(kPlayers == 3)
		{
			if((cpunum_read_byte(0, 0x1088EC) == 0xFF && cpunum_read_byte(0, 0x1088ED) == 0xFF))
				change_position(0,1,2,3,4,5);
			else if((cpunum_read_byte(0, 0x1088EC) != 0xFF && cpunum_read_byte(0, 0x1088ED) == 0xFF))
				change_position(1,0,2,3,4,5);
			else if((cpunum_read_byte(0, 0x1088EC) == 0xFF && cpunum_read_byte(0, 0x1088ED) != 0xFF))
				change_position(0,1,2,3,4,5);
			else if((cpunum_read_byte(0, 0x1088EC) != 0xFF && cpunum_read_byte(0, 0x1088ED) != 0xFF))
				change_position(1,0,2,3,4,5);
		}

		player1_c = cpunum_read_byte(0, 0x1088EC);
		player2_c = cpunum_read_byte(0, 0x1088EE);
		player3_c = cpunum_read_byte(0, 0x1088ED);
		player4_c = cpunum_read_byte(0, 0x1088EF);
		player1_sub = -1;
		player2_sub = -1;
		player3_sub = -1;
		player4_sub = -1;

		if(player1_c == 0x07)
                        player1_sub = 0x0B;
		else if(player1_c == 0x87)
                        player1_sub = 0x8B;
		if(player2_c == 0x07)
                        player2_sub = 0x0B;
		else if(player2_c == 0x87)
                        player2_sub = 0x8B;
		if(player3_c == 0x07)
                        player3_sub = 0x0B;
		else if(player3_c == 0x87)
                        player3_sub = 0x8B;
		if(player4_c == 0x07)
                        player4_sub = 0x0B;
		else if(player4_c == 0x87)
                        player4_sub = 0x8B;

		if(cpunum_read_byte(0, 0x1088FB) == 0x10)
		{
			init= 1;
		}
	}
	else
	{
            if(kPlayers == 1) {}
            else if(kPlayers == 2 || kPlayers == 3)
            {
			if(cpunum_read_byte(0, 0x10821F) == player1_c || cpunum_read_byte(0, 0x10821F) == player1_sub)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0x10821F) == player2_c || cpunum_read_byte(0, 0x10821F) == player2_sub)
				change_position(1,0,2,3,4,5);
            }
		else if(kPlayers >= 4)
		{
			if( (cpunum_read_byte(0, 0x10821F) == player1_c || cpunum_read_byte(0, 0x10821F) == player1_sub) &&
			    (cpunum_read_byte(0, 0x10841F) == player3_c || cpunum_read_byte(0, 0x10841F) == player3_sub) )
				change_position(0,1,2,3,4,5);
			else if( (cpunum_read_byte(0, 0x10821F) == player2_c || cpunum_read_byte(0, 0x10821F) == player2_sub) &&
			         (cpunum_read_byte(0, 0x10841F) == player3_c || cpunum_read_byte(0, 0x10841F) == player3_sub) )
				change_position(1,0,2,3,4,5);
			else if( (cpunum_read_byte(0, 0x10821F) == player1_c || cpunum_read_byte(0, 0x10821F) == player1_sub) &&
      		         (cpunum_read_byte(0, 0x10841F) == player4_c || cpunum_read_byte(0, 0x10841F) == player4_sub) )
				change_position(0,1,3,2,4,5);
			else if( (cpunum_read_byte(0, 0x10821F) == player2_c || cpunum_read_byte(0, 0x10821F) == player2_sub) &&
			         (cpunum_read_byte(0, 0x10841F) == player4_c || cpunum_read_byte(0, 0x10841F) == player4_sub) )
				change_position(1,0,3,2,4,5);
		}
	}
	break;
}
case rotd_4p:
{
	if( (cpunum_read_byte(0, 0x106BE2) == 0 && cpunum_read_byte(0, 0x106BE6) == 0) ||
          (cpunum_read_byte(0, 0x106BF0) == 0 && cpunum_read_byte(0, 0x106BF4) == 0) )
	init = 0;
	if(init == 0)
	{
		if(kPlayers == 2 || kPlayers >= 4)
		{
			if((cpunum_read_byte(0, 0x106BE2) == 0 && cpunum_read_byte(0, 0x106BF0) == 0))
				change_position(0,1,2,3,4,5);
			else if((cpunum_read_byte(0, 0x106BE2) == 0xFF && cpunum_read_byte(0, 0x106BF0) == 0))
				change_position(1,0,2,3,4,5);
			else if((cpunum_read_byte(0, 0x106BE2) == 0 && cpunum_read_byte(0, 0x106BF0) == 0xFF))
				change_position(0,1,3,2,4,5);
			else if((cpunum_read_byte(0, 0x106BE2) == 0xFF && cpunum_read_byte(0, 0x106BF0) == 0xFF))
				change_position(1,0,3,2,4,5);
		}
		else if(kPlayers == 3)
		{
			if((cpunum_read_byte(0, 0x106BE2) == 0 && cpunum_read_byte(0, 0x106BF0) == 0))
				change_position(0,1,2,3,4,5);
			else if((cpunum_read_byte(0, 0x106BE2) == 0xFF && cpunum_read_byte(0, 0x106BF0) == 0))
				change_position(1,0,2,3,4,5);
			else if((cpunum_read_byte(0, 0x106BE2) == 0 && cpunum_read_byte(0, 0x106BF0) == 0xFF))
				change_position(0,1,2,3,4,5);
			else if((cpunum_read_byte(0, 0x106BE2) == 0xFF && cpunum_read_byte(0, 0x106BF0) == 0xFF))
				change_position(1,0,2,3,4,5);
		}

		if( cpunum_read_byte(0, 0x106BE2) == 0xFF && cpunum_read_byte(0, 0x106BE6) == 0xFF &&
	          cpunum_read_byte(0, 0x106BF0) == 0xFF && cpunum_read_byte(0, 0x106BF4) == 0xFF )
		{
			player1_c = cpunum_read_byte(0, 0x106BE3);
			player2_c = cpunum_read_byte(0, 0x106BE7);
			player3_c = cpunum_read_byte(0, 0x106BF1);
			player4_c = cpunum_read_byte(0, 0x106BF5);
			init = 1;
		}
	}
	else
	{
            if(kPlayers == 1) {}
            else if(kPlayers == 2 || kPlayers == 3)
            {
			if(cpunum_read_byte(0, 0x102763) == player2_c)
				change_position(0,1,2,3,4,5);
			else if(cpunum_read_byte(0, 0x102763) == player1_c)
				change_position(1,0,2,3,4,5);
            }
		else if(kPlayers >= 4)
		{
			if( (cpunum_read_byte(0, 0x102763) == player2_c) &&
			    (cpunum_read_byte(0, 0x1025EB) == player4_c) )
				change_position(0,1,2,3,4,5);
			else if( (cpunum_read_byte(0, 0x102763) == player1_c) &&
			         (cpunum_read_byte(0, 0x1025EB) == player4_c) )
				change_position(1,0,2,3,4,5);
			else if( (cpunum_read_byte(0, 0x102763) == player2_c) &&
      		         (cpunum_read_byte(0, 0x1025EB) == player3_c) )
				change_position(0,1,3,2,4,5);
			else if( (cpunum_read_byte(0, 0x102763) == player1_c) &&
			         (cpunum_read_byte(0, 0x1025EB) == player3_c) )
				change_position(1,0,3,2,4,5);
		}
	}
	break;
}
case lbowling_4p:
{
	if(cpunum_read_byte(0, 0x102C0C) == 0x00 && cpunum_read_byte(0, 0x102C0D) == 0x01)
		change_position(0,1,2,3,4,5);
	else if(cpunum_read_byte(0, 0x102C0C) == 0x02 && cpunum_read_byte(0, 0x102C0D) == 0x01)
		change_position(2,1,0,3,4,5);
	else if(cpunum_read_byte(0, 0x102C0C) == 0x00 && cpunum_read_byte(0, 0x102C0D) == 0x03)
		change_position(0,3,2,1,4,5);
	else if(cpunum_read_byte(0, 0x102C0C) == 0x02 && cpunum_read_byte(0, 0x102C0D) == 0x03)
		change_position(2,3,0,1,4,5);
	break;
}
case cyberbt2p:
{ p2 = 2; p3 = 1; break; }
case loderndf_vs:
{ p2 = 2; p3 = 1; break; }
case none: break;
}

/************************/
			switch(kaillera_schedule)
			{
			case KS_RESET:
				ui_key = K_UI_RESET_MACHINE;
				break;
			case KS_SAVE:
				if (kcrccounter == 0)
					ui_key = K_UI_AUTO_SAVE;
				break;
			case KS_CRC:
				{
					UINT32 crc = fgetsavecrc(Machine->gamedrv->name, "~");
					char	buf[256];
					sprintf(buf, "%08X", crc);
					SendKailleraCommand(KC_savecrc, buf);
				}
				break;
			case KS_DIP:
				ui_key = K_UI_APPLY_DIP;
				break;
			default:
				if(kPlayerNB == 1)
				{
					if(input_ui_pressed(IPT_UI_RESET_MACHINE)) ui_key = K_UI_RESET_MACHINE;
                              else if(input_ui_pressed(IPT_UI_P1_SHIFT_DOWN)) ui_key = K_UI_SHIFT_DOWN;
                              else if(input_ui_pressed(IPT_UI_P1_SHIFT_UP)) ui_key = K_UI_SHIFT_UP;
					else if(input_ui_pressed(IPT_UI_SWAP_CONTROL)) ui_key = K_UI_SWAP_CONTROL;
					else if(input_ui_pressed(IPT_UI_LOAD_STATE) && kcrccounter == 0) ui_key = K_UI_LOAD_STATE;
					else if(input_ui_pressed(IPT_UI_LOAD_AUTOSAVE) && kcrccounter == 0) ui_key = K_UI_LOAD_AUTOSAVE;
					else if(input_ui_pressed(IPT_UI_SAVE_STATE) && kcrccounter == 0) ui_key = K_UI_SAVE_STATE;
					else if(input_ui_pressed(IPT_UI_PAUSE) && !KailleraChatIsActive()) ui_key = K_UI_PAUSE;
				}
			}
			if (kaillera_schedule != KS_CLOSE) kaillera_schedule = KS_NONE;

			if(ui_key == K_UI_NONE) {
				switch(control_type) {
				case 0:
			  		val[0] = 0;
					b = 1;

	                        for (i = 0; i < 15; i++)
					{
					if (kBitsPlayValues[0][i][0] != -1)
						if (~input_port_value[kBitsPlayValues[0][i][0]] & kBitsPlayValues[0][i][1])
							val[0] |= b;
					b = b << 1;
					}
					break;
				case 1:
			  		val2[0] = 0;
					b = 1;

	                        for (i = 0; i < 3; i++)
					{
					if (kBitsPlayValues[0][i][0] != -1)
						if (~input_port_value[kBitsPlayValues[0][i][0]] & kBitsPlayValues[0][i][1])
							val2[0] |= b;
					b = b << 1;
					}
	                        for (i = 3; i < 7; i++)
					{
					if (kBitsPlayValues[0][i][0] != -1)
						if (input_port_value[kBitsPlayValues[0][i][0]] & kBitsPlayValues[0][i][3])
							val2[0] |= b;
					b = b << 1;
					}
	                        for (i = 7; i < 15; i++)
					{
					if (kBitsPlayValues[0][i][0] != -1)
						if (~input_port_value[kBitsPlayValues[0][i][0]] & kBitsPlayValues[0][i][1])
							val2[0] |= b;
					b = b << 1;
					}

					/* append mouse positions to the end of val2 */
					val2[0] = val2[0] << 7;
					if (mouse_delta_axis[0][0] > 0 && mouse_delta_axis[0][0] < 128) {
						val2[0] = val2[0] + mouse_delta_axis[0][0];
						val2[0] = val2[0] << 1;
					} else if (mouse_delta_axis[0][0] < 0 && mouse_delta_axis[0][0] > -128) {
						val2[0] = val2[0] - mouse_delta_axis[0][0];
						val2[0] = val2[0] << 1;
						val2[0] |= 1;
					} else if (mouse_delta_axis[0][0] >= 128) {
						val2[0] = val2[0] + 127;
						val2[0] = val2[0] << 1;
					} else if (mouse_delta_axis[0][0] <= -128) {
						val2[0] = val2[0] + 127;
						val2[0] = val2[0] << 1;
						val2[0] |= 1;
					} else if (mouse_delta_axis[0][0] == 0) {
						val2[0] = val2[0] << 1;
					}
					val2[0] = val2[0] << 7;
					if (mouse_delta_axis[0][1] > 0 && mouse_delta_axis[0][1] < 128) {
						val2[0] = val2[0] + mouse_delta_axis[0][1];
						val2[0] = val2[0] << 1;
					} else if (mouse_delta_axis[0][1] < 0 && mouse_delta_axis[0][1] > -128) {
						val2[0] = val2[0] - mouse_delta_axis[0][1];
						val2[0] = val2[0] << 1;
						val2[0] |= 1;
					} else if (mouse_delta_axis[0][1] >= 128) {
						val2[0] = val2[0] + 127;
						val2[0] = val2[0] << 1;
					} else if (mouse_delta_axis[0][1] <= -128) {
						val2[0] = val2[0] + 127;
						val2[0] = val2[0] << 1;
						val2[0] |= 1;
					} else if (mouse_delta_axis[0][1] == 0) {
						val2[0] = val2[0] << 1;
					}
					break; 
				case 2:
			  		val2[0] = 0;
					b = 1;

	                        for (i = 0; i < 30; i++)
					{
					if (kBitsPlayValues[0][i][0] != -1)
						if (~input_port_value[kBitsPlayValues[0][i][0]] & kBitsPlayValues[0][i][1])
							val2[0] |= b;
					b = b << 1;
					}
					break;
				}
			} else {
				if (control_type == 0) val[0] = ui_key | K_UI_UIBIT;
				else val2[0] = ui_key | K_UI_UIBIT_L;
			}

			if (control_type == 0) {
		                  st=cycle_counter();
					recvLen=kailleraModifyPlayValues((void *)val, 2);
	      	            addClock(cycle_counter()-st);
			}
			else {
		                  st=cycle_counter();
					recvLen=kailleraModifyPlayValues((void *)val2, 4);
	      	            addClock(cycle_counter()-st);
			}

			if (recvLen > 0)
			{
				memcpy(input_port_value, kDefValues, sizeof(input_port_value));

				switch(control_type) {                                     
				case 0:
					for (i = 0; i < (recvLen / 2); i++)
					{
						int j;
                  	            int p = 0;
						if((val[i] & K_UI_UIBIT) != 0)
						{
							ui_key = val[i] & K_UI_MASK;
							switch(ui_key) {
							case K_UI_RESET_MACHINE:
								if(record)
								{
									writeword(trace,IPT_UI_RESET_MACHINE);
									special_key = 1;
								}
								machine_reset();
      	                                    p1_pos = 1;
								p1	= 0;
								p2	= 1;
								p3	= 2;
								p4	= 3;
								p5	= 4;
								p6	= 5;
								p7	= 6;
								p8	= 7;
								ana_p1= 0;
								ana_p2= 1;
								ana_p3= 2;
								ana_p4= 3;
								control_counter = 0;
								init = -1;
								usrintf_showmessage("Reset");
								break;
							case K_UI_LOAD_STATE:
								if(record)
								{
									writeword(trace,IPT_UI_LOAD_STATE);
									special_key = 1;
								}
								cpu_loadsave_schedule(LOADSAVE_LOAD, '@');
								usrintf_showmessage("State loaded");
								if (ksavecounter) ksavecounter = 1;
								break;
      	                              case K_UI_SAVE_STATE:
								if(record)
								{
									writeword(trace,IPT_UI_SAVE_STATE);
									special_key = 1;
								}
	                                          cpu_loadsave_schedule(LOADSAVE_SAVE, '@');
      	                                    usrintf_showmessage("State saved");
            	                              break;
							case K_UI_AUTO_SAVE:
								cpu_loadsave_schedule(LOADSAVE_SAVE, '~');
								kcrccounter = 3 * 60;
								kgotcrc = 0;
								kaillera_schedule = KS_CRC;
								break;
							case K_UI_LOAD_AUTOSAVE:
								cpu_loadsave_schedule(LOADSAVE_LOAD, '~');
								usrintf_showmessage("Auto Save loaded");
								if (ksavecounter) ksavecounter = 1;
								break;
							case K_UI_PAUSE:
								netplay_pause = -netplay_pause;
								if(netplay_pause == 1) usrintf_showmessage("Pause");
								else if(netplay_pause == -1) usrintf_showmessage("Unpause");
								break;
							case K_UI_APPLY_DIP:
								in = Machine->input_ports;
								in++;
								port = 0;
								while (in->type != IPT_END && port < MAX_INPUT_PORTS)
								{
									while (in->type != IPT_END && in->type != IPT_PORT)
									{
										if ((in->type & ~IPF_MASK) == IPT_DIPSWITCH_NAME)
										{
											kDefValues[port] =
												(kDefValues[port] & ~in->mask) | (in->default_value & in->mask);
										}
										in++;
									}
									port++;
									if (in->type == IPT_PORT) in++;
								}
								usrintf_showmessage("Dipswitch changed");
								break;
	                                    case K_UI_SHIFT_DOWN:
      	                                    shift_down();
            	                              break;
	                                    case K_UI_SHIFT_UP:
      	                                    shift_up();
            	                              break;
	                                    case K_UI_SWAP_CONTROL:
      	                                 	swap_control();
            	                              break;
							}
							continue;
						}
						b = 1;
  
      	                        for (j = 0; j < 15; j++)
						{
							switch(i)
							{
				                        case 0: p = p1; break;
      	                                    case 1: p = p2; break;
            	                              case 2: p = p3; break;
                  	                        case 3: p = p4; break;
                        	                  case 4: p = p5; break;
                              	            case 5: p = p6; break;
                              	            case 6: p = p7; break;
                              	            case 7: p = p8; break;
							}
      	                              if (kBitsPlayValues[p][j][0] != -1)
            	                        {
                  	            	      if (kBitsPlayValues[p][j][2] != IP_ACTIVE_LOW)
                        	                  {
                              	      	      if (!(val[i] & b)) {
	                                  	      	      input_port_value[kBitsPlayValues[p][j][0]] |= kBitsPlayValues[p][j][1];
			      	                              if (kBitsPlayValues[p][j][4] != -1) {
	      	                  	                        input_port_value[kBitsPlayValues[p][j][4]] |= kBitsPlayValues[p][j][5];
										}
									}
      	                                    }
            	                              else
                  	                        {
	                  	                        if (val[i] & b) {
      	                  	                        input_port_value[kBitsPlayValues[p][j][0]] &= ~kBitsPlayValues[p][j][1];
			      	                              if (kBitsPlayValues[p][j][4] != -1) {
	      	                  	                        input_port_value[kBitsPlayValues[p][j][4]] &= ~kBitsPlayValues[p][j][5];
										}
									}
                                    	      }
	                                     }
      	                               b =b << 1;
						}
					}
					break;
				case 1:
					for (i = 0; i < (recvLen / 4); i++)
					{
						int k, is_negative, j;
	                              int p = 0;
	
						if((val2[i] & K_UI_UIBIT_L) != 0)
						{
							ui_key = val2[i] & K_UI_MASK_L;
							switch(ui_key) {
							case K_UI_RESET_MACHINE:
								if(record)
								{
									writeword(trace,IPT_UI_RESET_MACHINE);
									special_key = 1;
								}
								machine_reset();
      	                                    p1_pos = 1;
								p1	= 0;
								p2	= 1;
								p3	= 2;
								p4	= 3;
								p5	= 4;
								p6	= 5;
								ana_p1= 0;
								ana_p2= 1;
								ana_p3= 2;
								ana_p4= 3;
								control_counter = 0;
								init = -1;
								usrintf_showmessage("Reset");
								break;
							case K_UI_LOAD_STATE:
								if(record)
								{
									writeword(trace,IPT_UI_LOAD_STATE);
									special_key = 1;
								}
								cpu_loadsave_schedule(LOADSAVE_LOAD, '@');
								usrintf_showmessage("State loaded");
								if (ksavecounter) ksavecounter = 1;
								break;
	                                    case K_UI_SAVE_STATE:
								if(record)
								{
									writeword(trace,IPT_UI_SAVE_STATE);
									special_key = 1;
								}
                                    	      cpu_loadsave_schedule(LOADSAVE_SAVE, '@');
	                                          usrintf_showmessage("State saved");
      	                                    break;
							case K_UI_AUTO_SAVE:
								cpu_loadsave_schedule(LOADSAVE_SAVE, '~');
								kcrccounter = 3 * 60;
								kgotcrc = 0;
								kaillera_schedule = KS_CRC;
								break;
							case K_UI_LOAD_AUTOSAVE:
								cpu_loadsave_schedule(LOADSAVE_LOAD, '~');
								usrintf_showmessage("Auto Save loaded");
								if (ksavecounter) ksavecounter = 1;
								break;
							case K_UI_PAUSE:
								netplay_pause = -netplay_pause;
								if(netplay_pause == 1) usrintf_showmessage("Pause");
								else if(netplay_pause == -1) usrintf_showmessage("Unpause");
								break;
							case K_UI_APPLY_DIP:
								in = Machine->input_ports;
								in++;
								port = 0;
								while (in->type != IPT_END && port < MAX_INPUT_PORTS)
								{
									while (in->type != IPT_END && in->type != IPT_PORT)
									{
										if ((in->type & ~IPF_MASK) == IPT_DIPSWITCH_NAME)
										{
											kDefValues[port] =
												(kDefValues[port] & ~in->mask) | (in->default_value & in->mask);
										}
										in++;
									}
									port++;
									if (in->type == IPT_PORT) in++;
								}
								usrintf_showmessage("Dipswitch changed");
								break;
	                                    case K_UI_SHIFT_DOWN:
      	                                    shift_down();
            	                              break;
                  	                  case K_UI_SHIFT_UP:
                        	                  shift_up();
                              	            break;
                                    	case K_UI_SWAP_CONTROL:
	                                       	swap_control();
      	                                    break;
							}
							continue;
						}
						deltax[i] = 0;
						deltay[i] = 0;

						/* y position */
						is_negative = 0;
						b = 1;
						if (val2[i] & b) is_negative = 1;
						val2[i] = val2[i] >> 1;
						for (k = 0; k < 7; k++) {
							if (val2[i] & b) deltay[i] |= b;
							b = b << 1;
						}
						val2[i] = val2[i] >> 7;
//						if (deltay[i] != 0) deltay[i] = deltay[i] + 1;
						if (is_negative) deltay[i] = -deltay[i];

						/* x position */
						is_negative = 0;
						b = 1;
						if (val2[i] & b) is_negative = 1;
						val2[i] = val2[i] >> 1;
						for (k = 0; k < 7; k++) {
							if (val2[i] & b) deltax[i] |= b;
							b = b << 1;
						}
						val2[i] = val2[i] >> 7;
//						if (deltax[i] != 0) deltax[i] = deltax[i] + 1;
						if (is_negative) deltax[i] = -deltax[i];

						b = 1;
	                              for (j = 0; j < 3; j++)
						{
							switch(i)
							{
				                        case 0: p = p1; break;
      	                                    case 1: p = p2; break;
            	                              case 2: p = p3; break;
                  	                        case 3: p = p4; break;
                        	                  case 4: p = p5; break;
                              	            case 5: p = p6; break;
							}
      	                              if (kBitsPlayValues[p][j][0] != -1)
            	                        {
                  	            	      if (kBitsPlayValues[p][j][2] != IP_ACTIVE_LOW)
                        	                  {
                              	      	      if (!(val2[i] & b)) {
                                    	      	      input_port_value[kBitsPlayValues[p][j][0]] |= kBitsPlayValues[p][j][1];
			      	                              if (kBitsPlayValues[p][j][4] != -1) {
	      	                  	                        input_port_value[kBitsPlayValues[p][j][4]] |= kBitsPlayValues[p][j][5];
										}
									}
                                          	}
	                                          else
      	                                    {
	      	                                    if (val2[i] & b) {
      	      	                                    input_port_value[kBitsPlayValues[p][j][0]] &= ~kBitsPlayValues[p][j][1];
			      	                              if (kBitsPlayValues[p][j][4] != -1) {
	      	                  	                        input_port_value[kBitsPlayValues[p][j][4]] &= ~kBitsPlayValues[p][j][5];
										}
									}
                        	                  }
                              	       }
                                    	 b =b << 1;
						}
      	                        for (j = 3; j < 7; j++)
						{
							b =b << 1;
						}
                              	for (j = 7; j < 15; j++)
						{
							switch(i)
							{
				                        case 0: p = p1; break;
      	                                    case 1: p = p2; break;
            	                              case 2: p = p3; break;
                  	                        case 3: p = p4; break;
                        	                  case 4: p = p5; break;
                              	            case 5: p = p6; break;
							}
	                                    if (kBitsPlayValues[p][j][0] != -1)
      	                              {
            	                  	      if (kBitsPlayValues[p][j][2] != IP_ACTIVE_LOW)
                  	                        {
                              	      	      if (!(val2[i] & b)) {
                                    	      	      input_port_value[kBitsPlayValues[p][j][0]] |= kBitsPlayValues[p][j][1];
			      	                              if (kBitsPlayValues[p][j][4] != -1) {
	      	                  	                        input_port_value[kBitsPlayValues[p][j][4]] |= kBitsPlayValues[p][j][5];
										}
									}
                                    	      }
	                                          else
      	                                    {
                              	      	      if (val2[i] & b) {
                                    	      	      input_port_value[kBitsPlayValues[p][j][0]] &= ~kBitsPlayValues[p][j][1];
			      	                              if (kBitsPlayValues[p][j][4] != -1) {
	      	                  	                        input_port_value[kBitsPlayValues[p][j][4]] &= ~kBitsPlayValues[p][j][5];
										}
									}
                        	                  }
                              	       }
	                                     b =b << 1;
						}
					}
					break;
				case 2:
					for (i = 0; i < (recvLen / 4); i++)
					{
						int j;
	                              int p = 0;
	
						if((val2[i] & K_UI_UIBIT_L) != 0)
						{
							ui_key = val2[i] & K_UI_MASK_L;
							switch(ui_key) {
							case K_UI_RESET_MACHINE:
								if(record)
								{
									writeword(trace,IPT_UI_RESET_MACHINE);
									special_key = 1;
								}
								machine_reset();
      	                                    p1_pos = 1;
								p1	= 0;
								p2	= 1;
								p3	= 2;
								p4	= 3;
								p5	= 4;
								p6	= 5;
								ana_p1= 0;
								ana_p2= 1;
								ana_p3= 2;
								ana_p4= 3;
								control_counter = 0;
								init = -1;
								usrintf_showmessage("Reset");
								break;
							case K_UI_LOAD_STATE:
								if(record)
								{
									writeword(trace,IPT_UI_LOAD_STATE);
									special_key = 1;
								}
								cpu_loadsave_schedule(LOADSAVE_LOAD, '@');
								usrintf_showmessage("State loaded");
								if (ksavecounter) ksavecounter = 1;
								break;
	                                    case K_UI_SAVE_STATE:
								if(record)
								{
									writeword(trace,IPT_UI_SAVE_STATE);
									special_key = 1;
								}
                                    	      cpu_loadsave_schedule(LOADSAVE_SAVE, '@');
	                                          usrintf_showmessage("State saved");
      	                                    break;
							case K_UI_AUTO_SAVE:
								cpu_loadsave_schedule(LOADSAVE_SAVE, '~');
								kcrccounter = 3 * 60;
								kgotcrc = 0;
								kaillera_schedule = KS_CRC;
								break;
							case K_UI_LOAD_AUTOSAVE:
								cpu_loadsave_schedule(LOADSAVE_LOAD, '~');
								usrintf_showmessage("Auto Save loaded");
								if (ksavecounter) ksavecounter = 1;
								break;
							case K_UI_PAUSE:
								netplay_pause = -netplay_pause;
								if(netplay_pause == 1) usrintf_showmessage("Pause");
								else if(netplay_pause == -1) usrintf_showmessage("Unpause");
								break;
							case K_UI_APPLY_DIP:
								in = Machine->input_ports;
								in++;
								port = 0;
								while (in->type != IPT_END && port < MAX_INPUT_PORTS)
								{
									while (in->type != IPT_END && in->type != IPT_PORT)
									{
										if ((in->type & ~IPF_MASK) == IPT_DIPSWITCH_NAME)
										{
											kDefValues[port] =
												(kDefValues[port] & ~in->mask) | (in->default_value & in->mask);
										}
										in++;
									}
									port++;
									if (in->type == IPT_PORT) in++;
								}
								usrintf_showmessage("Dipswitch changed");
								break;
	                                    case K_UI_SHIFT_DOWN:
      	                                    shift_down();
            	                              break;
                  	                  case K_UI_SHIFT_UP:
                        	                  shift_up();
                              	            break;
                                    	case K_UI_SWAP_CONTROL:
	                                       	swap_control();
      	                                    break;
							}
							continue;
						}
						b = 1;

	                              for (j = 0; j < 30; j++)
						{
							switch(i)
							{
				                        case 0: p = p1; break;
      	                                    case 1: p = p2; break;
            	                              case 2: p = p3; break;
                  	                        case 3: p = p4; break;
                        	                  case 4: p = p5; break;
                              	            case 5: p = p6; break;
							}
      	                              if (kBitsPlayValues[p][j][0] != -1)
            	                        {
                  	            	      if (kBitsPlayValues[p][j][2] != IP_ACTIVE_LOW)
                        	                  {
                              	      	      if (!(val2[i] & b)) {
	                                  	      	      input_port_value[kBitsPlayValues[p][j][0]] |= kBitsPlayValues[p][j][1];
			      	                              if (kBitsPlayValues[p][j][4] != -1) {
	      	                  	                        input_port_value[kBitsPlayValues[p][j][4]] |= kBitsPlayValues[p][j][5];
										}
									}
                                          	}
	                                          else
      	                                    {
                              	      	      if (val2[i] & b) {
                                    	      	      input_port_value[kBitsPlayValues[p][j][0]] &= ~kBitsPlayValues[p][j][1];
			      	                              if (kBitsPlayValues[p][j][4] != -1) {
	      	                  	                        input_port_value[kBitsPlayValues[p][j][4]] &= ~kBitsPlayValues[p][j][5];
										}
									}
                        	                  }
                              	       }
                                    	 b =b << 1;
						}
					}
					break;
				}
			}
			if (recvLen == 0)
				memcpy(kDefValues, input_port_value, sizeof(input_port_value));
		}
	}
#endif /* KAILLERA */

#ifdef KAILLERA
	if (record && netplay_pause == -1)
	{
		int i;
		for (i = 0; i < MAX_INPUT_PORTS; i ++) {
			writeword(record,input_port_value[i]);
		}
		if(!special_key) {
			for (i = 0; i < MAX_INPUT_PORTS; i ++) {
				writeword(trace,0x0);
			}
		}
		else {
			for (i = 0; i < MAX_INPUT_PORTS-1; i ++) {
				writeword(trace,0x0);
			}
		}
	}
#else
	if (record)
	{
		int i;

		for (i = 0; i < MAX_INPUT_PORTS; i ++)
			writeword(record,input_port_value[i]);
	}
#endif
#ifdef MAME_NET
	if ( net_active() && (default_player != NET_SPECTATOR) )
		net_input_sync((unsigned char *) input_port_value, (unsigned char *) input_port_defaults, MAX_INPUT_PORTS);
#endif /* MAME_NET */

profiler_mark(PROFILER_END);
}

#ifdef KAILLERA
void shift_down(void)
{
        if(p1_pos == 1)
        {
                change_position(1,0,2,3,4,5);
                p1_pos = 2;
                control_counter = 3;
                usrintf_showmessage("P1 Shift Down: 2*34");
        }
        else if(p1_pos == 2)
        {
                change_position(2,0,1,3,4,5);
                p1_pos = 3;
                control_counter = 6;
                usrintf_showmessage("P1 Shift Down: 23*4");
        }
        else if(p1_pos == 3)
        {
                change_position(3,0,1,2,4,5);
                p1_pos = 4;
		    control_counter = 9;
                usrintf_showmessage("P1 Shift Down: 234*");
        }
        else if(p1_pos == 4)
        {
		    control_counter = 9;
                usrintf_showmessage("P1 Shift Down: 234*");
        }
}

void shift_up(void)
{
        if(p1_pos == 1)
        {
                control_counter = 0;
                usrintf_showmessage("P1 Shift Up: *234");
        }
        else if(p1_pos == 2)
        {
                change_position(0,1,2,3,4,5);
                p1_pos = 1;
                control_counter = 0;
                usrintf_showmessage("P1 Shift Up: *234");
        }
        else if(p1_pos == 3)
        {
                change_position(1,0,2,3,4,5);
                p1_pos = 2;
                control_counter = 3;
                usrintf_showmessage("P1 Shift Up: 2*34");
        }
        else if(p1_pos == 4)
        {
                change_position(2,0,1,3,4,5);
                p1_pos = 3;
                control_counter = 6;
                usrintf_showmessage("P1 Shift Up: 23*4");
        }
}

void swap_control(void)
{
	switch(control_counter)
	{
	case 0:
      {
		change_position(0,1,3,2,4,5);
		control_counter++;
            p1_pos = 1;
            usrintf_showmessage("Swap Controls: 1243");
		break;
	}
	case 1:
      {
		change_position(0,2,1,3,4,5);
		control_counter++;
            p1_pos = 1;
            usrintf_showmessage("Swap Controls: 1324");
		break;
	}
	case 2:
	{
		change_position(0,3,2,1,4,5);
		control_counter++;
            p1_pos = 1;
            usrintf_showmessage("Swap Controls: 1432");
		break;
	}
	case 3:
	{
		change_position(1,0,3,2,4,5);
		control_counter++;
            p1_pos = 2;
            usrintf_showmessage("Swap Controls: 2143");
		break;
	}
	case 4:
	{
		change_position(2,0,1,3,4,5);
		control_counter++;
            p1_pos = 3;
            usrintf_showmessage("Swap Controls: 2314");
		break;
	}
	case 5:
	{
		change_position(3,0,2,1,4,5);
		control_counter++;
            p1_pos = 4;
            usrintf_showmessage("Swap Controls: 2431");
		break;
	}
	case 6:
	{
		change_position(1,2,0,3,4,5);
		control_counter++;
            p1_pos = 2;
            usrintf_showmessage("Swap Controls: 3124");
		break;
	}
	case 7:
	{
		change_position(2,1,0,3,4,5);
		control_counter++;
            p1_pos = 3;
            usrintf_showmessage("Swap Controls: 3214");
		break;
	}
	case 8:
	{
		change_position(3,2,0,1,4,5);
		control_counter++;
            p1_pos = 4;
            usrintf_showmessage("Swap Controls: 3421");
		break;
	}
	case 9:
	{
		change_position(1,3,2,0,4,5);
		control_counter++;
            p1_pos = 2;
            usrintf_showmessage("Swap Controls: 4132");
		break;
	}
	case 10:
	{
		change_position(2,1,3,0,4,5);
		control_counter++;
            p1_pos = 3;
            usrintf_showmessage("Swap Controls: 4213");
		break;
	}
	case 11:
	{
		change_position(3,2,1,0,4,5);
		control_counter++;
            p1_pos = 4;
            usrintf_showmessage("Swap Controls: 4321");
		break;
	}
	case 12:
	{
		change_position(0,1,2,3,4,5);
		control_counter = 0;
            p1_pos = 1;
            usrintf_showmessage("Swap Controls: 1234");
		break;
	}
	}
}

void change_position(int pos1, int pos2, int pos3, int pos4, int pos5, int pos6)
{
        p1 = pos1;
        p2 = pos2;
        p3 = pos3;
        p4 = pos4;
	  p5 = pos5;
	  p6 = pos6;

	  // analog control is a little bit different
	switch(p1) {
		case 0: ana_p1 = 0; break;
		case 1: ana_p2 = 0; break;
		case 2: ana_p3 = 0; break;
		case 3: ana_p4 = 0; break;
	}

	switch(p2) {
		case 0: ana_p1 = 1; break;
		case 1: ana_p2 = 1; break;
		case 2: ana_p3 = 1; break;
		case 3: ana_p4 = 1; break;
	}

	switch(p3) {
		case 0: ana_p1 = 2; break;
		case 1: ana_p2 = 2; break;
		case 2: ana_p3 = 2; break;
		case 3: ana_p4 = 2; break;
	}

	switch(p4) {
		case 0: ana_p1 = 3; break;
		case 1: ana_p2 = 3; break;
		case 2: ana_p3 = 3; break;
		case 3: ana_p4 = 3; break;
	}
}

void change_position2(int pos1, int pos2, int pos3, int pos4, int pos5, int pos6, int pos7, int pos8)
{
        p1 = pos1;
        p2 = pos2;
        p3 = pos3;
        p4 = pos4;
	  p5 = pos5;
	  p6 = pos6;
	  p7 = pos7;
	  p8 = pos8;
}

void kof_swap(int pp1, int pp2)
{
        if(kPlayers == 4 || kPlayers == 2)
        {
			if(pp1 == 0 && pp2 == 0)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == 0 && pp2 == 1)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == 0 && pp2 == 2)
                                change_position(0,1,2,3,4,5);
			else if(pp1 == 0 && pp2 == 3)
                                change_position(0,1,2,3,4,5);
			else if(pp1 == 1 && pp2 == 0)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == 1 && pp2 == 1)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == 1 && pp2 == 2)
                                change_position(0,1,2,3,4,5);
			else if(pp1 == 1 && pp2 == 3)
                                change_position(0,1,2,3,4,5);
			else if(pp1 == 2 && pp2 == 0)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == 2 && pp2 == 1)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == 2 && pp2 == 2)
                                change_position(1,0,2,3,4,5);
			else if(pp1 == 2 && pp2 == 3)
                                change_position(1,0,2,3,4,5);
			else if(pp1 == 3 && pp2 == 0)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == 3 && pp2 == 1)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == 3 && pp2 == 2)
                                change_position(1,0,2,3,4,5);
			else if(pp1 == 3 && pp2 == 3)
                                change_position(1,0,2,3,4,5);
        }
        else if(kPlayers == 5)
        {
			if(pp1 == 0 && pp2 == 0)
				change_position(0,1,2,3,4,5);
			else if(pp1 == 0 && pp2 == 1)
                                change_position(0,1,2,3,4,5);
			else if(pp1 == 0 && pp2 == 2)
                                change_position(0,1,2,4,3,5);
			else if(pp1 == 0 && pp2 == 3)
                                change_position(0,1,2,4,3,5);
			else if(pp1 == 1 && pp2 == 0)
				change_position(1,0,2,3,4,5);
			else if(pp1 == 1 && pp2 == 1)
                                change_position(1,0,2,3,4,5);
			else if(pp1 == 1 && pp2 == 2)
                                change_position(1,0,2,4,3,5);
			else if(pp1 == 1 && pp2 == 3)
                                change_position(1,0,2,4,3,5);
			else if(pp1 == 2 && pp2 == 0)
				change_position(1,2,0,3,4,5);
			else if(pp1 == 2 && pp2 == 1)
                                change_position(1,2,0,3,4,5);
			else if(pp1 == 2 && pp2 == 2)
                                change_position(1,2,0,4,3,5);
			else if(pp1 == 2 && pp2 == 3)
                                change_position(1,2,0,4,3,5);
			else if(pp1 == 3 && pp2 == 0)
				change_position(1,2,0,3,4,5);
			else if(pp1 == 3 && pp2 == 1)
                                change_position(1,2,0,3,4,5);
			else if(pp1 == 3 && pp2 == 2)
                                change_position(1,2,0,4,3,5);
			else if(pp1 == 3 && pp2 == 3)
                                change_position(1,2,0,4,3,5);
        }
        else if(kPlayers == 3 || kPlayers >= 6)
        {
			if(pp1 == 0 && pp2 == 0)
				change_position(0,1,2,3,4,5);
			else if(pp1 == 0 && pp2 == 1)
				change_position(0,1,2,4,3,5);
			else if(pp1 == 0 && pp2 == 2)
				change_position(0,1,2,4,5,3);
			else if(pp1 == 0 && pp2 == 3)
				change_position(0,1,2,4,5,3);
			else if(pp1 == 1 && pp2 == 0)
				change_position(1,0,2,3,4,5);
			else if(pp1 == 1 && pp2 == 1)
				change_position(1,0,2,4,3,5);
			else if(pp1 == 1 && pp2 == 2)
				change_position(1,0,2,4,5,3);
			else if(pp1 == 1 && pp2 == 3)
				change_position(1,0,2,4,5,3);
			else if(pp1 == 2 && pp2 == 0)
				change_position(1,2,0,3,4,5);
			else if(pp1 == 2 && pp2 == 1)
				change_position(1,2,0,4,3,5);
			else if(pp1 == 2 && pp2 == 2)
				change_position(1,2,0,4,5,3);
			else if(pp1 == 2 && pp2 == 3)
				change_position(1,2,0,4,5,3);
			else if(pp1 == 3 && pp2 == 0)
				change_position(1,2,0,3,4,5);
			else if(pp1 == 3 && pp2 == 1)
				change_position(1,2,0,4,3,5);
			else if(pp1 == 3 && pp2 == 2)
				change_position(1,2,0,4,5,3);
			else if(pp1 == 3 && pp2 == 3)
				change_position(1,2,0,4,5,3);
        }
}

void kof_swap2(int pp1, int pp2)
{
        if(kPlayers == 4 || kPlayers == 2)
        {
			if(pp1 == p1_1c && pp2 == p2_1c)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == p1_1c && pp2 == p2_2c)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == p1_1c && pp2 == p2_3c)
                                change_position(0,1,2,3,4,5);
			else if(pp1 == p1_1c && pp2 == p2_4c)
                                change_position(0,1,2,3,4,5);
			else if(pp1 == p1_2c && pp2 == p2_1c)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == p1_2c && pp2 == p2_2c)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == p1_2c && pp2 == p2_3c)
                                change_position(0,1,2,3,4,5);
			else if(pp1 == p1_2c && pp2 == p2_4c)
                                change_position(0,1,2,3,4,5);
			else if(pp1 == p1_3c && pp2 == p2_1c)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == p1_3c && pp2 == p2_2c)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == p1_3c && pp2 == p2_3c)
                                change_position(1,0,2,3,4,5);
			else if(pp1 == p1_3c && pp2 == p2_4c)
                                change_position(1,0,2,3,4,5);
			else if(pp1 == p1_4c && pp2 == p2_1c)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == p1_4c && pp2 == p2_2c)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == p1_4c && pp2 == p2_3c)
                                change_position(1,0,2,3,4,5);
			else if(pp1 == p1_4c && pp2 == p2_4c)
                                change_position(1,0,2,3,4,5);
        }
        else if(kPlayers == 3)
        {
			if(pp1 == p1_1c && pp2 == p2_1c)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == p1_1c && pp2 == p2_2c)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == p1_1c && pp2 == p2_3c)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == p1_1c && pp2 == p2_4c)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == p1_2c && pp2 == p2_1c)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == p1_2c && pp2 == p2_2c)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == p1_2c && pp2 == p2_3c)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == p1_2c && pp2 == p2_4c)
                                change_position(0,1,3,2,4,5);
			else if(pp1 == p1_3c && pp2 == p2_1c)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == p1_3c && pp2 == p2_2c)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == p1_3c && pp2 == p2_3c)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == p1_3c && pp2 == p2_4c)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == p1_4c && pp2 == p2_1c)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == p1_4c && pp2 == p2_2c)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == p1_4c && pp2 == p2_3c)
                                change_position(1,0,3,2,4,5);
			else if(pp1 == p1_4c && pp2 == p2_4c)
                                change_position(1,0,3,2,4,5);
        }
        else if(kPlayers == 5)
        {
			if(pp1 == p1_1c && pp2 == p2_1c)
					change_position(0,1,2,3,4,5);
			else if(pp1 == p1_1c && pp2 == p2_2c)
                                change_position(0,1,2,3,4,5);
			else if(pp1 == p1_1c && pp2 == p2_3c)
                                change_position(0,1,2,4,3,5);
			else if(pp1 == p1_1c && pp2 == p2_4c)
                                change_position(0,1,2,4,3,5);
			else if(pp1 == p1_2c && pp2 == p2_1c)
					change_position(1,0,2,3,4,5);
			else if(pp1 == p1_2c && pp2 == p2_2c)
                                change_position(1,0,2,3,4,5);
			else if(pp1 == p1_2c && pp2 == p2_3c)
                                change_position(1,0,2,4,3,5);
			else if(pp1 == p1_2c && pp2 == p2_4c)
                                change_position(1,0,2,4,3,5);
			else if(pp1 == p1_3c && pp2 == p2_1c)
					change_position(1,2,0,3,4,5);
			else if(pp1 == p1_3c && pp2 == p2_2c)
                                change_position(1,2,0,3,4,5);
			else if(pp1 == p1_3c && pp2 == p2_3c)
                                change_position(1,2,0,4,3,5);
			else if(pp1 == p1_3c && pp2 == p2_4c)
                                change_position(1,2,0,4,3,5);
			else if(pp1 == p1_4c && pp2 == p2_1c)
					change_position(1,2,0,3,4,5);
			else if(pp1 == p1_4c && pp2 == p2_2c)
                                change_position(1,2,0,3,4,5);
			else if(pp1 == p1_4c && pp2 == p2_3c)
                                change_position(1,2,0,4,3,5);
			else if(pp1 == p1_4c && pp2 == p2_4c)
                                change_position(1,2,0,4,3,5);
        }
        else if(kPlayers == 6)
        {
			if(pp1 == p1_1c && pp2 == p2_1c)
				change_position(0,1,2,3,4,5);
			else if(pp1 == p1_1c && pp2 == p2_2c)
				change_position(0,1,2,4,3,5);
			else if(pp1 == p1_1c && pp2 == p2_3c)
				change_position(0,1,2,4,5,3);
			else if(pp1 == p1_1c && pp2 == p2_4c)
				change_position(0,1,2,4,5,3);
			else if(pp1 == p1_2c && pp2 == p2_1c)
				change_position(1,0,2,3,4,5);
			else if(pp1 == p1_2c && pp2 == p2_2c)
				change_position(1,0,2,4,3,5);
			else if(pp1 == p1_2c && pp2 == p2_3c)
				change_position(1,0,2,4,5,3);
			else if(pp1 == p1_2c && pp2 == p2_4c)
				change_position(1,0,2,4,5,3);
			else if(pp1 == p1_3c && pp2 == p2_1c)
				change_position(1,2,0,3,4,5);
			else if(pp1 == p1_3c && pp2 == p2_2c)
				change_position(1,2,0,4,3,5);
			else if(pp1 == p1_3c && pp2 == p2_3c)
				change_position(1,2,0,4,5,3);
			else if(pp1 == p1_3c && pp2 == p2_4c)
				change_position(1,2,0,4,5,3);
			else if(pp1 == p1_4c && pp2 == p2_1c)
				change_position(1,2,0,3,4,5);
			else if(pp1 == p1_4c && pp2 == p2_2c)
				change_position(1,2,0,4,3,5);
			else if(pp1 == p1_4c && pp2 == p2_3c)
				change_position(1,2,0,4,5,3);
			else if(pp1 == p1_4c && pp2 == p2_4c)
				change_position(1,2,0,4,5,3);
        }
        else if(kPlayers == 7)
        {
			if(pp1 == p1_1c && pp2 == p2_1c)
				change_position2(0,1,1,1,3,1,1,1);
			else if(pp1 == p1_1c && pp2 == p2_2c)
				change_position2(0,1,1,1,1,3,1,1);
			else if(pp1 == p1_1c && pp2 == p2_3c)
				change_position2(0,1,1,1,1,1,3,1);
			else if(pp1 == p1_1c && pp2 == p2_4c)
				change_position2(0,1,1,1,1,1,3,1);
			else if(pp1 == p1_2c && pp2 == p2_1c)
				change_position2(1,0,1,1,3,1,1,1);
			else if(pp1 == p1_2c && pp2 == p2_2c)
				change_position2(1,0,1,1,1,3,1,1);
			else if(pp1 == p1_2c && pp2 == p2_3c)
				change_position2(1,0,1,1,1,1,3,1);
			else if(pp1 == p1_2c && pp2 == p2_4c)
				change_position2(1,0,1,1,1,1,3,1);
			else if(pp1 == p1_3c && pp2 == p2_1c)
				change_position2(1,1,0,1,3,1,1,1);
			else if(pp1 == p1_3c && pp2 == p2_2c)
				change_position2(1,1,0,1,1,3,1,1);
			else if(pp1 == p1_3c && pp2 == p2_3c)
				change_position2(1,1,0,1,1,1,3,1);
			else if(pp1 == p1_3c && pp2 == p2_4c)
				change_position2(1,1,0,1,1,1,3,1);
			else if(pp1 == p1_4c && pp2 == p2_1c)
				change_position2(1,1,1,0,3,1,1,1);
			else if(pp1 == p1_4c && pp2 == p2_2c)
				change_position2(1,1,1,0,1,3,1,1);
			else if(pp1 == p1_4c && pp2 == p2_3c)
				change_position2(1,1,1,0,1,1,3,1);
			else if(pp1 == p1_4c && pp2 == p2_4c)
				change_position2(1,1,1,0,1,1,3,1);
        }
        else if(kPlayers >= 8)
        {
			if(pp1 == p1_1c && pp2 == p2_1c)
				change_position2(0,1,1,1,3,1,1,1);
			else if(pp1 == p1_1c && pp2 == p2_2c)
				change_position2(0,1,1,1,1,3,1,1);
			else if(pp1 == p1_1c && pp2 == p2_3c)
				change_position2(0,1,1,1,1,1,3,1);
			else if(pp1 == p1_1c && pp2 == p2_4c)
				change_position2(0,1,1,1,1,1,1,3);
			else if(pp1 == p1_2c && pp2 == p2_1c)
				change_position2(1,0,1,1,3,1,1,1);
			else if(pp1 == p1_2c && pp2 == p2_2c)
				change_position2(1,0,1,1,1,3,1,1);
			else if(pp1 == p1_2c && pp2 == p2_3c)
				change_position2(1,0,1,1,1,1,3,1);
			else if(pp1 == p1_2c && pp2 == p2_4c)
				change_position2(1,0,1,1,1,1,1,3);
			else if(pp1 == p1_3c && pp2 == p2_1c)
				change_position2(1,1,0,1,3,1,1,1);
			else if(pp1 == p1_3c && pp2 == p2_2c)
				change_position2(1,1,0,1,1,3,1,1);
			else if(pp1 == p1_3c && pp2 == p2_3c)
				change_position2(1,1,0,1,1,1,3,1);
			else if(pp1 == p1_3c && pp2 == p2_4c)
				change_position2(1,1,0,1,1,1,1,3);
			else if(pp1 == p1_4c && pp2 == p2_1c)
				change_position2(1,1,1,0,3,1,1,1);
			else if(pp1 == p1_4c && pp2 == p2_2c)
				change_position2(1,1,1,0,1,3,1,1);
			else if(pp1 == p1_4c && pp2 == p2_3c)
				change_position2(1,1,1,0,1,1,3,1);
			else if(pp1 == p1_4c && pp2 == p2_4c)
				change_position2(1,1,1,0,1,1,1,3);
        }
}
#endif


/* used the the CPU interface to notify that VBlank has ended, so we can update */
/* IPT_VBLANK input ports. */
void inputport_vblank_end(void)
{
	int port;
	int i;


profiler_mark(PROFILER_INPUT);
	for (port = 0;port < MAX_INPUT_PORTS;port++)
	{
		if (input_vblank[port])
		{
			input_port_value[port] ^= input_vblank[port];
			input_vblank[port] = 0;
		}
	}

	/* update the analog devices */
	for (i = 0;i < OSD_MAX_JOY_ANALOG;i++)
	{
		/* update the analog joystick position */
		int a;
		for (a=0; a<MAX_ANALOG_AXES ; a++)
		{
			analog_previous_axis[i][a] = analog_current_axis[i][a];
		}
		osd_analogjoy_read (i, analog_current_axis[i], analogjoy_input[i]);

		/* update mouse/trackball position */
		osd_trak_read (i, &(mouse_delta_axis[i])[X_AXIS], &(mouse_delta_axis[i])[Y_AXIS]);

		/* update lightgun position, if any */
 		osd_lightgun_read (i, &(lightgun_delta_axis[i])[X_AXIS], &(lightgun_delta_axis[i])[Y_AXIS]);
	}

	for (i = 0;i < MAX_INPUT_PORTS;i++)
	{
		struct InputPort *in;

		in=input_analog[i];
		if (in)
		{
			update_analog_port(i);
		}
	}
profiler_mark(PROFILER_END);
}



int readinputport(int port)
{
	struct InputPort *in;

	/* Update analog ports on demand */
	in=input_analog[port];
	if (in)
	{
		scale_analog_port(port);
	}

	return input_port_value[port];
}

READ_HANDLER( input_port_0_r ) { return readinputport(0); }
READ_HANDLER( input_port_1_r ) { return readinputport(1); }
READ_HANDLER( input_port_2_r ) { return readinputport(2); }
READ_HANDLER( input_port_3_r ) { return readinputport(3); }
READ_HANDLER( input_port_4_r ) { return readinputport(4); }
READ_HANDLER( input_port_5_r ) { return readinputport(5); }
READ_HANDLER( input_port_6_r ) { return readinputport(6); }
READ_HANDLER( input_port_7_r ) { return readinputport(7); }
READ_HANDLER( input_port_8_r ) { return readinputport(8); }
READ_HANDLER( input_port_9_r ) { return readinputport(9); }
READ_HANDLER( input_port_10_r ) { return readinputport(10); }
READ_HANDLER( input_port_11_r ) { return readinputport(11); }
READ_HANDLER( input_port_12_r ) { return readinputport(12); }
READ_HANDLER( input_port_13_r ) { return readinputport(13); }
READ_HANDLER( input_port_14_r ) { return readinputport(14); }
READ_HANDLER( input_port_15_r ) { return readinputport(15); }
READ_HANDLER( input_port_16_r ) { return readinputport(16); }
READ_HANDLER( input_port_17_r ) { return readinputport(17); }
READ_HANDLER( input_port_18_r ) { return readinputport(18); }
READ_HANDLER( input_port_19_r ) { return readinputport(19); }

READ16_HANDLER( input_port_0_word_r ) { return readinputport(0); }
READ16_HANDLER( input_port_1_word_r ) { return readinputport(1); }
READ16_HANDLER( input_port_2_word_r ) { return readinputport(2); }
READ16_HANDLER( input_port_3_word_r ) { return readinputport(3); }
READ16_HANDLER( input_port_4_word_r ) { return readinputport(4); }
READ16_HANDLER( input_port_5_word_r ) { return readinputport(5); }
READ16_HANDLER( input_port_6_word_r ) { return readinputport(6); }
READ16_HANDLER( input_port_7_word_r ) { return readinputport(7); }
READ16_HANDLER( input_port_8_word_r ) { return readinputport(8); }
READ16_HANDLER( input_port_9_word_r ) { return readinputport(9); }
READ16_HANDLER( input_port_10_word_r ) { return readinputport(10); }
READ16_HANDLER( input_port_11_word_r ) { return readinputport(11); }
READ16_HANDLER( input_port_12_word_r ) { return readinputport(12); }
READ16_HANDLER( input_port_13_word_r ) { return readinputport(13); }
READ16_HANDLER( input_port_14_word_r ) { return readinputport(14); }
READ16_HANDLER( input_port_15_word_r ) { return readinputport(15); }
READ16_HANDLER( input_port_16_word_r ) { return readinputport(16); }
READ16_HANDLER( input_port_17_word_r ) { return readinputport(17); }
READ16_HANDLER( input_port_18_word_r ) { return readinputport(18); }
READ16_HANDLER( input_port_19_word_r ) { return readinputport(19); }

#ifdef MAME_NET
void set_default_player_controls(int player)
{
	if (player == NET_SPECTATOR)
		default_player = NET_SPECTATOR;
	else
		default_player = player - 1;
}
#endif /* MAME_NET */

/***************************************************************************/
/* InputPort conversion */

static unsigned input_port_count(const struct InputPortTiny *src)
{
	unsigned total;

	total = 0;
	while (src->type != IPT_END)
	{
		int type = src->type & ~IPF_MASK;
		if (type > IPT_ANALOG_START && type < IPT_ANALOG_END)
			total += 2;
		else if (type != IPT_EXTENSION)
			++total;
		++src;
	}

	++total; /* for IPT_END */

	return total;
}

struct InputPort* input_port_allocate(const struct InputPortTiny *src)
{
	struct InputPort* dst;
	struct InputPort* base;
	unsigned total;

	total = input_port_count(src);

	base = (struct InputPort*)malloc(total * sizeof(struct InputPort));
	dst = base;

	while (src->type != IPT_END)
	{
		int type = src->type & ~IPF_MASK;
		const struct InputPortTiny *ext;
		const struct InputPortTiny *src_end;
		InputCode seq_default;

		if (type > IPT_ANALOG_START && type < IPT_ANALOG_END)
			src_end = src + 2;
		else
			src_end = src + 1;

		switch (type)
		{
			case IPT_END :
			case IPT_PORT :
			case IPT_DIPSWITCH_NAME :
			case IPT_DIPSWITCH_SETTING :
				seq_default = CODE_NONE;
			break;
			default:
				seq_default = CODE_DEFAULT;
		}

		ext = src_end;
		while (src != src_end)
		{
			dst->type = src->type;
			dst->mask = src->mask;
			dst->default_value = src->default_value;
			dst->name = src->name;

  			if (ext->type == IPT_EXTENSION)
  			{
				InputCode or1 =	IP_GET_CODE_OR1(ext);
				InputCode or2 =	IP_GET_CODE_OR2(ext);

				if (or1 < __code_max)
				{
					if (or2 < __code_max)
						seq_set_3(&dst->seq, or1, CODE_OR, or2);
					else
						seq_set_1(&dst->seq, or1);
				} else {
					if (or1 == CODE_NONE)
						seq_set_1(&dst->seq, or2);
					else
						seq_set_1(&dst->seq, or1);
				}

  				++ext;
  			} else {
				seq_set_1(&dst->seq,seq_default);
  			}

			++src;
			++dst;
		}

		src = ext;
	}

	dst->type = IPT_END;

	return base;
}

void input_port_free(struct InputPort* dst)
{
	free(dst);
}


void seq_set_string(InputSeq* a, const char *buf)
{
	char *lbuf;
	char *arg = NULL;
	int j;
	struct ik *pik;
	int found;

	// create a locale buffer to be parsed by strtok
	lbuf = malloc (strlen(buf)+1);

	// copy the input string
	strcpy (lbuf, buf);

	for(j=0;j<SEQ_MAX;++j)
		(*a)[j] = CODE_NONE;

	arg = strtok(lbuf, " \t\r\n");
	j = 0;
	while( arg != NULL )
	{
		found = 0;

		pik = input_keywords;

		while (!found && pik->name && pik->name[0] != 0)
		{
			if (strcmp(pik->name,arg) == 0)
			{
				// this entry is only valid if it is a KEYCODE
				if (pik->type == IKT_STD)
				{
					(*a)[j] = pik->val;
					j++;
					found = 1;
				}
			}
			pik++;
		}

		pik = osd_input_keywords;

		if (pik)
		{
			while (!found && pik->name && pik->name[0] != 0)
			{
				if (strcmp(pik->name,arg) == 0)
				{
					switch (pik->type)
					{
						case IKT_STD:
							(*a)[j] = pik->val;
							j++;
							found = 1;
						break;

						case IKT_OSD_KEY:
							(*a)[j] = keyoscode_to_code(pik->val);
							j++;
							found = 1;
						break;

						case IKT_OSD_JOY:
							(*a)[j] = joyoscode_to_code(pik->val);
							j++;
							found = 1;
						break;
					}
				}
				pik++;
			}
		}

		arg = strtok(NULL, " \t\r\n");
	}
	free (lbuf);
}

void init_analog_seq()
{
	struct InputPort *in;
	int player, axis;

/* init analogjoy_input array */
	for (player=0; player<OSD_MAX_JOY_ANALOG; player++)
	{
		for (axis=0; axis<MAX_ANALOG_AXES; axis++)
		{
			analogjoy_input[player][axis] = CODE_NONE;
		}
	}

	in = Machine->input_ports;
	if (in->type == IPT_END) return; 	/* nothing to do */

	/* make sure the InputPort definition is correct */
	if (in->type != IPT_PORT)
	{
		logerror("Error in InputPort definition: expecting PORT_START\n");
		return;
	}
	else
	{
		in++;
	}

	while (in->type != IPT_END)
	{
		if (in->type != IPT_PORT && ((in->type & ~IPF_MASK) > IPT_ANALOG_START)
			&& ((in->type & ~IPF_MASK) < IPT_ANALOG_END))
		{
			int j, invert;
			InputSeq *seq;
			InputCode analog_seq;

			seq = input_port_seq(in);
			invert = 0;
			analog_seq = CODE_NONE;

			for(j=0; j<SEQ_MAX && analog_seq == CODE_NONE; ++j)
			{
				switch ((*seq)[j])
				{
					case CODE_NONE :
						continue;
					case CODE_NOT :
						invert = !invert;
						break;
					case CODE_OR :
						invert = 0;
						break;
					default:
						if (!invert && is_joystick_axis_code((*seq)[j]) )
						{
							analog_seq = return_os_joycode((*seq)[j]);
						}
						invert = 0;
						break;
				}
			}
			if (analog_seq != CODE_NONE)
			{
				switch (in->type & IPF_PLAYERMASK)
				{
					case IPF_PLAYER2:          player = 1; break;
					case IPF_PLAYER3:          player = 2; break;
					case IPF_PLAYER4:          player = 3; break;
					case IPF_PLAYER1: default: player = 0; break;
				}

				switch (in->type & ~IPF_MASK)
				{
					case IPT_DIAL:
					case IPT_PADDLE:
					case IPT_TRACKBALL_X:
					case IPT_LIGHTGUN_X:
					case IPT_AD_STICK_X:
						axis = X_AXIS;
						break;
					case IPT_DIAL_V:
					case IPT_PADDLE_V:
					case IPT_TRACKBALL_Y:
					case IPT_LIGHTGUN_Y:
					case IPT_AD_STICK_Y:
						axis = Y_AXIS;
						break;
					case IPT_AD_STICK_Z:
					case IPT_PEDAL2:
						axis = Z_AXIS;
						break;
					case IPT_PEDAL:
						axis = PEDAL_AXIS;
						break;
					default:
						axis = 0;
						break;
				}

				analogjoy_input[player][axis] = analog_seq;
			}
		}

		in++;
	}

	return;
}
